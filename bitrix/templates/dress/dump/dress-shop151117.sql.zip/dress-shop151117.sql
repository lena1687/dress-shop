-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Ноя 15 2017 г., 11:54
-- Версия сервера: 10.1.25-MariaDB-
-- Версия PHP: 7.0.22-0ubuntu0.17.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `dress-shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `b_admin_notify`
--

CREATE TABLE `b_admin_notify` (
  `ID` int(18) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `ENABLE_CLOSE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `PUBLIC_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NOTIFY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_admin_notify_lang`
--

CREATE TABLE `b_admin_notify_lang` (
  `ID` int(18) NOT NULL,
  `NOTIFY_ID` int(18) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_agent`
--

CREATE TABLE `b_agent` (
  `ID` int(18) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `NAME` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `LAST_EXEC` datetime DEFAULT NULL,
  `NEXT_EXEC` datetime NOT NULL,
  `DATE_CHECK` datetime DEFAULT NULL,
  `AGENT_INTERVAL` int(18) DEFAULT '86400',
  `IS_PERIOD` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `USER_ID` int(18) DEFAULT NULL,
  `RUNNING` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_agent`
--

INSERT INTO `b_agent` (`ID`, `MODULE_ID`, `SORT`, `NAME`, `ACTIVE`, `LAST_EXEC`, `NEXT_EXEC`, `DATE_CHECK`, `AGENT_INTERVAL`, `IS_PERIOD`, `USER_ID`, `RUNNING`) VALUES
(1, 'main', 100, 'CEvent::CleanUpAgent();', 'Y', '2017-11-15 08:18:46', '2017-11-16 00:00:00', NULL, 86400, 'Y', NULL, 'N'),
(2, 'main', 100, 'CUser::CleanUpHitAuthAgent();', 'Y', '2017-11-15 08:18:47', '2017-11-16 00:00:00', NULL, 86400, 'Y', NULL, 'N'),
(3, 'main', 100, 'CCaptchaAgent::DeleteOldCaptcha(3600);', 'Y', '2017-11-15 11:20:24', '2017-11-15 12:20:24', NULL, 3600, 'N', NULL, 'N'),
(4, 'main', 100, 'CUndo::CleanUpOld();', 'Y', '2017-11-15 08:18:50', '2017-11-16 00:00:00', NULL, 86400, 'Y', NULL, 'N'),
(5, 'main', 100, 'CSiteCheckerTest::CommonTest();', 'Y', '2017-11-15 08:30:04', '2017-11-16 08:30:04', NULL, 86400, 'N', NULL, 'N'),
(6, 'main', 100, '\\Bitrix\\Main\\Analytics\\CounterDataTable::submitData();', 'Y', '2017-11-15 11:53:31', '2017-11-15 11:54:31', NULL, 60, 'N', NULL, 'N'),
(7, 'search', 10, 'CSearchSuggest::CleanUpAgent();', 'Y', '2017-11-15 08:30:04', '2017-11-16 08:30:04', NULL, 86400, 'N', NULL, 'N'),
(8, 'search', 10, 'CSearchStatistic::CleanUpAgent();', 'Y', '2017-11-15 08:30:04', '2017-11-16 08:30:04', NULL, 86400, 'N', NULL, 'N'),
(9, 'seo', 100, 'Bitrix\\Seo\\Engine\\YandexDirect::updateAgent();', 'Y', '2017-11-15 11:21:12', '2017-11-15 12:21:12', NULL, 3600, 'N', NULL, 'N'),
(10, 'seo', 100, 'Bitrix\\Seo\\Adv\\LogTable::clean();', 'Y', '2017-11-15 08:30:04', '2017-11-16 08:30:04', NULL, 86400, 'N', NULL, 'N'),
(11, 'seo', 100, 'Bitrix\\Seo\\Adv\\Auto::checkQuantityAgent();', 'Y', '2017-11-15 11:21:13', '2017-11-15 12:21:13', NULL, 3600, 'N', NULL, 'N');

-- --------------------------------------------------------

--
-- Структура таблицы `b_app_password`
--

CREATE TABLE `b_app_password` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `APPLICATION_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DIGEST_PASSWORD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `DATE_LOGIN` datetime DEFAULT NULL,
  `LAST_IP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYSCOMMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_b24connector_buttons`
--

CREATE TABLE `b_b24connector_buttons` (
  `ID` int(11) NOT NULL,
  `APP_ID` int(11) NOT NULL,
  `ADD_DATE` datetime NOT NULL,
  `ADD_BY` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SCRIPT` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_bitrixcloud_option`
--

CREATE TABLE `b_bitrixcloud_option` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL,
  `PARAM_KEY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAM_VALUE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_bitrixcloud_option`
--

INSERT INTO `b_bitrixcloud_option` (`ID`, `NAME`, `SORT`, `PARAM_KEY`, `PARAM_VALUE`) VALUES
(1, 'backup_quota', 0, '0', '0'),
(2, 'backup_total_size', 0, '0', '0'),
(3, 'backup_last_backup_time', 0, '0', '1508121693'),
(4, 'monitoring_expire_time', 0, '0', '1510652952');

-- --------------------------------------------------------

--
-- Структура таблицы `b_cache_tag`
--

CREATE TABLE `b_cache_tag` (
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SALT` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RELATIVE_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAG` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_cache_tag`
--

INSERT INTO `b_cache_tag` (`SITE_ID`, `CACHE_SALT`, `RELATIVE_PATH`, `TAG`) VALUES
(NULL, NULL, '0:1510713004', '**'),
('s1', '/e25', '/s1/bitrix/news.list/e25', 'iblock_id_1'),
('s1', '/e25', '/s1/bitrix/news.list/e25', 'iblock_id_4'),
('s1', '/e25', '/s1/bitrix/news.list/e25', 'iblock_id_5'),
('s1', '/e25', '/s1/bitrix/catalog.section.list/e25', 'iblock_id_3'),
('s1', '/e25', '/s1/bitrix/catalog.element/e25', 'iblock_id_3'),
('s1', '/e25', '/s1/bitrix/catalog.element/e25', 'iblock_property_enum_3'),
('s1', '/e25', '/iblock/catalog', 'iblock_id_3'),
('s1', '/e25', '/s1/bitrix/catalog.smart.filter/e25', 'iblock_id_3'),
('s1', '/e25', '/s1/bitrix/catalog.section', 'iblock_id_3'),
('s1', '/e25', '/s1/bitrix/catalog.section', 'iblock_property_enum_3'),
('s1', '/e25', '/s1/bitrix/catalog.top', 'iblock_id_3'),
('s1', '/e25', '/s1/bitrix/catalog.top', 'iblock_property_enum_3');

-- --------------------------------------------------------

--
-- Структура таблицы `b_captcha`
--

CREATE TABLE `b_captcha` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `IP` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_checklist`
--

CREATE TABLE `b_checklist` (
  `ID` int(11) NOT NULL,
  `DATE_CREATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TESTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMPANY_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PICTURE` int(11) DEFAULT NULL,
  `TOTAL` int(11) DEFAULT NULL,
  `SUCCESS` int(11) DEFAULT NULL,
  `FAILED` int(11) DEFAULT NULL,
  `PENDING` int(11) DEFAULT NULL,
  `SKIP` int(11) DEFAULT NULL,
  `STATE` longtext COLLATE utf8_unicode_ci,
  `REPORT_COMMENT` text COLLATE utf8_unicode_ci,
  `REPORT` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `EMAIL` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHONE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SENDED_TO_BITRIX` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `HIDDEN` char(1) COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_clouds_file_bucket`
--

CREATE TABLE `b_clouds_file_bucket` (
  `ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SORT` int(11) DEFAULT '500',
  `READ_ONLY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `SERVICE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BUCKET` varchar(63) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCATION` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CNAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_COUNT` int(11) DEFAULT '0',
  `FILE_SIZE` float DEFAULT '0',
  `LAST_FILE_ID` int(11) DEFAULT NULL,
  `PREFIX` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `FILE_RULES` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_clouds_file_resize`
--

CREATE TABLE `b_clouds_file_resize` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ERROR_CODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `FILE_ID` int(11) DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `FROM_PATH` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_PATH` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_clouds_file_upload`
--

CREATE TABLE `b_clouds_file_upload` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FILE_PATH` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `FILE_SIZE` int(11) DEFAULT NULL,
  `TMP_FILE` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BUCKET_ID` int(11) NOT NULL,
  `PART_SIZE` int(11) NOT NULL,
  `PART_NO` int(11) NOT NULL,
  `PART_FAIL_COUNTER` int(11) NOT NULL,
  `NEXT_STEP` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_component_params`
--

CREATE TABLE `b_component_params` (
  `ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `COMPONENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TEMPLATE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REAL_PATH` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SEF_MODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SEF_FOLDER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `START_CHAR` int(11) NOT NULL,
  `END_CHAR` int(11) NOT NULL,
  `PARAMETERS` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_component_params`
--

INSERT INTO `b_component_params` (`ID`, `SITE_ID`, `COMPONENT_NAME`, `TEMPLATE_NAME`, `REAL_PATH`, `SEF_MODE`, `SEF_FOLDER`, `START_CHAR`, `END_CHAR`, `PARAMETERS`) VALUES
(844, 's1', 'bitrix:menu', 'header-menu', '/bitrix/templates/dress/header.php', 'N', NULL, 1735, 2669, 'a:10:{s:18:\"ALLOW_MULTI_SELECT\";s:1:\"N\";s:15:\"CHILD_MENU_TYPE\";s:4:\"left\";s:5:\"DELAY\";s:1:\"N\";s:9:\"MAX_LEVEL\";s:1:\"1\";s:19:\"MENU_CACHE_GET_VARS\";a:1:{i:0;s:0:\"\";}s:15:\"MENU_CACHE_TIME\";s:4:\"3600\";s:15:\"MENU_CACHE_TYPE\";s:1:\"N\";s:21:\"MENU_CACHE_USE_GROUPS\";s:1:\"Y\";s:14:\"ROOT_MENU_TYPE\";s:4:\"left\";s:7:\"USE_EXT\";s:1:\"N\";}'),
(1815, 's1', 'bitrix:breadcrumb', 'breadcrumb', '/index.php', 'N', NULL, 221, 449, 'a:4:{s:4:\"PATH\";s:0:\"\";s:7:\"SITE_ID\";s:2:\"s1\";s:10:\"START_FROM\";s:1:\"0\";s:18:\"COMPONENT_TEMPLATE\";s:10:\"breadcrumb\";}'),
(1816, 's1', 'bitrix:news.list', 'slider', '/index.php', 'N', NULL, 600, 2224, 'a:52:{s:18:\"ACTIVE_DATE_FORMAT\";s:5:\"d.m.Y\";s:18:\"ADD_SECTIONS_CHAIN\";s:1:\"Y\";s:9:\"AJAX_MODE\";s:1:\"N\";s:22:\"AJAX_OPTION_ADDITIONAL\";s:0:\"\";s:19:\"AJAX_OPTION_HISTORY\";s:1:\"N\";s:16:\"AJAX_OPTION_JUMP\";s:1:\"N\";s:17:\"AJAX_OPTION_STYLE\";s:1:\"Y\";s:12:\"CACHE_FILTER\";s:1:\"N\";s:12:\"CACHE_GROUPS\";s:1:\"Y\";s:10:\"CACHE_TIME\";s:8:\"36000000\";s:10:\"CACHE_TYPE\";s:1:\"A\";s:11:\"CHECK_DATES\";s:1:\"Y\";s:18:\"COMPONENT_TEMPLATE\";s:6:\"slider\";s:10:\"DETAIL_URL\";s:0:\"\";s:20:\"DISPLAY_BOTTOM_PAGER\";s:1:\"Y\";s:12:\"DISPLAY_DATE\";s:1:\"N\";s:12:\"DISPLAY_NAME\";s:1:\"N\";s:15:\"DISPLAY_PICTURE\";s:1:\"Y\";s:20:\"DISPLAY_PREVIEW_TEXT\";s:1:\"Y\";s:17:\"DISPLAY_TOP_PAGER\";s:1:\"N\";s:10:\"FIELD_CODE\";a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}s:11:\"FILTER_NAME\";s:0:\"\";s:24:\"HIDE_LINK_WHEN_NO_DETAIL\";s:1:\"N\";s:9:\"IBLOCK_ID\";s:1:\"1\";s:11:\"IBLOCK_TYPE\";s:13:\"slider_header\";s:25:\"INCLUDE_IBLOCK_INTO_CHAIN\";s:1:\"N\";s:19:\"INCLUDE_SUBSECTIONS\";s:1:\"Y\";s:11:\"MESSAGE_404\";s:0:\"\";s:10:\"NEWS_COUNT\";s:2:\"20\";s:22:\"PAGER_BASE_LINK_ENABLE\";s:1:\"N\";s:20:\"PAGER_DESC_NUMBERING\";s:1:\"N\";s:31:\"PAGER_DESC_NUMBERING_CACHE_TIME\";s:5:\"36000\";s:14:\"PAGER_SHOW_ALL\";s:1:\"N\";s:17:\"PAGER_SHOW_ALWAYS\";s:1:\"N\";s:14:\"PAGER_TEMPLATE\";s:8:\".default\";s:11:\"PAGER_TITLE\";s:14:\"Новости\";s:14:\"PARENT_SECTION\";s:0:\"\";s:19:\"PARENT_SECTION_CODE\";s:0:\"\";s:20:\"PREVIEW_TRUNCATE_LEN\";s:0:\"\";s:13:\"PROPERTY_CODE\";a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}s:17:\"SET_BROWSER_TITLE\";s:1:\"N\";s:17:\"SET_LAST_MODIFIED\";s:1:\"N\";s:20:\"SET_META_DESCRIPTION\";s:1:\"N\";s:17:\"SET_META_KEYWORDS\";s:1:\"Y\";s:14:\"SET_STATUS_404\";s:1:\"N\";s:9:\"SET_TITLE\";s:1:\"N\";s:8:\"SHOW_404\";s:1:\"N\";s:8:\"SORT_BY1\";s:11:\"ACTIVE_FROM\";s:8:\"SORT_BY2\";s:4:\"SORT\";s:11:\"SORT_ORDER1\";s:4:\"DESC\";s:11:\"SORT_ORDER2\";s:3:\"ASC\";s:20:\"STRICT_SECTION_CHECK\";s:1:\"N\";}'),
(1817, 's1', 'bitrix:catalog.top', 'mytop', '/index.php', 'N', NULL, 2527, 4879, 'a:58:{s:15:\"ACTION_VARIABLE\";s:6:\"action\";s:13:\"ADD_PICT_PROP\";s:1:\"-\";s:24:\"ADD_PROPERTIES_TO_BASKET\";s:1:\"Y\";s:10:\"BASKET_URL\";s:20:\"/personal/basket.php\";s:12:\"CACHE_FILTER\";s:1:\"N\";s:12:\"CACHE_GROUPS\";s:1:\"Y\";s:10:\"CACHE_TIME\";s:8:\"36000000\";s:10:\"CACHE_TYPE\";s:1:\"A\";s:12:\"COMPARE_NAME\";s:20:\"CATALOG_COMPARE_LIST\";s:15:\"COMPATIBLE_MODE\";s:1:\"Y\";s:18:\"COMPONENT_TEMPLATE\";s:5:\"mytop\";s:10:\"DETAIL_URL\";s:39:\"/catalog/#SECTION_CODE#/#ELEMENT_CODE#/\";s:15:\"DISPLAY_COMPARE\";s:1:\"N\";s:13:\"ELEMENT_COUNT\";s:1:\"6\";s:18:\"ELEMENT_SORT_FIELD\";s:5:\"shows\";s:19:\"ELEMENT_SORT_FIELD2\";s:2:\"id\";s:18:\"ELEMENT_SORT_ORDER\";s:3:\"asc\";s:19:\"ELEMENT_SORT_ORDER2\";s:4:\"desc\";s:15:\"ENLARGE_PRODUCT\";s:4:\"PROP\";s:12:\"ENLARGE_PROP\";s:1:\"-\";s:11:\"FILTER_NAME\";s:0:\"\";s:9:\"IBLOCK_ID\";s:1:\"3\";s:11:\"IBLOCK_TYPE\";s:10:\"assortment\";s:10:\"LABEL_PROP\";a:4:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:16:\"CAT_AVAILABILITY\";}s:17:\"LABEL_PROP_MOBILE\";a:4:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:16:\"CAT_AVAILABILITY\";}s:19:\"LABEL_PROP_POSITION\";s:8:\"top-left\";s:18:\"LINE_ELEMENT_COUNT\";s:1:\"3\";s:22:\"MESS_BTN_ADD_TO_BASKET\";s:17:\"В корзину\";s:12:\"MESS_BTN_BUY\";s:12:\"Купить\";s:16:\"MESS_BTN_COMPARE\";s:16:\"Сравнить\";s:15:\"MESS_BTN_DETAIL\";s:18:\"Подробнее\";s:18:\"MESS_NOT_AVAILABLE\";s:24:\"Нет в наличии\";s:12:\"OFFERS_LIMIT\";s:1:\"5\";s:26:\"PARTIAL_PRODUCT_PROPERTIES\";s:1:\"N\";s:10:\"PRICE_CODE\";N;s:17:\"PRICE_VAT_INCLUDE\";s:1:\"Y\";s:20:\"PRODUCT_BLOCKS_ORDER\";s:54:\"price,props,sku,quantityLimit,quantity,buttons,compare\";s:19:\"PRODUCT_ID_VARIABLE\";s:2:\"id\";s:18:\"PRODUCT_PROPERTIES\";N;s:22:\"PRODUCT_PROPS_VARIABLE\";s:4:\"prop\";s:25:\"PRODUCT_QUANTITY_VARIABLE\";s:8:\"quantity\";s:20:\"PRODUCT_ROW_VARIANTS\";s:34:\"[{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\";s:20:\"PRODUCT_SUBSCRIPTION\";s:1:\"N\";s:13:\"PROPERTY_CODE\";a:6:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:9:\"CAT_PRICE\";i:4;s:16:\"CAT_AVAILABILITY\";i:5;s:0:\"\";}s:20:\"PROPERTY_CODE_MOBILE\";a:5:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:9:\"CAT_PRICE\";i:4;s:16:\"CAT_AVAILABILITY\";}s:12:\"ROTATE_TIMER\";s:1:\"2\";s:19:\"SECTION_ID_VARIABLE\";s:0:\"\";s:11:\"SECTION_URL\";s:24:\"/catalog/#SECTION_CODE#/\";s:8:\"SEF_MODE\";s:1:\"N\";s:8:\"SEF_RULE\";s:0:\"\";s:15:\"SHOW_PAGINATION\";s:1:\"Y\";s:16:\"SHOW_PRICE_COUNT\";s:1:\"1\";s:11:\"SHOW_SLIDER\";s:1:\"N\";s:14:\"TEMPLATE_THEME\";s:4:\"blue\";s:22:\"USE_ENHANCED_ECOMMERCE\";s:1:\"N\";s:15:\"USE_PRICE_COUNT\";s:1:\"N\";s:20:\"USE_PRODUCT_QUANTITY\";s:1:\"N\";s:9:\"VIEW_MODE\";s:7:\"SECTION\";}'),
(1818, 's1', 'dress:main.feedback', 'myfeedback', '/index.php', 'N', NULL, 4996, 5314, 'a:6:{s:18:\"COMPONENT_TEMPLATE\";s:10:\"myfeedback\";s:8:\"EMAIL_TO\";s:12:\"test@mail.ru\";s:16:\"EVENT_MESSAGE_ID\";N;s:7:\"OK_TEXT\";s:59:\"Спасибо, ваше сообщение принято.\";s:15:\"REQUIRED_FIELDS\";a:2:{i:0;s:4:\"TELL\";i:1;s:7:\"MESSAGE\";}s:11:\"USE_CAPTCHA\";s:1:\"N\";}'),
(1819, 's1', 'bitrix:catalog.smart.filter', 'myfilter', '/index.php', 'N', NULL, 5622, 6380, 'a:22:{s:12:\"CACHE_GROUPS\";s:1:\"Y\";s:10:\"CACHE_TIME\";s:8:\"36000000\";s:10:\"CACHE_TYPE\";s:1:\"A\";s:21:\"DISPLAY_ELEMENT_COUNT\";s:1:\"N\";s:11:\"FILTER_NAME\";s:9:\"arrFilter\";s:16:\"FILTER_VIEW_MODE\";s:10:\"horizontal\";s:9:\"IBLOCK_ID\";s:1:\"3\";s:11:\"IBLOCK_TYPE\";s:10:\"assortment\";s:17:\"PAGER_PARAMS_NAME\";s:8:\"arrPager\";s:14:\"POPUP_POSITION\";s:4:\"left\";s:15:\"SAVE_IN_SESSION\";s:1:\"N\";s:12:\"SECTION_CODE\";s:12:\"SECTION_CODE\";s:19:\"SECTION_DESCRIPTION\";s:1:\"-\";s:10:\"SECTION_ID\";s:26:\"={$_REQUEST[\"SECTION_ID\"]}\";s:13:\"SECTION_TITLE\";s:1:\"-\";s:8:\"SEF_MODE\";s:1:\"N\";s:14:\"TEMPLATE_THEME\";s:4:\"blue\";s:10:\"XML_EXPORT\";s:1:\"N\";s:18:\"COMPONENT_TEMPLATE\";s:8:\"myfilter\";s:8:\"SEF_RULE\";s:0:\"\";s:17:\"SECTION_CODE_PATH\";s:0:\"\";s:17:\"SMART_FILTER_PATH\";s:0:\"\";}'),
(1820, 's1', 'bitrix:catalog', 'mycatalog', '/index.php', 'Y', '/catalog/', 6455, 13189, 'a:153:{s:15:\"ACTION_VARIABLE\";s:6:\"action\";s:17:\"ADD_ELEMENT_CHAIN\";s:1:\"Y\";s:13:\"ADD_PICT_PROP\";s:1:\"-\";s:24:\"ADD_PROPERTIES_TO_BASKET\";s:1:\"Y\";s:18:\"ADD_SECTIONS_CHAIN\";s:1:\"Y\";s:9:\"AJAX_MODE\";s:1:\"N\";s:22:\"AJAX_OPTION_ADDITIONAL\";s:0:\"\";s:19:\"AJAX_OPTION_HISTORY\";s:1:\"N\";s:16:\"AJAX_OPTION_JUMP\";s:1:\"N\";s:17:\"AJAX_OPTION_STYLE\";s:1:\"Y\";s:10:\"BASKET_URL\";s:20:\"/personal/basket.php\";s:12:\"CACHE_FILTER\";s:1:\"N\";s:12:\"CACHE_GROUPS\";s:1:\"Y\";s:10:\"CACHE_TIME\";s:8:\"36000000\";s:10:\"CACHE_TYPE\";s:1:\"A\";s:15:\"COMPATIBLE_MODE\";s:1:\"Y\";s:18:\"COMPONENT_TEMPLATE\";s:9:\"mycatalog\";s:27:\"DETAIL_ADD_DETAIL_TO_SLIDER\";s:1:\"N\";s:23:\"DETAIL_BACKGROUND_IMAGE\";s:1:\"-\";s:16:\"DETAIL_BRAND_USE\";s:1:\"N\";s:20:\"DETAIL_BROWSER_TITLE\";s:4:\"NAME\";s:32:\"DETAIL_CHECK_SECTION_ID_VARIABLE\";s:1:\"N\";s:26:\"DETAIL_DETAIL_PICTURE_MODE\";a:1:{i:0;s:9:\"MAGNIFIER\";}s:19:\"DETAIL_DISPLAY_NAME\";s:1:\"Y\";s:32:\"DETAIL_DISPLAY_PREVIEW_TEXT_MODE\";s:1:\"E\";s:23:\"DETAIL_IMAGE_RESOLUTION\";s:4:\"1by1\";s:31:\"DETAIL_MAIN_BLOCK_PROPERTY_CODE\";a:1:{i:0;s:16:\"CAT_DETAIL_PHOTO\";}s:23:\"DETAIL_META_DESCRIPTION\";s:1:\"-\";s:20:\"DETAIL_META_KEYWORDS\";s:1:\"-\";s:31:\"DETAIL_PRODUCT_INFO_BLOCK_ORDER\";s:9:\"props,sku\";s:30:\"DETAIL_PRODUCT_PAY_BLOCK_ORDER\";s:55:\"price,rating,priceRanges,quantity,buttons,quantityLimit\";s:20:\"DETAIL_PROPERTY_CODE\";a:7:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:16:\"CAT_AVAILABILITY\";i:4;s:9:\"CAT_PRICE\";i:5;s:16:\"CAT_DETAIL_PHOTO\";i:6;s:0:\"\";}s:24:\"DETAIL_SET_CANONICAL_URL\";s:1:\"Y\";s:19:\"DETAIL_SHOW_POPULAR\";s:1:\"Y\";s:18:\"DETAIL_SHOW_SLIDER\";s:1:\"N\";s:18:\"DETAIL_SHOW_VIEWED\";s:1:\"Y\";s:22:\"DETAIL_SLIDER_INTERVAL\";s:4:\"5000\";s:22:\"DETAIL_SLIDER_PROGRESS\";s:1:\"N\";s:27:\"DETAIL_STRICT_SECTION_CHECK\";s:1:\"N\";s:19:\"DETAIL_USE_COMMENTS\";s:1:\"N\";s:22:\"DETAIL_USE_VOTE_RATING\";s:1:\"N\";s:28:\"DISABLE_INIT_JS_IN_COMPONENT\";s:1:\"N\";s:20:\"DISPLAY_BOTTOM_PAGER\";s:1:\"N\";s:17:\"DISPLAY_TOP_PAGER\";s:1:\"Y\";s:18:\"ELEMENT_SORT_FIELD\";s:4:\"sort\";s:19:\"ELEMENT_SORT_FIELD2\";s:2:\"id\";s:18:\"ELEMENT_SORT_ORDER\";s:3:\"asc\";s:19:\"ELEMENT_SORT_ORDER2\";s:4:\"desc\";s:8:\"FILE_404\";s:0:\"\";s:17:\"FILTER_FIELD_CODE\";a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}s:21:\"FILTER_HIDE_ON_MOBILE\";s:1:\"N\";s:11:\"FILTER_NAME\";s:0:\"\";s:17:\"FILTER_PRICE_CODE\";a:1:{i:0;s:9:\"CAT_PRICE\";}s:20:\"FILTER_PROPERTY_CODE\";a:6:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:16:\"CAT_AVAILABILITY\";i:4;s:9:\"CAT_PRICE\";i:5;s:0:\"\";}s:16:\"FILTER_VIEW_MODE\";s:10:\"HORIZONTAL\";s:9:\"IBLOCK_ID\";s:1:\"3\";s:11:\"IBLOCK_TYPE\";s:10:\"assortment\";s:19:\"INCLUDE_SUBSECTIONS\";s:1:\"Y\";s:14:\"INSTANT_RELOAD\";s:1:\"Y\";s:10:\"LABEL_PROP\";a:4:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:16:\"CAT_AVAILABILITY\";}s:17:\"LABEL_PROP_MOBILE\";N;s:19:\"LABEL_PROP_POSITION\";s:8:\"top-left\";s:9:\"LAZY_LOAD\";s:1:\"N\";s:18:\"LINE_ELEMENT_COUNT\";s:1:\"3\";s:17:\"LINK_ELEMENTS_URL\";s:39:\"link.php?PARENT_ELEMENT_ID=#ELEMENT_ID#\";s:14:\"LINK_IBLOCK_ID\";s:0:\"\";s:16:\"LINK_IBLOCK_TYPE\";s:0:\"\";s:17:\"LINK_PROPERTY_SID\";s:0:\"\";s:18:\"LIST_BROWSER_TITLE\";s:1:\"-\";s:20:\"LIST_ENLARGE_PRODUCT\";s:6:\"STRICT\";s:21:\"LIST_META_DESCRIPTION\";s:1:\"-\";s:18:\"LIST_META_KEYWORDS\";s:1:\"-\";s:25:\"LIST_PRODUCT_BLOCKS_ORDER\";s:54:\"props,price,sku,quantityLimit,quantity,buttons,compare\";s:25:\"LIST_PRODUCT_ROW_VARIANTS\";s:166:\"[{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\";s:18:\"LIST_PROPERTY_CODE\";a:6:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:16:\"CAT_AVAILABILITY\";i:4;s:9:\"CAT_PRICE\";i:5;s:0:\"\";}s:25:\"LIST_PROPERTY_CODE_MOBILE\";a:5:{i:0;s:9:\"CAT_COLOR\";i:1;s:8:\"CAT_SIZE\";i:2;s:14:\"CAT_SIZE_SHOES\";i:3;s:16:\"CAT_AVAILABILITY\";i:4;s:9:\"CAT_PRICE\";}s:16:\"LIST_SHOW_SLIDER\";s:1:\"N\";s:20:\"LIST_SLIDER_INTERVAL\";s:4:\"3000\";s:20:\"LIST_SLIDER_PROGRESS\";s:1:\"N\";s:14:\"LOAD_ON_SCROLL\";s:1:\"N\";s:11:\"MESSAGE_404\";s:0:\"\";s:22:\"MESS_BTN_ADD_TO_BASKET\";s:17:\"В корзину\";s:12:\"MESS_BTN_BUY\";s:12:\"Купить\";s:16:\"MESS_BTN_COMPARE\";s:18:\"Сравнение\";s:15:\"MESS_BTN_DETAIL\";s:18:\"Подробнее\";s:18:\"MESS_BTN_SUBSCRIBE\";s:22:\"Подписаться\";s:18:\"MESS_NOT_AVAILABLE\";s:24:\"Нет в наличии\";s:22:\"PAGER_BASE_LINK_ENABLE\";s:1:\"N\";s:20:\"PAGER_DESC_NUMBERING\";s:1:\"N\";s:31:\"PAGER_DESC_NUMBERING_CACHE_TIME\";s:5:\"36000\";s:14:\"PAGER_SHOW_ALL\";s:1:\"Y\";s:17:\"PAGER_SHOW_ALWAYS\";s:1:\"Y\";s:14:\"PAGER_TEMPLATE\";s:6:\"orange\";s:11:\"PAGER_TITLE\";s:12:\"Товары\";s:18:\"PAGE_ELEMENT_COUNT\";s:2:\"30\";s:26:\"PARTIAL_PRODUCT_PROPERTIES\";s:1:\"N\";s:10:\"PRICE_CODE\";N;s:17:\"PRICE_VAT_INCLUDE\";s:1:\"Y\";s:20:\"PRICE_VAT_SHOW_VALUE\";s:1:\"N\";s:19:\"PRODUCT_ID_VARIABLE\";s:2:\"id\";s:18:\"PRODUCT_PROPERTIES\";N;s:22:\"PRODUCT_PROPS_VARIABLE\";s:4:\"prop\";s:25:\"PRODUCT_QUANTITY_VARIABLE\";s:8:\"quantity\";s:18:\"SEARCH_CHECK_DATES\";s:1:\"Y\";s:20:\"SEARCH_NO_WORD_LOGIC\";s:1:\"Y\";s:24:\"SEARCH_PAGE_RESULT_COUNT\";s:2:\"50\";s:14:\"SEARCH_RESTART\";s:1:\"N\";s:25:\"SEARCH_USE_LANGUAGE_GUESS\";s:1:\"Y\";s:26:\"SECTIONS_HIDE_SECTION_NAME\";s:1:\"N\";s:25:\"SECTIONS_SHOW_PARENT_NAME\";s:1:\"Y\";s:18:\"SECTIONS_VIEW_MODE\";s:4:\"TILE\";s:24:\"SECTION_BACKGROUND_IMAGE\";s:1:\"-\";s:22:\"SECTION_COUNT_ELEMENTS\";s:1:\"N\";s:19:\"SECTION_ID_VARIABLE\";s:12:\"SECTION_CODE\";s:17:\"SECTION_TOP_DEPTH\";s:1:\"2\";s:10:\"SEF_FOLDER\";s:9:\"/catalog/\";s:8:\"SEF_MODE\";s:1:\"Y\";s:17:\"SET_LAST_MODIFIED\";s:1:\"N\";s:14:\"SET_STATUS_404\";s:1:\"N\";s:9:\"SET_TITLE\";s:1:\"N\";s:8:\"SHOW_404\";s:1:\"N\";s:16:\"SHOW_DEACTIVATED\";s:1:\"N\";s:16:\"SHOW_PRICE_COUNT\";s:1:\"1\";s:17:\"SHOW_TOP_ELEMENTS\";s:1:\"N\";s:19:\"SIDEBAR_DETAIL_SHOW\";s:1:\"N\";s:12:\"SIDEBAR_PATH\";s:0:\"\";s:20:\"SIDEBAR_SECTION_SHOW\";s:1:\"Y\";s:14:\"TEMPLATE_THEME\";s:4:\"blue\";s:17:\"TOP_ELEMENT_COUNT\";s:1:\"3\";s:22:\"TOP_ELEMENT_SORT_FIELD\";s:4:\"sort\";s:23:\"TOP_ELEMENT_SORT_FIELD2\";s:2:\"id\";s:22:\"TOP_ELEMENT_SORT_ORDER\";s:3:\"asc\";s:23:\"TOP_ELEMENT_SORT_ORDER2\";s:4:\"desc\";s:19:\"TOP_ENLARGE_PRODUCT\";s:6:\"STRICT\";s:22:\"TOP_LINE_ELEMENT_COUNT\";s:1:\"3\";s:24:\"TOP_PRODUCT_BLOCKS_ORDER\";s:54:\"price,props,sku,quantityLimit,quantity,buttons,compare\";s:24:\"TOP_PRODUCT_ROW_VARIANTS\";s:34:\"[{\'VARIANT\':\'2\',\'BIG_DATA\':false}]\";s:17:\"TOP_PROPERTY_CODE\";a:5:{i:0;s:16:\"cat_availability\";i:1;s:14:\"cat_size_shoes\";i:2;s:8:\"cat_size\";i:3;s:9:\"cat_price\";i:4;s:0:\"\";}s:24:\"TOP_PROPERTY_CODE_MOBILE\";a:4:{i:0;s:16:\"cat_availability\";i:1;s:14:\"cat_size_shoes\";i:2;s:8:\"cat_size\";i:3;s:9:\"cat_price\";}s:16:\"TOP_ROTATE_TIMER\";s:2:\"30\";s:15:\"TOP_SHOW_SLIDER\";s:1:\"N\";s:19:\"TOP_SLIDER_INTERVAL\";s:4:\"3000\";s:19:\"TOP_SLIDER_PROGRESS\";s:1:\"N\";s:13:\"TOP_VIEW_MODE\";s:7:\"SECTION\";s:11:\"USE_COMPARE\";s:1:\"N\";s:19:\"USE_ELEMENT_COUNTER\";s:1:\"Y\";s:22:\"USE_ENHANCED_ECOMMERCE\";s:1:\"N\";s:10:\"USE_FILTER\";s:1:\"Y\";s:24:\"USE_MAIN_ELEMENT_SECTION\";s:1:\"N\";s:15:\"USE_PRICE_COUNT\";s:1:\"N\";s:20:\"USE_PRODUCT_QUANTITY\";s:1:\"N\";s:9:\"USE_STORE\";s:1:\"N\";s:17:\"SEF_URL_TEMPLATES\";a:5:{s:8:\"sections\";s:0:\"\";s:7:\"section\";s:15:\"#SECTION_CODE#/\";s:7:\"element\";s:30:\"#SECTION_CODE#/#ELEMENT_CODE#/\";s:7:\"compare\";s:8:\"compare/\";s:12:\"smart_filter\";s:48:\"#SECTION_CODE#/filter/#SMART_FILTER_PATH#/apply/\";}}'),
(1821, 's1', 'bitrix:news.list', 'mymap', '/index.php', 'N', NULL, 14351, 16097, 'a:52:{s:18:\"ACTIVE_DATE_FORMAT\";s:5:\"d.m.Y\";s:18:\"ADD_SECTIONS_CHAIN\";s:1:\"N\";s:9:\"AJAX_MODE\";s:1:\"N\";s:22:\"AJAX_OPTION_ADDITIONAL\";s:0:\"\";s:19:\"AJAX_OPTION_HISTORY\";s:1:\"N\";s:16:\"AJAX_OPTION_JUMP\";s:1:\"N\";s:17:\"AJAX_OPTION_STYLE\";s:1:\"Y\";s:12:\"CACHE_FILTER\";s:1:\"N\";s:12:\"CACHE_GROUPS\";s:1:\"Y\";s:10:\"CACHE_TIME\";s:8:\"36000000\";s:10:\"CACHE_TYPE\";s:1:\"A\";s:11:\"CHECK_DATES\";s:1:\"Y\";s:18:\"COMPONENT_TEMPLATE\";s:5:\"mymap\";s:10:\"DETAIL_URL\";s:0:\"\";s:20:\"DISPLAY_BOTTOM_PAGER\";s:1:\"Y\";s:12:\"DISPLAY_DATE\";s:1:\"Y\";s:12:\"DISPLAY_NAME\";s:1:\"Y\";s:15:\"DISPLAY_PICTURE\";s:1:\"Y\";s:20:\"DISPLAY_PREVIEW_TEXT\";s:1:\"Y\";s:17:\"DISPLAY_TOP_PAGER\";s:1:\"N\";s:10:\"FIELD_CODE\";a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}s:11:\"FILTER_NAME\";s:0:\"\";s:24:\"HIDE_LINK_WHEN_NO_DETAIL\";s:1:\"N\";s:9:\"IBLOCK_ID\";s:1:\"4\";s:11:\"IBLOCK_TYPE\";s:10:\"dress_shop\";s:25:\"INCLUDE_IBLOCK_INTO_CHAIN\";s:1:\"N\";s:19:\"INCLUDE_SUBSECTIONS\";s:1:\"Y\";s:11:\"MESSAGE_404\";s:0:\"\";s:10:\"NEWS_COUNT\";s:2:\"20\";s:22:\"PAGER_BASE_LINK_ENABLE\";s:1:\"N\";s:20:\"PAGER_DESC_NUMBERING\";s:1:\"N\";s:31:\"PAGER_DESC_NUMBERING_CACHE_TIME\";s:5:\"36000\";s:14:\"PAGER_SHOW_ALL\";s:1:\"N\";s:17:\"PAGER_SHOW_ALWAYS\";s:1:\"N\";s:14:\"PAGER_TEMPLATE\";s:8:\".default\";s:11:\"PAGER_TITLE\";s:14:\"Новости\";s:14:\"PARENT_SECTION\";s:0:\"\";s:19:\"PARENT_SECTION_CODE\";s:0:\"\";s:20:\"PREVIEW_TRUNCATE_LEN\";s:0:\"\";s:13:\"PROPERTY_CODE\";a:6:{i:0;s:7:\"ADDRESS\";i:1;s:5:\"PHONE\";i:2;s:10:\"YANDEX_MAP\";i:3;s:12:\"SHOP_MANAGER\";i:4;s:5:\"HOURS\";i:5;s:0:\"\";}s:17:\"SET_BROWSER_TITLE\";s:1:\"N\";s:17:\"SET_LAST_MODIFIED\";s:1:\"N\";s:20:\"SET_META_DESCRIPTION\";s:1:\"Y\";s:17:\"SET_META_KEYWORDS\";s:1:\"Y\";s:14:\"SET_STATUS_404\";s:1:\"N\";s:9:\"SET_TITLE\";s:1:\"N\";s:8:\"SHOW_404\";s:1:\"N\";s:8:\"SORT_BY1\";s:11:\"ACTIVE_FROM\";s:8:\"SORT_BY2\";s:4:\"SORT\";s:11:\"SORT_ORDER1\";s:4:\"DESC\";s:11:\"SORT_ORDER2\";s:3:\"ASC\";s:20:\"STRICT_SECTION_CHECK\";s:1:\"N\";}'),
(1822, 's1', 'dress:main.feedback', 'myfeedback', '/index.php', 'N', NULL, 16170, 16488, 'a:6:{s:18:\"COMPONENT_TEMPLATE\";s:10:\"myfeedback\";s:8:\"EMAIL_TO\";s:12:\"test@mail.ru\";s:16:\"EVENT_MESSAGE_ID\";N;s:7:\"OK_TEXT\";s:59:\"Спасибо, ваше сообщение принято.\";s:15:\"REQUIRED_FIELDS\";a:2:{i:0;s:4:\"TELL\";i:1;s:7:\"MESSAGE\";}s:11:\"USE_CAPTCHA\";s:1:\"N\";}'),
(1823, 's1', 'bitrix:news.list', 'slider-rewiev', '/index.php', 'N', NULL, 16566, 18204, 'a:52:{s:18:\"ACTIVE_DATE_FORMAT\";s:5:\"d.m.Y\";s:18:\"ADD_SECTIONS_CHAIN\";s:1:\"N\";s:9:\"AJAX_MODE\";s:1:\"N\";s:22:\"AJAX_OPTION_ADDITIONAL\";s:0:\"\";s:19:\"AJAX_OPTION_HISTORY\";s:1:\"N\";s:16:\"AJAX_OPTION_JUMP\";s:1:\"N\";s:17:\"AJAX_OPTION_STYLE\";s:1:\"Y\";s:12:\"CACHE_FILTER\";s:1:\"N\";s:12:\"CACHE_GROUPS\";s:1:\"Y\";s:10:\"CACHE_TIME\";s:8:\"36000000\";s:10:\"CACHE_TYPE\";s:1:\"A\";s:11:\"CHECK_DATES\";s:1:\"Y\";s:18:\"COMPONENT_TEMPLATE\";s:13:\"slider-rewiev\";s:10:\"DETAIL_URL\";s:0:\"\";s:20:\"DISPLAY_BOTTOM_PAGER\";s:1:\"Y\";s:12:\"DISPLAY_DATE\";s:1:\"N\";s:12:\"DISPLAY_NAME\";s:1:\"Y\";s:15:\"DISPLAY_PICTURE\";s:1:\"N\";s:20:\"DISPLAY_PREVIEW_TEXT\";s:1:\"Y\";s:17:\"DISPLAY_TOP_PAGER\";s:1:\"N\";s:10:\"FIELD_CODE\";a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}s:11:\"FILTER_NAME\";s:0:\"\";s:24:\"HIDE_LINK_WHEN_NO_DETAIL\";s:1:\"N\";s:9:\"IBLOCK_ID\";s:1:\"5\";s:11:\"IBLOCK_TYPE\";s:13:\"slider_header\";s:25:\"INCLUDE_IBLOCK_INTO_CHAIN\";s:1:\"N\";s:19:\"INCLUDE_SUBSECTIONS\";s:1:\"Y\";s:11:\"MESSAGE_404\";s:0:\"\";s:10:\"NEWS_COUNT\";s:2:\"20\";s:22:\"PAGER_BASE_LINK_ENABLE\";s:1:\"N\";s:20:\"PAGER_DESC_NUMBERING\";s:1:\"N\";s:31:\"PAGER_DESC_NUMBERING_CACHE_TIME\";s:5:\"36000\";s:14:\"PAGER_SHOW_ALL\";s:1:\"N\";s:17:\"PAGER_SHOW_ALWAYS\";s:1:\"N\";s:14:\"PAGER_TEMPLATE\";s:8:\".default\";s:11:\"PAGER_TITLE\";s:14:\"Новости\";s:14:\"PARENT_SECTION\";s:0:\"\";s:19:\"PARENT_SECTION_CODE\";s:0:\"\";s:20:\"PREVIEW_TRUNCATE_LEN\";s:0:\"\";s:13:\"PROPERTY_CODE\";a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}s:17:\"SET_BROWSER_TITLE\";s:1:\"N\";s:17:\"SET_LAST_MODIFIED\";s:1:\"N\";s:20:\"SET_META_DESCRIPTION\";s:1:\"Y\";s:17:\"SET_META_KEYWORDS\";s:1:\"N\";s:14:\"SET_STATUS_404\";s:1:\"N\";s:9:\"SET_TITLE\";s:1:\"N\";s:8:\"SHOW_404\";s:1:\"N\";s:8:\"SORT_BY1\";s:11:\"ACTIVE_FROM\";s:8:\"SORT_BY2\";s:4:\"SORT\";s:11:\"SORT_ORDER1\";s:4:\"DESC\";s:11:\"SORT_ORDER2\";s:3:\"ASC\";s:20:\"STRICT_SECTION_CHECK\";s:1:\"N\";}');

-- --------------------------------------------------------

--
-- Структура таблицы `b_consent_agreement`
--

CREATE TABLE `b_consent_agreement` (
  `ID` int(18) NOT NULL,
  `CODE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATA_PROVIDER` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AGREEMENT_TEXT` longtext COLLATE utf8_unicode_ci,
  `LABEL_TEXT` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECURITY_CODE` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_consent_field`
--

CREATE TABLE `b_consent_field` (
  `ID` int(18) NOT NULL,
  `AGREEMENT_ID` int(18) NOT NULL,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_consent_user_consent`
--

CREATE TABLE `b_consent_user_consent` (
  `ID` int(18) NOT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `AGREEMENT_ID` int(18) NOT NULL,
  `USER_ID` int(18) DEFAULT NULL,
  `IP` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ORIGIN_ID` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ORIGINATOR_ID` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_counter_data`
--

CREATE TABLE `b_counter_data` (
  `ID` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `DATA` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_culture`
--

CREATE TABLE `b_culture` (
  `ID` int(11) NOT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(1) DEFAULT '1',
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIRECTION` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_culture`
--

INSERT INTO `b_culture` (`ID`, `CODE`, `NAME`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `DIRECTION`) VALUES
(1, 'ru', 'ru', 'DD.MM.YYYY', 'DD.MM.YYYY HH:MI:SS', '#NAME# #LAST_NAME#', 1, 'UTF-8', 'Y'),
(2, 'en', 'en', 'MM/DD/YYYY', 'MM/DD/YYYY H:MI:SS T', '#NAME# #LAST_NAME#', 0, 'UTF-8', 'Y');

-- --------------------------------------------------------

--
-- Структура таблицы `b_event`
--

CREATE TABLE `b_event` (
  `ID` int(18) NOT NULL,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_ID` int(18) DEFAULT NULL,
  `LID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `C_FIELDS` longtext COLLATE utf8_unicode_ci,
  `DATE_INSERT` datetime DEFAULT NULL,
  `DATE_EXEC` datetime DEFAULT NULL,
  `SUCCESS_EXEC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DUPLICATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_event_attachment`
--

CREATE TABLE `b_event_attachment` (
  `EVENT_ID` int(18) NOT NULL,
  `FILE_ID` int(18) NOT NULL,
  `IS_FILE_COPIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_event_log`
--

CREATE TABLE `b_event_log` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SEVERITY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `AUDIT_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `REMOTE_ADDR` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_AGENT` text COLLATE utf8_unicode_ci,
  `REQUEST_URI` text COLLATE utf8_unicode_ci,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(18) DEFAULT NULL,
  `GUEST_ID` int(18) DEFAULT NULL,
  `DESCRIPTION` mediumtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_event_log`
--

INSERT INTO `b_event_log` (`ID`, `TIMESTAMP_X`, `SEVERITY`, `AUDIT_TYPE_ID`, `MODULE_ID`, `ITEM_ID`, `REMOTE_ADDR`, `USER_AGENT`, `REQUEST_URI`, `SITE_ID`, `USER_ID`, `GUEST_ID`, `DESCRIPTION`) VALUES
(1, '2017-10-18 09:29:15', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(2, '2017-10-18 09:30:32', 'UNKNOWN', 'MENU_ADD', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&new=Y&lang=ru&site=s1&back_url=%2F%3Fbitrix_include_areas%3DY%26clear_cache%3DY&path=&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(3, '2017-10-18 09:30:43', 'UNKNOWN', 'MENU_ADD', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&new=Y&lang=ru&site=s1&back_url=%2F%3Fbitrix_include_areas%3DY%26clear_cache%3DY&path=&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(4, '2017-10-18 09:30:49', 'UNKNOWN', 'MENU_ADD', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&new=Y&lang=ru&site=s1&back_url=%2F%3Fbitrix_include_areas%3DY%26clear_cache%3DY&path=&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(5, '2017-10-18 09:31:35', 'UNKNOWN', 'MENU_ADD', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&new=Y&lang=ru&site=s1&back_url=%2F%3Fbitrix_include_areas%3DY%26clear_cache%3DY&path=&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(6, '2017-10-19 03:34:25', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(7, '2017-10-19 10:02:53', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(8, '2017-10-19 11:05:06', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(9, '2017-10-20 08:15:15', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(10, '2017-10-20 08:19:34', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(11, '2017-10-23 02:51:27', 'WARNING', 'SITE_CHECKER_ERROR', 'main', '/var/www/dress-shop', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/site_checker.php?HTTP_HOST=dress-shop&SERVER_PORT=&HTTPS=&test_start=Y&lang=ru&step=36&global_test_vars=YTozOntzOjIwOiJzaXRlX2NoZWNrZXJfc3VjY2VzcyI7czoxOiJOIjtzOjE2OiJjaGVja19ieF9jcm9udGFiIjtiOjA7czoxMDoibGFzdF92YWx1ZSI7czoxMjoiYjI0Y29ubmVjdG9yIjt9', NULL, 1, NULL, ''),
(12, '2017-10-23 02:55:00', 'WARNING', 'SITE_CHECKER_ERROR', 'main', '/var/www/dress-shop', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/site_checker.php?HTTP_HOST=dress-shop&SERVER_PORT=&HTTPS=&test_start=Y&lang=ru&step=36&global_test_vars=YTozOntzOjIwOiJzaXRlX2NoZWNrZXJfc3VjY2VzcyI7czoxOiJOIjtzOjE2OiJjaGVja19ieF9jcm9udGFiIjtiOjA7czoxMDoibGFzdF92YWx1ZSI7czoxMjoiYjI0Y29ubmVjdG9yIjt9', NULL, 1, NULL, ''),
(13, '2017-10-27 05:06:22', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(14, '2017-10-27 05:23:57', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(15, '2017-10-27 06:48:56', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit_src.php?bxsender=core_window_cdialog&lang=ru&site=ru&back_url=%2F%3Fbitrix_include_areas%3DY%26clear_cache%3DY&path=%2Fbitrix%2Ftemplates%2Fdress%2Fcomponents%2Fbitrix%2Fcatalog.top%2F.default%2Ftemplate.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:74:\"bitrix/templates/dress/components/bitrix/catalog.top/.default/template.php\";}'),
(16, '2017-10-27 09:40:40', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(17, '2017-10-27 10:09:23', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(18, '2017-11-02 02:57:42', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(19, '2017-11-02 02:58:56', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(20, '2017-11-02 08:44:58', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:19:\"include/telefon.php\";}'),
(21, '2017-11-02 09:04:09', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:23:\"include/adress-info.php\";}'),
(22, '2017-11-02 10:44:27', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(23, '2017-11-03 09:05:25', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F%3Fclear_cache_session%3DY%26bitrix_include_areas%3DN%26clear_cache%3DY%26_r%3D1140&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(24, '2017-11-03 09:07:05', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(25, '2017-11-03 09:10:54', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(26, '2017-11-03 09:32:32', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F%3Fclear_cache%3DY%26_r%3D4658&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(27, '2017-11-08 02:22:45', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2Fll%3B&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(28, '2017-11-08 02:23:45', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2Fll%3B&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(29, '2017-11-08 02:40:05', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(30, '2017-11-08 02:43:19', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2Fjj&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(31, '2017-11-08 02:44:36', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2Fjj%3Fclear_cache%3DY&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(32, '2017-11-08 03:01:28', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(33, '2017-11-08 03:09:49', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(34, '2017-11-08 03:52:40', 'UNKNOWN', 'MENU_EDIT', 'fileman', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/fileman_menu_edit.php?', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(35, '2017-11-08 03:55:08', 'UNKNOWN', 'MENU_EDIT', 'fileman', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/fileman_menu_edit.php?', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(36, '2017-11-08 03:56:20', 'UNKNOWN', 'MENU_EDIT', 'fileman', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/fileman_menu_edit.php?', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(37, '2017-11-08 03:58:01', 'UNKNOWN', 'MENU_EDIT', 'fileman', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/fileman_menu_edit.php?', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(38, '2017-11-08 04:00:03', 'UNKNOWN', 'MENU_EDIT', 'fileman', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/fileman_menu_edit.php?', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(39, '2017-11-08 04:28:15', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2F&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(40, '2017-11-08 04:28:27', 'UNKNOWN', 'MENU_EDIT', 'fileman', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/fileman_menu_edit.php?', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(41, '2017-11-08 05:21:54', 'UNKNOWN', 'MENU_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_menu_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&back_url=%2Fmm&path=%2F&name=left&siteTemplateId=dress', NULL, 1, NULL, 'a:2:{s:9:\"menu_name\";N;s:4:\"path\";b:0;}'),
(42, '2017-11-08 08:31:47', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(43, '2017-11-09 03:34:02', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(44, '2017-11-09 03:53:31', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(45, '2017-11-09 04:29:16', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(46, '2017-11-09 04:44:15', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(47, '2017-11-09 05:11:55', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(48, '2017-11-09 06:14:03', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(49, '2017-11-13 03:58:50', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(50, '2017-11-13 03:59:58', 'UNKNOWN', 'PAGE_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_file_edit.php', 's1', 1, NULL, 'a:1:{s:4:\"path\";s:9:\"index.php\";}'),
(51, '2017-11-13 04:30:20', 'UNKNOWN', 'SECTION_EDIT', 'main', 'UNKNOWN', '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '/bitrix/admin/public_folder_edit.php?bxsender=core_window_cdialog&lang=ru&site=s1&path=%2Fcatalog%2Fshoes%2Fsapogi-centi%2F&back_url=%2Fcatalog%2Fshoes%2Fsapogi-centi%2F%3Fbitrix_include_areas%3DY%26clear_cache%3DY&siteTemplateId=dress', NULL, 1, NULL, 'a:1:{s:4:\"path\";b:0;}');

-- --------------------------------------------------------

--
-- Структура таблицы `b_event_message`
--

CREATE TABLE `b_event_message` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EMAIL_FROM` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#EMAIL_FROM#',
  `EMAIL_TO` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#EMAIL_TO#',
  `SUBJECT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` longtext COLLATE utf8_unicode_ci,
  `MESSAGE_PHP` longtext COLLATE utf8_unicode_ci,
  `BODY_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `BCC` text COLLATE utf8_unicode_ci,
  `REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CC` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IN_REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRIORITY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD1_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD1_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD2_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD2_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_TEMPLATE_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ADDITIONAL_FIELD` text COLLATE utf8_unicode_ci,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_event_message`
--

INSERT INTO `b_event_message` (`ID`, `TIMESTAMP_X`, `EVENT_NAME`, `LID`, `ACTIVE`, `EMAIL_FROM`, `EMAIL_TO`, `SUBJECT`, `MESSAGE`, `MESSAGE_PHP`, `BODY_TYPE`, `BCC`, `REPLY_TO`, `CC`, `IN_REPLY_TO`, `PRIORITY`, `FIELD1_NAME`, `FIELD1_VALUE`, `FIELD2_NAME`, `FIELD2_VALUE`, `SITE_TEMPLATE_ID`, `ADDITIONAL_FIELD`, `LANGUAGE_ID`) VALUES
(1, '2017-10-16 02:36:33', 'NEW_USER', 's1', 'Y', '#DEFAULT_EMAIL_FROM#', '#DEFAULT_EMAIL_FROM#', '#SITE_NAME#: Зарегистрировался новый пользователь', 'Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНа сайте #SERVER_NAME# успешно зарегистрирован новый пользователь.\n\nДанные пользователя:\nID пользователя: #USER_ID#\n\nИмя: #NAME#\nФамилия: #LAST_NAME#\nE-Mail: #EMAIL#\n\nLogin: #LOGIN#\n\nПисьмо сгенерировано автоматически.', 'Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nНа сайте <?=$arParams[\"SERVER_NAME\"];?> успешно зарегистрирован новый пользователь.\n\nДанные пользователя:\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\n\nИмя: <?=$arParams[\"NAME\"];?>\n\nФамилия: <?=$arParams[\"LAST_NAME\"];?>\n\nE-Mail: <?=$arParams[\"EMAIL\"];?>\n\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nПисьмо сгенерировано автоматически.', 'text', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ru'),
(2, '2017-10-16 02:36:33', 'USER_INFO', 's1', 'Y', '#DEFAULT_EMAIL_FROM#', '#EMAIL#', '#SITE_NAME#: Регистрационная информация', 'Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nВы можете изменить пароль, перейдя по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=#CHECKWORD#&USER_LOGIN=#URL_LOGIN#\n\nСообщение сгенерировано автоматически.', 'Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n<?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>,\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\nСтатус профиля: <?=$arParams[\"STATUS\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nВы можете изменить пароль, перейдя по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=<?=$arParams[\"CHECKWORD\"];?>&USER_LOGIN=<?=$arParams[\"URL_LOGIN\"];?>\n\n\nСообщение сгенерировано автоматически.', 'text', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ru'),
(3, '2017-10-16 02:36:33', 'USER_PASS_REQUEST', 's1', 'Y', '#DEFAULT_EMAIL_FROM#', '#EMAIL#', '#SITE_NAME#: Запрос на смену пароля', 'Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=#CHECKWORD#&USER_LOGIN=#URL_LOGIN#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nСообщение сгенерировано автоматически.', 'Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n<?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>,\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=<?=$arParams[\"CHECKWORD\"];?>&USER_LOGIN=<?=$arParams[\"URL_LOGIN\"];?>\n\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\nСтатус профиля: <?=$arParams[\"STATUS\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nСообщение сгенерировано автоматически.', 'text', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ru'),
(4, '2017-10-16 02:36:33', 'USER_PASS_CHANGED', 's1', 'Y', '#DEFAULT_EMAIL_FROM#', '#EMAIL#', '#SITE_NAME#: Подтверждение смены пароля', 'Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nСообщение сгенерировано автоматически.', 'Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n<?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>,\n\n<?=$arParams[\"MESSAGE\"];?>\n\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"USER_ID\"];?>\n\nСтатус профиля: <?=$arParams[\"STATUS\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nСообщение сгенерировано автоматически.', 'text', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ru'),
(5, '2017-10-16 02:36:33', 'NEW_USER_CONFIRM', 's1', 'Y', '#DEFAULT_EMAIL_FROM#', '#EMAIL#', '#SITE_NAME#: Подтверждение регистрации нового пользователя', 'Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был использован при регистрации нового пользователя на сервере #SERVER_NAME#.\n\nВаш код для подтверждения регистрации: #CONFIRM_CODE#\n\nДля подтверждения регистрации перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?confirm_registration=yes&confirm_user_id=#USER_ID#&confirm_code=#CONFIRM_CODE#\n\nВы также можете ввести код для подтверждения регистрации на странице:\nhttp://#SERVER_NAME#/auth/index.php?confirm_registration=yes&confirm_user_id=#USER_ID#\n\nВнимание! Ваш профиль не будет активным, пока вы не подтвердите свою регистрацию.\n\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.', 'Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был использован при регистрации нового пользователя на сервере <?=$arParams[\"SERVER_NAME\"];?>.\n\nВаш код для подтверждения регистрации: <?=$arParams[\"CONFIRM_CODE\"];?>\n\n\nДля подтверждения регистрации перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?confirm_registration=yes&confirm_user_id=<?=$arParams[\"USER_ID\"];?>&confirm_code=<?=$arParams[\"CONFIRM_CODE\"];?>\n\n\nВы также можете ввести код для подтверждения регистрации на странице:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth/index.php?confirm_registration=yes&confirm_user_id=<?=$arParams[\"USER_ID\"];?>\n\n\nВнимание! Ваш профиль не будет активным, пока вы не подтвердите свою регистрацию.\n\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.', 'text', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ru'),
(6, '2017-10-16 02:36:33', 'USER_INVITE', 's1', 'Y', '#DEFAULT_EMAIL_FROM#', '#EMAIL#', '#SITE_NAME#: Приглашение на сайт', 'Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\nЗдравствуйте, #NAME# #LAST_NAME#!\n\nАдминистратором сайта вы добавлены в число зарегистрированных пользователей.\n\nПриглашаем Вас на наш сайт.\n\nВаша регистрационная информация:\n\nID пользователя: #ID#\nLogin: #LOGIN#\n\nРекомендуем вам сменить установленный автоматически пароль.\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth.php?change_password=yes&USER_LOGIN=#URL_LOGIN#&USER_CHECKWORD=#CHECKWORD#\n', 'Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\n\n------------------------------------------\nЗдравствуйте, <?=$arParams[\"NAME\"];?> <?=$arParams[\"LAST_NAME\"];?>!\n\nАдминистратором сайта вы добавлены в число зарегистрированных пользователей.\n\nПриглашаем Вас на наш сайт.\n\nВаша регистрационная информация:\n\nID пользователя: <?=$arParams[\"ID\"];?>\n\nLogin: <?=$arParams[\"LOGIN\"];?>\n\n\nРекомендуем вам сменить установленный автоматически пароль.\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://<?=$arParams[\"SERVER_NAME\"];?>/auth.php?change_password=yes&USER_LOGIN=<?=$arParams[\"URL_LOGIN\"];?>&USER_CHECKWORD=<?=$arParams[\"CHECKWORD\"];?>\n\n', 'text', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ru'),
(7, '2017-10-19 11:20:08', 'FEEDBACK_FORM', 's1', 'Y', '#DEFAULT_EMAIL_FROM#', '#EMAIL_TO#', '#SITE_NAME#: Сообщение из формы обратной связи', 'Информационное сообщение сайта #SITE_NAME#\r\n------------------------------------------\r\n\r\nВам было отправлено сообщение через форму обратной связи\r\n\r\nАвтор: #AUTHOR#\r\n____________________________\r\nE-mail автора: #AUTHOR_EMAIL#\r\n____________________________\r\nТелефон: #TELL#\r\n____________________________\r\nТекст сообщения:\r\n#TEXT#\r\n___________________________\r\n\r\nСообщение сгенерировано автоматически.', 'Информационное сообщение сайта <?=$arParams[\"SITE_NAME\"];?>\r\n\r\n------------------------------------------\r\n\r\nВам было отправлено сообщение через форму обратной связи\r\n\r\nАвтор: <?=$arParams[\"AUTHOR\"];?>\r\n\r\n____________________________\r\nE-mail автора: <?=$arParams[\"AUTHOR_EMAIL\"];?>\r\n\r\n____________________________\r\nТелефон: <?=$arParams[\"TELL\"];?>\r\n\r\n____________________________\r\nТекст сообщения:\r\n<?=$arParams[\"TEXT\"];?>\r\n\r\n___________________________\r\n\r\nСообщение сгенерировано автоматически.', 'text', '', '', '', '', '', NULL, NULL, NULL, NULL, '', 'a:0:{}', 'ru');

-- --------------------------------------------------------

--
-- Структура таблицы `b_event_message_attachment`
--

CREATE TABLE `b_event_message_attachment` (
  `EVENT_MESSAGE_ID` int(18) NOT NULL,
  `FILE_ID` int(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_event_message_site`
--

CREATE TABLE `b_event_message_site` (
  `EVENT_MESSAGE_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_event_message_site`
--

INSERT INTO `b_event_message_site` (`EVENT_MESSAGE_ID`, `SITE_ID`) VALUES
(1, 's1'),
(2, 's1'),
(3, 's1'),
(4, 's1'),
(5, 's1'),
(6, 's1'),
(7, 's1');

-- --------------------------------------------------------

--
-- Структура таблицы `b_event_type`
--

CREATE TABLE `b_event_type` (
  `ID` int(18) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(18) NOT NULL DEFAULT '150'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_event_type`
--

INSERT INTO `b_event_type` (`ID`, `LID`, `EVENT_NAME`, `NAME`, `DESCRIPTION`, `SORT`) VALUES
(1, 'ru', 'NEW_USER', 'Зарегистрировался новый пользователь', '\n\n#USER_ID# - ID пользователя\n#LOGIN# - Логин\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#USER_IP# - IP пользователя\n#USER_HOST# - Хост пользователя\n', 1),
(2, 'ru', 'USER_INFO', 'Информация о пользователе', '\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n', 2),
(3, 'ru', 'NEW_USER_CONFIRM', 'Подтверждение регистрации нового пользователя', '\n\n\n#USER_ID# - ID пользователя\n#LOGIN# - Логин\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#USER_IP# - IP пользователя\n#USER_HOST# - Хост пользователя\n#CONFIRM_CODE# - Код подтверждения\n', 3),
(4, 'ru', 'USER_PASS_REQUEST', 'Запрос на смену пароля', '\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n', 4),
(5, 'ru', 'USER_PASS_CHANGED', 'Подтверждение смены пароля', '\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n', 5),
(6, 'ru', 'USER_INVITE', 'Приглашение на сайт нового пользователя', '#ID# - ID пользователя\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#PASSWORD# - пароль пользователя \n#CHECKWORD# - Контрольная строка для смены пароля\n#XML_ID# - ID пользователя для связи с внешними источниками\n', 6),
(7, 'ru', 'FEEDBACK_FORM', 'Отправка сообщения через форму обратной связи', '#AUTHOR# - Автор сообщения\n#AUTHOR_EMAIL# - Email автора сообщения\n#TEXT# - Текст сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма', 7),
(8, 'en', 'NEW_USER', 'New user was registered', '\n\n#USER_ID# - User ID\n#LOGIN# - Login\n#EMAIL# - EMail\n#NAME# - Name\n#LAST_NAME# - Last Name\n#USER_IP# - User IP\n#USER_HOST# - User Host\n', 1),
(9, 'en', 'USER_INFO', 'Account Information', '\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n', 2),
(10, 'en', 'NEW_USER_CONFIRM', 'New user registration confirmation', '\n\n#USER_ID# - User ID\n#LOGIN# - Login\n#EMAIL# - E-mail\n#NAME# - First name\n#LAST_NAME# - Last name\n#USER_IP# - User IP\n#USER_HOST# - User host\n#CONFIRM_CODE# - Confirmation code\n', 3),
(11, 'en', 'USER_PASS_REQUEST', 'Password Change Request', '\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n', 4),
(12, 'en', 'USER_PASS_CHANGED', 'Password Change Confirmation', '\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n', 5),
(13, 'en', 'USER_INVITE', 'Invitation of a new site user', '#ID# - User ID\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#EMAIL# - EMail\n#NAME# - Name\n#LAST_NAME# - Last Name\n#PASSWORD# - User password \n#CHECKWORD# - Password check string\n#XML_ID# - User ID to link with external data sources\n\n', 6),
(14, 'en', 'FEEDBACK_FORM', 'Sending a message using a feedback form', '#AUTHOR# - Message author\n#AUTHOR_EMAIL# - Author\'s e-mail address\n#TEXT# - Message text\n#EMAIL_FROM# - Sender\'s e-mail address\n#EMAIL_TO# - Recipient\'s e-mail address', 7);

-- --------------------------------------------------------

--
-- Структура таблицы `b_favorite`
--

CREATE TABLE `b_favorite` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `CODE_ID` int(18) DEFAULT NULL,
  `COMMON` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MENU_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_file`
--

CREATE TABLE `b_file` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HEIGHT` int(18) DEFAULT NULL,
  `WIDTH` int(18) DEFAULT NULL,
  `FILE_SIZE` bigint(20) DEFAULT NULL,
  `CONTENT_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'IMAGE',
  `SUBDIR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ORIGINAL_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HANDLER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EXTERNAL_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_file`
--

INSERT INTO `b_file` (`ID`, `TIMESTAMP_X`, `MODULE_ID`, `HEIGHT`, `WIDTH`, `FILE_SIZE`, `CONTENT_TYPE`, `SUBDIR`, `FILE_NAME`, `ORIGINAL_NAME`, `DESCRIPTION`, `HANDLER_ID`, `EXTERNAL_ID`) VALUES
(1, '2017-10-19 03:32:09', 'iblock', 640, 960, 223346, 'image/jpeg', 'iblock/607', '60798faa5c8bdd0882b982925881695c.jpg', '5.jpg', '', NULL, '687fb306a30329219984e8b970994372'),
(2, '2017-10-19 03:32:59', 'iblock', 640, 960, 161603, 'image/jpeg', 'iblock/715', '7151bbf2759001c0c299b54289a18b03.jpg', '16.jpg', '', NULL, 'e7167a86d80005347b9ac5902379d853'),
(10, '2017-10-19 08:05:29', 'iblock', 640, 960, 249078, 'image/jpeg', 'iblock/c22', 'c220898d17f053f93ee0f2915c08f33e.jpg', '18.jpg', '', NULL, '1ba418ce2ded40a3ae63d7280fe1b9ab'),
(11, '2017-10-20 03:06:46', 'iblock', 639, 960, 125899, 'image/jpeg', 'iblock/7eb', '7ebba6e3f95ea29a375e60571bd41156.jpg', '2.jpg', '', NULL, 'bf0da93f897e6606985ce2b5cd819b28'),
(14, '2017-10-20 08:39:20', 'iblock', 640, 426, 48779, 'image/jpeg', 'iblock/27b', '27bb9eede29c3191f8618deb2f5f1316.jpg', 'swimsuit.jpg', '', NULL, '51b27c4df95a8aefe188d21037d55e3a'),
(27, '2017-10-23 06:00:52', 'iblock', 225, 400, 18870, 'image/jpeg', 'iblock/d37', 'd37402a33708e867431e38a14b2d8b73.jpg', 'costumes.jpg', '', NULL, '7c1249e476d898f72b7712e33e02c474'),
(28, '2017-10-23 07:14:49', 'iblock', 266, 400, 29409, 'image/jpeg', 'iblock/8cf', '8cf4dc6e0877c85e61ed526220b30bbc.jpg', 'accessories.jpg', '', NULL, '56e750f1aad33bdea9811a209518925b'),
(30, '2017-10-23 07:24:35', 'iblock', 600, 400, 46359, 'image/jpeg', 'iblock/c97', 'c979c5b0301f9bf6da81175244087d30.jpg', 'underwear.jpg', '', NULL, '4e6d3d2c5c986cb9bde3516f572ae4c4'),
(31, '2017-10-23 07:25:30', 'iblock', 600, 400, 95631, 'image/jpeg', 'iblock/b93', 'b93f116776dbb0b37df1d92f167510ef.jpg', 'jackets.jpg', '', NULL, '58e569d25475eadf35565dfd8103d13d'),
(32, '2017-10-23 07:25:43', 'iblock', 256, 400, 39144, 'image/jpeg', 'iblock/1da', '1da61518f5515411bb5b1a933cf524b6.jpg', 'pants.jpg', '', NULL, 'de9b0c95ada0848f340d200488285689'),
(33, '2017-10-23 07:26:17', 'iblock', 302, 400, 31121, 'image/jpeg', 'iblock/b62', 'b62211fd3f7789b9aee1d203f78c8f87.jpg', 'dress.jpg', '', NULL, 'fcd95e81e552126b7897e9bff58d3149'),
(38, '2017-10-23 07:27:50', 'iblock', 300, 400, 33681, 'image/jpeg', 'iblock/57e', '57e6953f63161a72d455cd738ac83fbf.jpg', 'cardigan.jpg', '', NULL, '2ca973374e0cd0c35e5a49d7fbbb9ea3'),
(39, '2017-10-23 07:28:40', 'iblock', 265, 400, 19870, 'image/jpeg', 'iblock/74c', '74cede8856f9b4a4ee18d19fc1562471.jpg', 'skirt.jpg', '', NULL, '662a9cac1fc39efd85a81a60188d9c77'),
(40, '2017-10-23 07:34:50', 'iblock', 565, 400, 34985, 'image/jpeg', 'iblock/efc', 'efc5bd4e499bdd26cc9199be5da0f930.jpg', 'sport.jpg', '', NULL, 'c78c027fa084aca118a5690b6f987cfc'),
(41, '2017-10-23 07:35:03', 'iblock', 265, 400, 21657, 'image/jpeg', 'iblock/435', '435d3adb6cd34ab71202eebec3953015.jpg', 'jeans.jpg', '', NULL, 'e35022a72d10e826f9b1769239e67382'),
(42, '2017-10-23 07:35:18', 'iblock', 266, 400, 26230, 'image/jpeg', 'iblock/dbd', 'dbd7346844db1e5f5971b7302140a3ed.jpg', 'shorts.jpg', '', NULL, 'f0640c02c61e0569fd71ac52918a4387'),
(43, '2017-10-23 07:40:27', 'iblock', 266, 400, 32478, 'image/jpeg', 'iblock/b78', 'b78fef3c4bca9c0302d73e31dd721bd0.jpg', 'shoes.jpg', '', NULL, '90b8c815881f7ad41cf31bdfd89992a7'),
(44, '2017-10-26 10:33:46', 'iblock', 370, 250, 34441, 'image/jpeg', 'iblock/076', '076c46480a1a11a4192244a9bdad4e89.jpg', 'dress-1.jpg', '', NULL, '2ce7ccf3542e7a8aec44a13141adea84'),
(51, '2017-11-14 09:35:18', 'iblock', 426, 640, 47724, 'image/jpeg', 'iblock/651', '651acd30fbfa410395a40e9f5efbf6bd.jpg', 'shoes-1.jpg', '11', NULL, 'b674d9c236def065b9d376915dfd36ed'),
(56, '2017-11-14 09:35:18', 'iblock', 426, 640, 184084, 'image/jpeg', 'iblock/9c4', '9c45497e7c0fb974f228745b3483a784.jpg', 'shoes-7.jpg', '22', NULL, '2d880de6cab8231c7f6b586c5c8248b4'),
(57, '2017-11-14 09:35:18', 'iblock', 640, 426, 64366, 'image/jpeg', 'iblock/d96', 'd964abefa8b6b65f30397401ef7010b1.jpg', 'shoes-6.jpg', '33', NULL, 'c5194e95de5f91af4980c4cc278c9b94'),
(58, '2017-11-10 03:48:12', 'iblock', 426, 640, 184084, 'image/jpeg', 'iblock/9cf', '9cf4b5a0020a4e4b4ff8610cf9da452b.jpg', 'shoes-7.jpg', '', NULL, '4e872d6d7650482eded5acfbcee13b8f'),
(59, '2017-11-10 09:21:42', 'iblock', 640, 960, 161603, 'image/jpeg', 'iblock/bf4', 'bf4cb75cac5325c8b82f0add7e539e71.jpg', '3.jpg', '', NULL, 'd5d0d573d707af52ba123a165a7c7795'),
(60, '2017-11-10 09:22:01', 'iblock', 640, 960, 249078, 'image/jpeg', 'iblock/04b', '04ba7d75c29d568e1b59d95874ce1dc3.jpg', '4.jpg', '', NULL, 'bdc84c84a6ad67c65c07003a8d4c9fe3'),
(61, '2017-11-13 02:46:30', 'iblock', 429, 640, 55919, 'image/jpeg', 'iblock/d87', 'd87099b522a070937e8102451cefb4db.jpg', 'shoes-4.jpg', '', NULL, 'e4e3793844a537083fdfe86c2c64edf9'),
(62, '2017-11-13 02:59:35', 'iblock', 426, 640, 52968, 'image/jpeg', 'iblock/a49', 'a497b948c99b64ed1f6ce10f62b62fa7.jpg', 'shoes-5.jpg', '', NULL, '6ef3491665b64cda2337d77482d264bc'),
(63, '2017-11-13 03:00:11', 'iblock', 426, 640, 39763, 'image/jpeg', 'iblock/783', '7831fabb0809d8eaf536d10349f40a12.jpg', 'shoes-3.jpg', '', NULL, 'b5ce759b9295e5e92fc9e1017ca6bbc4'),
(64, '2017-11-14 09:42:29', 'iblock', 426, 640, 184084, 'image/jpeg', 'iblock/a53', 'a53812bcb8ec0f3c8dd6f65412df30a1.jpg', 'shoes-7.jpg', '', NULL, '7c87624f00772e1434a1da954a3b685d'),
(65, '2017-11-14 09:42:57', 'iblock', 640, 426, 64366, 'image/jpeg', 'iblock/b7c', 'b7c2a07bc1bb5cb7b980cee098c47e74.jpg', 'shoes-6.jpg', '', NULL, 'e8f9d8325fb743aa58830c92b0225592'),
(66, '2017-11-14 09:43:44', 'iblock', 427, 640, 55506, 'image/jpeg', 'iblock/5cd', '5cd74fe55bd9bcc8bb19affe98180163.jpg', 'shoes-2.jpg', '', NULL, '6b26cc09ecba06116ebd7238d4e2f6c4'),
(67, '2017-11-14 09:43:48', 'iblock', 426, 640, 52968, 'image/jpeg', 'iblock/353', '3532eb5815c120e019386ece84de3d69.jpg', 'shoes-5.jpg', '', NULL, 'd7b0d082f799d21c7a61f66b14e0ee8b'),
(68, '2017-11-14 09:44:00', 'iblock', 426, 640, 47724, 'image/jpeg', 'iblock/d43', 'd4302d388cc7689ed5a453b704bc2276.jpg', 'shoes-1.jpg', '', NULL, 'b939005cb2de75b0256aa1c5c945ade3');

-- --------------------------------------------------------

--
-- Структура таблицы `b_file_search`
--

CREATE TABLE `b_file_search` (
  `ID` int(11) NOT NULL,
  `SESS_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `F_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `B_DIR` int(11) NOT NULL DEFAULT '0',
  `F_SIZE` int(11) NOT NULL DEFAULT '0',
  `F_TIME` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_filters`
--

CREATE TABLE `b_filters` (
  `ID` int(18) NOT NULL,
  `USER_ID` int(18) DEFAULT NULL,
  `FILTER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FIELDS` text COLLATE utf8_unicode_ci NOT NULL,
  `COMMON` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRESET` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRESET_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(18) DEFAULT NULL,
  `SORT_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_finder_dest`
--

CREATE TABLE `b_finder_dest` (
  `USER_ID` int(11) NOT NULL,
  `CODE` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_USER_ID` int(11) DEFAULT NULL,
  `CODE_TYPE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTEXT` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_USE_DATE` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_geoip_handlers`
--

CREATE TABLE `b_geoip_handlers` (
  `ID` int(11) NOT NULL,
  `SORT` int(10) NOT NULL DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `CLASS_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONFIG` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_geoip_handlers`
--

INSERT INTO `b_geoip_handlers` (`ID`, `SORT`, `ACTIVE`, `CLASS_NAME`, `CONFIG`) VALUES
(1, 100, 'N', '\\Bitrix\\Main\\Service\\GeoIp\\MaxMind', NULL),
(2, 110, 'Y', '\\Bitrix\\Main\\Service\\GeoIp\\SypexGeo', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_group`
--

CREATE TABLE `b_group` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `ANONYMOUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECURITY_POLICY` text COLLATE utf8_unicode_ci,
  `STRING_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_group`
--

INSERT INTO `b_group` (`ID`, `TIMESTAMP_X`, `ACTIVE`, `C_SORT`, `ANONYMOUS`, `NAME`, `DESCRIPTION`, `SECURITY_POLICY`, `STRING_ID`) VALUES
(1, '2017-10-16 02:36:19', 'Y', 1, 'N', 'Администраторы', 'Полный доступ к управлению сайтом.', NULL, NULL),
(2, '2017-10-16 02:36:19', 'Y', 2, 'Y', 'Все пользователи (в том числе неавторизованные)', 'Все пользователи, включая неавторизованных.', NULL, NULL),
(3, '2017-10-16 02:36:19', 'Y', 3, 'N', 'Пользователи, имеющие право голосовать за рейтинг', 'В эту группу пользователи добавляются автоматически.', NULL, 'RATING_VOTE'),
(4, '2017-10-16 02:36:19', 'Y', 4, 'N', 'Пользователи имеющие право голосовать за авторитет', 'В эту группу пользователи добавляются автоматически.', NULL, 'RATING_VOTE_AUTHORITY');

-- --------------------------------------------------------

--
-- Структура таблицы `b_group_collection_task`
--

CREATE TABLE `b_group_collection_task` (
  `GROUP_ID` int(11) NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  `COLLECTION_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_group_subordinate`
--

CREATE TABLE `b_group_subordinate` (
  `ID` int(18) NOT NULL,
  `AR_SUBGROUP_ID` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_group_task`
--

CREATE TABLE `b_group_task` (
  `GROUP_ID` int(18) NOT NULL,
  `TASK_ID` int(18) NOT NULL,
  `EXTERNAL_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_hlblock_entity`
--

CREATE TABLE `b_hlblock_entity` (
  `ID` int(11) UNSIGNED NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `TABLE_NAME` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_hlblock_entity_lang`
--

CREATE TABLE `b_hlblock_entity_lang` (
  `ID` int(11) UNSIGNED NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_hlblock_entity_rights`
--

CREATE TABLE `b_hlblock_entity_rights` (
  `ID` int(11) UNSIGNED NOT NULL,
  `HL_ID` int(11) UNSIGNED NOT NULL,
  `TASK_ID` int(11) UNSIGNED NOT NULL,
  `ACCESS_CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_hot_keys`
--

CREATE TABLE `b_hot_keys` (
  `ID` int(18) NOT NULL,
  `KEYS_STRING` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_ID` int(18) NOT NULL,
  `USER_ID` int(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_hot_keys`
--

INSERT INTO `b_hot_keys` (`ID`, `KEYS_STRING`, `CODE_ID`, `USER_ID`) VALUES
(1, 'Ctrl+Alt+85', 139, 0),
(2, 'Ctrl+Alt+80', 17, 0),
(3, 'Ctrl+Alt+70', 120, 0),
(4, 'Ctrl+Alt+68', 117, 0),
(5, 'Ctrl+Alt+81', 3, 0),
(6, 'Ctrl+Alt+75', 106, 0),
(7, 'Ctrl+Alt+79', 133, 0),
(8, 'Ctrl+Alt+70', 121, 0),
(9, 'Ctrl+Alt+69', 118, 0),
(10, 'Ctrl+Shift+83', 87, 0),
(11, 'Ctrl+Shift+88', 88, 0),
(12, 'Ctrl+Shift+76', 89, 0),
(13, 'Ctrl+Alt+85', 139, 1),
(14, 'Ctrl+Alt+80', 17, 1),
(15, 'Ctrl+Alt+70', 120, 1),
(16, 'Ctrl+Alt+68', 117, 1),
(17, 'Ctrl+Alt+81', 3, 1),
(18, 'Ctrl+Alt+75', 106, 1),
(19, 'Ctrl+Alt+79', 133, 1),
(20, 'Ctrl+Alt+70', 121, 1),
(21, 'Ctrl+Alt+69', 118, 1),
(22, 'Ctrl+Shift+83', 87, 1),
(23, 'Ctrl+Shift+88', 88, 1),
(24, 'Ctrl+Shift+76', 89, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `b_hot_keys_code`
--

CREATE TABLE `b_hot_keys_code` (
  `ID` int(18) NOT NULL,
  `CLASS_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMMENTS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE_OBJ` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_CUSTOM` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_hot_keys_code`
--

INSERT INTO `b_hot_keys_code` (`ID`, `CLASS_NAME`, `CODE`, `NAME`, `COMMENTS`, `TITLE_OBJ`, `URL`, `IS_CUSTOM`) VALUES
(3, 'CAdminTabControl', 'NextTab();', 'HK_DB_CADMINTC', 'HK_DB_CADMINTC_C', 'tab-container', '', 0),
(5, 'btn_new', 'var d=BX (\'btn_new\'); if (d) location.href = d.href;', 'HK_DB_BUT_ADD', 'HK_DB_BUT_ADD_C', 'btn_new', '', 0),
(6, 'btn_excel', 'var d=BX(\'btn_excel\'); if (d) location.href = d.href;', 'HK_DB_BUT_EXL', 'HK_DB_BUT_EXL_C', 'btn_excel', '', 0),
(7, 'btn_settings', 'var d=BX(\'btn_settings\'); if (d) location.href = d.href;', 'HK_DB_BUT_OPT', 'HK_DB_BUT_OPT_C', 'btn_settings', '', 0),
(8, 'btn_list', 'var d=BX(\'btn_list\'); if (d) location.href = d.href;', 'HK_DB_BUT_LST', 'HK_DB_BUT_LST_C', 'btn_list', '', 0),
(9, 'Edit_Save_Button', 'var d=BX .findChild(document, {attribute: {\'name\': \'save\'}}, true );  if (d) d.click();', 'HK_DB_BUT_SAVE', 'HK_DB_BUT_SAVE_C', 'Edit_Save_Button', '', 0),
(10, 'btn_delete', 'var d=BX(\'btn_delete\'); if (d) location.href = d.href;', 'HK_DB_BUT_DEL', 'HK_DB_BUT_DEL_C', 'btn_delete', '', 0),
(12, 'CAdminFilter', 'var d=BX .findChild(document, {attribute: {\'name\': \'find\'}}, true ); if (d) d.focus();', 'HK_DB_FLT_FND', 'HK_DB_FLT_FND_C', 'find', '', 0),
(13, 'CAdminFilter', 'var d=BX .findChild(document, {attribute: {\'name\': \'set_filter\'}}, true );  if (d) d.click();', 'HK_DB_FLT_BUT_F', 'HK_DB_FLT_BUT_F_C', 'set_filter', '', 0),
(14, 'CAdminFilter', 'var d=BX .findChild(document, {attribute: {\'name\': \'del_filter\'}}, true );  if (d) d.click();', 'HK_DB_FLT_BUT_CNL', 'HK_DB_FLT_BUT_CNL_C', 'del_filter', '', 0),
(15, 'bx-panel-admin-button-help-icon-id', 'var d=BX(\'bx-panel-admin-button-help-icon-id\'); if (d) location.href = d.href;', 'HK_DB_BUT_HLP', 'HK_DB_BUT_HLP_C', 'bx-panel-admin-button-help-icon-id', '', 0),
(17, 'Global', 'BXHotKeys.ShowSettings();', 'HK_DB_SHW_L', 'HK_DB_SHW_L_C', 'bx-panel-hotkeys', '', 0),
(19, 'Edit_Apply_Button', 'var d=BX .findChild(document, {attribute: {\'name\': \'apply\'}}, true );  if (d) d.click();', 'HK_DB_BUT_APPL', 'HK_DB_BUT_APPL_C', 'Edit_Apply_Button', '', 0),
(20, 'Edit_Cancel_Button', 'var d=BX .findChild(document, {attribute: {\'name\': \'cancel\'}}, true );  if (d) d.click();', 'HK_DB_BUT_CANCEL', 'HK_DB_BUT_CANCEL_C', 'Edit_Cancel_Button', '', 0),
(54, 'top_panel_org_fav', '', '-=AUTONAME=-', NULL, 'top_panel_org_fav', NULL, 0),
(55, 'top_panel_module_settings', '', '-=AUTONAME=-', NULL, 'top_panel_module_settings', '', 0),
(56, 'top_panel_interface_settings', '', '-=AUTONAME=-', NULL, 'top_panel_interface_settings', '', 0),
(57, 'top_panel_help', '', '-=AUTONAME=-', NULL, 'top_panel_help', '', 0),
(58, 'top_panel_bizproc_tasks', '', '-=AUTONAME=-', NULL, 'top_panel_bizproc_tasks', '', 0),
(59, 'top_panel_add_fav', '', '-=AUTONAME=-', NULL, 'top_panel_add_fav', NULL, 0),
(60, 'top_panel_create_page', '', '-=AUTONAME=-', NULL, 'top_panel_create_page', '', 0),
(62, 'top_panel_create_folder', '', '-=AUTONAME=-', NULL, 'top_panel_create_folder', '', 0),
(63, 'top_panel_edit_page', '', '-=AUTONAME=-', NULL, 'top_panel_edit_page', '', 0),
(64, 'top_panel_page_prop', '', '-=AUTONAME=-', NULL, 'top_panel_page_prop', '', 0),
(65, 'top_panel_edit_page_html', '', '-=AUTONAME=-', NULL, 'top_panel_edit_page_html', '', 0),
(67, 'top_panel_edit_page_php', '', '-=AUTONAME=-', NULL, 'top_panel_edit_page_php', '', 0),
(68, 'top_panel_del_page', '', '-=AUTONAME=-', NULL, 'top_panel_del_page', '', 0),
(69, 'top_panel_folder_prop', '', '-=AUTONAME=-', NULL, 'top_panel_folder_prop', '', 0),
(70, 'top_panel_access_folder_new', '', '-=AUTONAME=-', NULL, 'top_panel_access_folder_new', '', 0),
(71, 'main_top_panel_struct_panel', '', '-=AUTONAME=-', NULL, 'main_top_panel_struct_panel', '', 0),
(72, 'top_panel_cache_page', '', '-=AUTONAME=-', NULL, 'top_panel_cache_page', '', 0),
(73, 'top_panel_cache_comp', '', '-=AUTONAME=-', NULL, 'top_panel_cache_comp', '', 0),
(74, 'top_panel_cache_not', '', '-=AUTONAME=-', NULL, 'top_panel_cache_not', '', 0),
(75, 'top_panel_edit_mode', '', '-=AUTONAME=-', NULL, 'top_panel_edit_mode', '', 0),
(76, 'top_panel_templ_site_css', '', '-=AUTONAME=-', NULL, 'top_panel_templ_site_css', '', 0),
(77, 'top_panel_templ_templ_css', '', '-=AUTONAME=-', NULL, 'top_panel_templ_templ_css', '', 0),
(78, 'top_panel_templ_site', '', '-=AUTONAME=-', NULL, 'top_panel_templ_site', '', 0),
(81, 'top_panel_debug_time', '', '-=AUTONAME=-', NULL, 'top_panel_debug_time', '', 0),
(82, 'top_panel_debug_incl', '', '-=AUTONAME=-', NULL, 'top_panel_debug_incl', '', 0),
(83, 'top_panel_debug_sql', '', '-=AUTONAME=-', NULL, 'top_panel_debug_sql', NULL, 0),
(84, 'top_panel_debug_compr', '', '-=AUTONAME=-', NULL, 'top_panel_debug_compr', '', 0),
(85, 'MTP_SHORT_URI1', '', '-=AUTONAME=-', NULL, 'MTP_SHORT_URI1', '', 0),
(86, 'MTP_SHORT_URI_LIST', '', '-=AUTONAME=-', NULL, 'MTP_SHORT_URI_LIST', '', 0),
(87, 'FMST_PANEL_STICKER_ADD', '', '-=AUTONAME=-', NULL, 'FMST_PANEL_STICKER_ADD', '', 0),
(88, 'FMST_PANEL_STICKERS_SHOW', '', '-=AUTONAME=-', NULL, 'FMST_PANEL_STICKERS_SHOW', '', 0),
(89, 'FMST_PANEL_CUR_STICKER_LIST', '', '-=AUTONAME=-', NULL, 'FMST_PANEL_CUR_STICKER_LIST', '', 0),
(90, 'FMST_PANEL_ALL_STICKER_LIST', '', '-=AUTONAME=-', NULL, 'FMST_PANEL_ALL_STICKER_LIST', '', 0),
(91, 'top_panel_menu', 'var d=BX(\"bx-panel-menu\"); if (d) d.click();', '-=AUTONAME=-', NULL, 'bx-panel-menu', '', 0),
(92, 'top_panel_admin', 'var d=BX(\'bx-panel-admin-tab\'); if (d) location.href = d.href;', '-=AUTONAME=-', NULL, 'bx-panel-admin-tab', '', 0),
(93, 'admin_panel_site', 'var d=BX(\'bx-panel-view-tab\'); if (d) location.href = d.href;', '-=AUTONAME=-', NULL, 'bx-panel-view-tab', '', 0),
(94, 'admin_panel_admin', 'var d=BX(\'bx-panel-admin-tab\'); if (d) location.href = d.href;', '-=AUTONAME=-', NULL, 'bx-panel-admin-tab', '', 0),
(96, 'top_panel_folder_prop_new', '', '-=AUTONAME=-', NULL, 'top_panel_folder_prop_new', '', 0),
(97, 'main_top_panel_structure', '', '-=AUTONAME=-', NULL, 'main_top_panel_structure', '', 0),
(98, 'top_panel_clear_cache', '', '-=AUTONAME=-', NULL, 'top_panel_clear_cache', '', 0),
(99, 'top_panel_templ', '', '-=AUTONAME=-', NULL, 'top_panel_templ', '', 0),
(100, 'top_panel_debug', '', '-=AUTONAME=-', NULL, 'top_panel_debug', '', 0),
(101, 'MTP_SHORT_URI', '', '-=AUTONAME=-', NULL, 'MTP_SHORT_URI', '', 0),
(102, 'FMST_PANEL_STICKERS', '', '-=AUTONAME=-', NULL, 'FMST_PANEL_STICKERS', '', 0),
(103, 'top_panel_settings', '', '-=AUTONAME=-', NULL, 'top_panel_settings', '', 0),
(104, 'top_panel_fav', '', '-=AUTONAME=-', NULL, 'top_panel_fav', '', 0),
(106, 'Global', 'location.href=\'/bitrix/admin/hot_keys_list.php?lang=ru\';', 'HK_DB_SHW_HK', '', '', '', 0),
(107, 'top_panel_edit_new', '', '-=AUTONAME=-', NULL, 'top_panel_edit_new', '', 0),
(108, 'FLOW_PANEL_CREATE_WITH_WF', '', '-=AUTONAME=-', NULL, 'FLOW_PANEL_CREATE_WITH_WF', '', 0),
(109, 'FLOW_PANEL_EDIT_WITH_WF', '', '-=AUTONAME=-', NULL, 'FLOW_PANEL_EDIT_WITH_WF', '', 0),
(110, 'FLOW_PANEL_HISTORY', '', '-=AUTONAME=-', NULL, 'FLOW_PANEL_HISTORY', '', 0),
(111, 'top_panel_create_new', '', '-=AUTONAME=-', NULL, 'top_panel_create_new', '', 0),
(112, 'top_panel_create_folder_new', '', '-=AUTONAME=-', NULL, 'top_panel_create_folder_new', '', 0),
(116, 'bx-panel-toggle', '', '-=AUTONAME=-', NULL, 'bx-panel-toggle', '', 0),
(117, 'bx-panel-small-toggle', '', '-=AUTONAME=-', NULL, 'bx-panel-small-toggle', '', 0),
(118, 'bx-panel-expander', 'var d=BX(\'bx-panel-expander\'); if (d) BX.fireEvent(d, \'click\');', '-=AUTONAME=-', NULL, 'bx-panel-expander', '', 0),
(119, 'bx-panel-hider', 'var d=BX(\'bx-panel-hider\'); if (d) d.click();', '-=AUTONAME=-', NULL, 'bx-panel-hider', '', 0),
(120, 'search-textbox-input', 'var d=BX(\'search-textbox-input\'); if (d) { d.click(); d.focus();}', '-=AUTONAME=-', '', 'search', '', 0),
(121, 'bx-search-input', 'var d=BX(\'bx-search-input\'); if (d) { d.click(); d.focus(); }', '-=AUTONAME=-', '', 'bx-search-input', '', 0),
(133, 'bx-panel-logout', 'var d=BX(\'bx-panel-logout\'); if (d) location.href = d.href;', '-=AUTONAME=-', '', 'bx-panel-logout', '', 0),
(135, 'CDialog', 'var d=BX(\'cancel\'); if (d) d.click();', 'HK_DB_D_CANCEL', '', 'cancel', '', 0),
(136, 'CDialog', 'var d=BX(\'close\'); if (d) d.click();', 'HK_DB_D_CLOSE', '', 'close', '', 0),
(137, 'CDialog', 'var d=BX(\'savebtn\'); if (d) d.click();', 'HK_DB_D_SAVE', '', 'savebtn', '', 0),
(138, 'CDialog', 'var d=BX(\'btn_popup_save\'); if (d) d.click();', 'HK_DB_D_EDIT_SAVE', '', 'btn_popup_save', '', 0),
(139, 'Global', 'location.href=\'/bitrix/admin/user_admin.php?lang=\'+phpVars.LANGUAGE_ID;', 'HK_DB_SHW_U', '', '', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock`
--

CREATE TABLE `b_iblock` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IBLOCK_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIST_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CANONICAL_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PICTURE` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `RSS_TTL` int(11) NOT NULL DEFAULT '24',
  `RSS_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `RSS_FILE_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RSS_FILE_LIMIT` int(11) DEFAULT NULL,
  `RSS_FILE_DAYS` int(11) DEFAULT NULL,
  `RSS_YANDEX_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INDEX_ELEMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `INDEX_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `WORKFLOW` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `BIZPROC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SECTION_CHOOSER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RIGHTS_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_PROPERTY` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PROPERTY_INDEX` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `LAST_CONV_ELEMENT` int(11) NOT NULL DEFAULT '0',
  `SOCNET_GROUP_ID` int(18) DEFAULT NULL,
  `EDIT_FILE_BEFORE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_FILE_AFTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTIONS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENTS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock`
--

INSERT INTO `b_iblock` (`ID`, `TIMESTAMP_X`, `IBLOCK_TYPE_ID`, `LID`, `CODE`, `NAME`, `ACTIVE`, `SORT`, `LIST_PAGE_URL`, `DETAIL_PAGE_URL`, `SECTION_PAGE_URL`, `CANONICAL_PAGE_URL`, `PICTURE`, `DESCRIPTION`, `DESCRIPTION_TYPE`, `RSS_TTL`, `RSS_ACTIVE`, `RSS_FILE_ACTIVE`, `RSS_FILE_LIMIT`, `RSS_FILE_DAYS`, `RSS_YANDEX_ACTIVE`, `XML_ID`, `TMP_ID`, `INDEX_ELEMENT`, `INDEX_SECTION`, `WORKFLOW`, `BIZPROC`, `SECTION_CHOOSER`, `LIST_MODE`, `RIGHTS_MODE`, `SECTION_PROPERTY`, `PROPERTY_INDEX`, `VERSION`, `LAST_CONV_ELEMENT`, `SOCNET_GROUP_ID`, `EDIT_FILE_BEFORE`, `EDIT_FILE_AFTER`, `SECTIONS_NAME`, `SECTION_NAME`, `ELEMENTS_NAME`, `ELEMENT_NAME`) VALUES
(1, '2017-11-02 10:30:50', 'slider_header', 's1', 'slider_in_header', 'Слайдер в шапке', 'Y', 500, '#SITE_DIR#/slider_header/index.php?ID=#IBLOCK_ID#', '#SITE_DIR#/slider_header/detail.php?ID=#ELEMENT_ID#', '#SITE_DIR#/slider_header/list.php?SECTION_ID=#SECTION_ID#', '', NULL, '', 'text', 24, 'Y', 'N', NULL, NULL, 'N', NULL, NULL, 'Y', 'Y', 'N', 'N', 'L', '', 'S', 'N', 'N', 1, 0, NULL, '', '', 'Разделы', 'Раздел', 'Слайды', 'Слайд'),
(3, '2017-11-14 11:15:48', 'assortment', 's1', 'assortment', 'Каталог одежды', 'Y', 500, '#SITE_DIR#/catalog/', '#SITE_DIR#/catalog/#SECTION_CODE#/#ELEMENT_CODE#', '#SITE_DIR#/catalog/#SECTION_CODE#/', '', NULL, '', 'text', 24, 'Y', 'N', NULL, NULL, 'N', NULL, 'abe0d6853fa09e37dc0e55b450a378d6', 'Y', 'Y', 'N', 'N', 'L', '', 'S', 'Y', 'I', 1, 0, NULL, '', '', 'Разделы', 'Раздел', 'Товары', 'Товар'),
(4, '2017-11-02 09:10:12', 'dress_shop', 's1', 'shop_contacts', 'Магазин контакты', 'Y', 500, '#SITE_DIR#/dress_shop/index.php?ID=#IBLOCK_ID#', '#SITE_DIR#/dress_shop/detail.php?ID=#ELEMENT_ID#', '#SITE_DIR#/dress_shop/list.php?SECTION_ID=#SECTION_ID#', '', NULL, '', 'text', 24, 'Y', 'N', NULL, NULL, 'N', NULL, NULL, 'Y', 'Y', 'N', 'N', 'L', '', 'S', NULL, NULL, 1, 0, NULL, '', '', 'Разделы', 'Раздел', 'Магазины', 'Магазин'),
(5, '2017-11-02 10:33:38', 'slider_header', 's1', 'slider-reviews', 'Слайдер отзывов', 'Y', 500, '', '', '', '', NULL, '', 'text', 24, 'Y', 'N', NULL, NULL, 'N', NULL, NULL, 'Y', 'Y', 'N', 'N', 'L', '', 'S', 'N', 'N', 1, 0, NULL, '', '', 'Разделы', 'Раздел', 'Слайды', 'Слайд');

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_cache`
--

CREATE TABLE `b_iblock_cache` (
  `CACHE_KEY` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `CACHE` longtext COLLATE utf8_unicode_ci NOT NULL,
  `CACHE_DATE` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_element`
--

CREATE TABLE `b_iblock_element` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `IBLOCK_ID` int(11) NOT NULL DEFAULT '0',
  `IBLOCK_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `DETAIL_TEXT` longtext COLLATE utf8_unicode_ci,
  `DETAIL_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `WF_STATUS_ID` int(18) DEFAULT '1',
  `WF_PARENT_ELEMENT_ID` int(11) DEFAULT NULL,
  `WF_NEW` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WF_LOCKED_BY` int(18) DEFAULT NULL,
  `WF_DATE_LOCK` datetime DEFAULT NULL,
  `WF_COMMENTS` text COLLATE utf8_unicode_ci,
  `IN_SECTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WF_LAST_HISTORY_ID` int(11) DEFAULT NULL,
  `SHOW_COUNTER` int(18) DEFAULT NULL,
  `SHOW_COUNTER_START` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_element`
--

INSERT INTO `b_iblock_element` (`ID`, `TIMESTAMP_X`, `MODIFIED_BY`, `DATE_CREATE`, `CREATED_BY`, `IBLOCK_ID`, `IBLOCK_SECTION_ID`, `ACTIVE`, `ACTIVE_FROM`, `ACTIVE_TO`, `SORT`, `NAME`, `PREVIEW_PICTURE`, `PREVIEW_TEXT`, `PREVIEW_TEXT_TYPE`, `DETAIL_PICTURE`, `DETAIL_TEXT`, `DETAIL_TEXT_TYPE`, `SEARCHABLE_CONTENT`, `WF_STATUS_ID`, `WF_PARENT_ELEMENT_ID`, `WF_NEW`, `WF_LOCKED_BY`, `WF_DATE_LOCK`, `WF_COMMENTS`, `IN_SECTIONS`, `XML_ID`, `CODE`, `TAGS`, `TMP_ID`, `WF_LAST_HISTORY_ID`, `SHOW_COUNTER`, `SHOW_COUNTER_START`) VALUES
(1, '2017-10-19 09:32:09', 1, '2017-10-19 09:32:09', 1, 1, NULL, 'Y', NULL, NULL, 500, 'Слайд-1', 1, '', 'text', NULL, '', 'text', 'СЛАЙД-1\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '1', 'slide_1', '', '0', NULL, NULL, NULL),
(2, '2017-10-19 09:32:59', 1, '2017-10-19 09:32:59', 1, 1, NULL, 'Y', NULL, NULL, 500, 'Слайд-2', 2, '', 'text', NULL, '', 'text', 'СЛАЙД-2\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '2', 'slaid_2', '', '0', NULL, NULL, NULL),
(3, '2017-10-19 14:05:29', 1, '2017-10-19 09:34:02', 1, 1, NULL, 'Y', NULL, NULL, 500, 'Слайд-3', 10, '', 'text', NULL, '', 'text', 'СЛАЙД-3\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '3', 'slide_3', '', '0', NULL, NULL, NULL),
(4, '2017-10-20 09:06:46', 1, '2017-10-20 09:06:46', 1, 1, NULL, 'Y', NULL, NULL, 500, 'Слайд-4', 11, '', 'text', NULL, '', 'text', 'СЛАЙД-4\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '4', 'slide_4', '', '0', NULL, NULL, NULL),
(6, '2017-10-20 14:39:20', 1, '2017-10-20 14:31:17', 1, 3, 10, 'Y', NULL, NULL, 500, 'Купальник \"Глория\"', 14, '', 'text', NULL, '', 'text', 'КУПАЛЬНИК \"ГЛОРИЯ\"\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '6', 'kupalnik-gloriya', '', '0', NULL, 7, '2017-10-23 09:11:50'),
(7, '2017-11-14 15:44:00', 1, '2017-10-26 16:26:01', 1, 3, 8, 'Y', NULL, NULL, 500, 'Кроссовки \"Rio\"', 68, '', 'text', NULL, '', 'text', 'КРОССОВКИ \"RIO\"\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '7', 'krossovki-rio', '', '0', NULL, 8, '2017-10-27 10:13:37'),
(8, '2017-11-14 15:43:44', 1, '2017-10-26 16:27:24', 1, 3, 8, 'Y', NULL, NULL, 500, 'Tуфли \"Карина\"', 66, '', 'text', NULL, '', 'text', 'TУФЛИ \"КАРИНА\"\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '8', 'tufli-karina', '', '0', NULL, 6, '2017-10-27 12:34:55'),
(9, '2017-11-10 15:22:01', 1, '2017-10-26 16:33:13', 1, 3, 5, 'Y', NULL, NULL, 500, 'Платье \"Мила\"', 44, '', 'text', NULL, 'Красивое и нежное!', 'text', 'ПЛАТЬЕ \"МИЛА\"\r\n\r\nКРАСИВОЕ И НЕЖНОЕ!', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '9', 'plate-mila', '', '0', NULL, 10, '2017-10-27 11:04:19'),
(10, '2017-11-13 09:00:11', 1, '2017-11-02 10:36:48', 1, 3, 8, 'Y', NULL, NULL, 500, 'Боссоножки \"Милисса\"', 63, '', 'text', NULL, 'Женственные и утонченные!', 'text', 'БОССОНОЖКИ \"МИЛИССА\"\r\n\r\nЖЕНСТВЕННЫЕ И УТОНЧЕННЫЕ!', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '10', 'bossonozhki-milissa', '', '0', NULL, 4, '2017-11-07 09:35:27'),
(11, '2017-11-14 15:35:18', 1, '2017-11-02 10:37:27', 1, 3, 8, 'Y', NULL, NULL, 500, 'Кеды \"ALISSport\"', 61, '', 'text', 58, 'Мягкие, удобные, модные!', 'text', 'КЕДЫ \"ALISSPORT\"\r\n\r\nМЯГКИЕ, УДОБНЫЕ, МОДНЫЕ!', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '11', 'kedy-alissport', '', '0', NULL, 9, '2017-11-02 10:45:30'),
(12, '2017-11-14 15:43:48', 1, '2017-11-02 10:37:53', 1, 3, 8, 'Y', NULL, NULL, 500, 'Боссоножки \"Сильви\"', 67, '', 'text', NULL, '', 'text', 'БОССОНОЖКИ \"СИЛЬВИ\"\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '12', 'bossonozhki-silvi', '', '0', NULL, 6, '2017-11-02 11:25:59'),
(13, '2017-11-02 15:14:14', 1, '2017-11-02 15:12:28', 1, 4, NULL, 'Y', NULL, NULL, 500, 'Модный бутик \"Люварис\"', NULL, '', 'text', NULL, '', 'text', 'МОДНЫЙ БУТИК \"ЛЮВАРИС\"\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '13', '', '', '0', NULL, NULL, NULL),
(14, '2017-11-08 12:53:36', 1, '2017-11-02 16:41:03', 1, 5, NULL, 'Y', NULL, NULL, 500, 'Наталья Киркова', NULL, 'Недавно вновь открыла для себя модный бутик \"Люварис\"! Очень радует огромный ассортимент, чуткое внимание к каждому клиенту, а главное эксклюзивность! \r\n', 'text', NULL, '', 'text', 'НАТАЛЬЯ КИРКОВА\r\nНЕДАВНО ВНОВЬ ОТКРЫЛА ДЛЯ СЕБЯ МОДНЫЙ БУТИК \"ЛЮВАРИС\"! ОЧЕНЬ РАДУЕТ ОГРОМНЫЙ АССОРТИМЕНТ, ЧУТКОЕ ВНИМАНИЕ К КАЖДОМУ КЛИЕНТУ, А ГЛАВНОЕ ЭКСКЛЮЗИВНОСТЬ! \r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '14', '', '', '0', NULL, NULL, NULL),
(15, '2017-11-02 17:12:42', 1, '2017-11-02 16:42:20', 1, 5, NULL, 'Y', NULL, NULL, 500, 'Мариша Линт', NULL, 'Отличный магазин, знакома с ним больше года, качественные вещи, хорошие добрые люди сейчас это редкость , да ещё и розыгрыши устраивают!', 'text', NULL, '', 'text', 'МАРИША ЛИНТ\r\nОТЛИЧНЫЙ МАГАЗИН, ЗНАКОМА С НИМ БОЛЬШЕ ГОДА, КАЧЕСТВЕННЫЕ ВЕЩИ, ХОРОШИЕ ДОБРЫЕ ЛЮДИ СЕЙЧАС ЭТО РЕДКОСТЬ , ДА ЕЩЁ И РОЗЫГРЫШИ УСТРАИВАЮТ!\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '15', '', '', '0', NULL, NULL, NULL),
(16, '2017-11-03 09:59:20', 1, '2017-11-02 16:43:06', 1, 5, NULL, 'Y', NULL, NULL, 500, 'Иришка Листовцева', NULL, 'Магазин шикарный тут вам подберут грамотный образ и честно скажут подходит или нет , а это очень важно . Продолжайте в том же духе спасибо что вы есть!!!', 'text', NULL, '', 'text', 'ИРИШКА ЛИСТОВЦЕВА\r\nМАГАЗИН ШИКАРНЫЙ ТУТ ВАМ ПОДБЕРУТ ГРАМОТНЫЙ ОБРАЗ И ЧЕСТНО СКАЖУТ ПОДХОДИТ ИЛИ НЕТ , А ЭТО ОЧЕНЬ ВАЖНО . ПРОДОЛЖАЙТЕ В ТОМ ЖЕ ДУХЕ СПАСИБО ЧТО ВЫ ЕСТЬ!!!\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'N', '16', '', '', '0', NULL, NULL, NULL),
(17, '2017-11-14 15:42:57', 1, '2017-11-08 17:16:21', 1, 3, 8, 'Y', NULL, NULL, 500, 'Полусапоги \"Malvin\"', 65, '', 'text', NULL, '', 'text', 'ПОЛУСАПОГИ \"MALVIN\"\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '17', 'polusapogi-malvin', '', '0', NULL, 4, '2017-11-13 12:26:30'),
(18, '2017-11-14 15:42:29', 1, '2017-11-09 08:28:38', 1, 3, 8, 'Y', NULL, NULL, 500, 'Сапоги \"Centi\"', 64, '', 'text', NULL, '', 'text', 'САПОГИ \"CENTI\"\r\n\r\n', 1, NULL, NULL, NULL, NULL, NULL, 'Y', '18', 'sapogi-centi', '', '0', NULL, 5, '2017-11-09 15:46:50');

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_element_iprop`
--

CREATE TABLE `b_iblock_element_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_element_lock`
--

CREATE TABLE `b_iblock_element_lock` (
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `DATE_LOCK` datetime DEFAULT NULL,
  `LOCKED_BY` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_element_property`
--

CREATE TABLE `b_iblock_element_property` (
  `ID` int(11) NOT NULL,
  `IBLOCK_PROPERTY_ID` int(11) NOT NULL,
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  `VALUE_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `VALUE_ENUM` int(11) DEFAULT NULL,
  `VALUE_NUM` decimal(18,4) DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_element_property`
--

INSERT INTO `b_iblock_element_property` (`ID`, `IBLOCK_PROPERTY_ID`, `IBLOCK_ELEMENT_ID`, `VALUE`, `VALUE_TYPE`, `VALUE_ENUM`, `VALUE_NUM`, `DESCRIPTION`) VALUES
(1, 2, 6, '2560', 'text', NULL, '2560.0000', ''),
(7, 1, 6, '2', 'text', 2, NULL, NULL),
(8, 1, 6, '3', 'text', 3, NULL, NULL),
(9, 1, 6, '6', 'text', 6, NULL, NULL),
(10, 3, 6, '7', 'text', 7, NULL, NULL),
(14, 2, 7, '2000', 'text', NULL, '2000.0000', ''),
(17, 2, 8, '3500', 'text', NULL, '3500.0000', ''),
(30, 2, 9, '2700', 'text', NULL, '2700.0000', ''),
(43, 2, 10, '3700', 'text', NULL, '3700.0000', ''),
(52, 2, 11, '2500', 'text', NULL, '2500.0000', ''),
(57, 2, 12, '5100', 'text', NULL, '5100.0000', ''),
(78, 5, 11, '51', 'text', NULL, '51.0000', '11'),
(106, 7, 13, 'Омск, ул. Фрунзе 77', 'text', NULL, '0.0000', ''),
(107, 9, 13, '8(900)123-45-68', 'text', NULL, '8.0000', ''),
(108, 8, 13, 'пн-сб: 11:00-20:00, вс 11:00-16:00', 'text', NULL, '0.0000', ''),
(109, 10, 13, 'Анденс Ирина Игориевна', 'text', NULL, '0.0000', ''),
(110, 11, 13, '54.994923527609,73.371036240784', 'text', NULL, '54.9949', ''),
(118, 2, 17, '5300', 'text', NULL, '5300.0000', ''),
(124, 2, 18, '5100', 'text', NULL, '5100.0000', ''),
(138, 5, 11, '56', 'text', NULL, '56.0000', '22'),
(139, 5, 11, '57', 'text', NULL, '57.0000', '33'),
(161, 5, 9, '59', 'text', NULL, '59.0000', NULL),
(162, 1, 9, '3', 'text', 3, NULL, NULL),
(163, 1, 9, '4', 'text', 4, NULL, NULL),
(165, 3, 9, '7', 'text', 7, NULL, NULL),
(166, 5, 9, '60', 'text', NULL, '60.0000', ''),
(193, 5, 10, '62', 'text', NULL, '62.0000', NULL),
(197, 3, 10, '7', 'text', 7, NULL, NULL),
(198, 4, 10, '9', 'text', 9, NULL, NULL),
(199, 4, 10, '10', 'text', 10, NULL, NULL),
(200, 4, 10, '11', 'text', 11, NULL, NULL),
(201, 4, 10, '12', 'text', 12, NULL, NULL),
(202, 4, 10, '13', 'text', 13, NULL, NULL),
(205, 6, 10, '16', 'text', 16, NULL, NULL),
(206, 6, 10, '14', 'text', 14, NULL, NULL),
(214, 3, 11, '8', 'text', 8, NULL, NULL),
(215, 4, 11, '10', 'text', 10, NULL, NULL),
(216, 4, 11, '11', 'text', 11, NULL, NULL),
(218, 6, 11, '18', 'text', 18, NULL, NULL),
(219, 6, 11, '16', 'text', 16, NULL, NULL),
(221, 3, 18, '8', 'text', 8, NULL, NULL),
(222, 4, 18, '9', 'text', 9, NULL, NULL),
(223, 4, 18, '10', 'text', 10, NULL, NULL),
(224, 4, 18, '11', 'text', 11, NULL, NULL),
(225, 4, 18, '12', 'text', 12, NULL, NULL),
(226, 4, 18, '13', 'text', 13, NULL, NULL),
(229, 6, 18, '16', 'text', 16, NULL, NULL),
(230, 3, 17, '8', 'text', 8, NULL, NULL),
(231, 4, 17, '11', 'text', 11, NULL, NULL),
(232, 4, 17, '12', 'text', 12, NULL, NULL),
(233, 4, 17, '13', 'text', 13, NULL, NULL),
(234, 6, 17, '15', 'text', 15, NULL, NULL),
(235, 3, 8, '7', 'text', 7, NULL, NULL),
(236, 4, 8, '10', 'text', 10, NULL, NULL),
(237, 4, 8, '11', 'text', 11, NULL, NULL),
(239, 3, 12, '7', 'text', 7, NULL, NULL),
(240, 4, 12, '11', 'text', 11, NULL, NULL),
(241, 4, 12, '13', 'text', 13, NULL, NULL),
(243, 3, 7, '7', 'text', 7, NULL, NULL),
(244, 4, 7, '11', 'text', 11, NULL, NULL),
(245, 4, 7, '12', 'text', 12, NULL, NULL),
(246, 4, 7, '13', 'text', 13, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_element_right`
--

CREATE TABLE `b_iblock_element_right` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) NOT NULL,
  `RIGHT_ID` int(11) NOT NULL,
  `IS_INHERITED` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_fields`
--

CREATE TABLE `b_iblock_fields` (
  `IBLOCK_ID` int(18) NOT NULL,
  `FIELD_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_fields`
--

INSERT INTO `b_iblock_fields` (`IBLOCK_ID`, `FIELD_ID`, `IS_REQUIRED`, `DEFAULT_VALUE`) VALUES
(1, 'ACTIVE', 'Y', 'Y'),
(1, 'ACTIVE_FROM', 'N', ''),
(1, 'ACTIVE_TO', 'N', ''),
(1, 'CODE', 'N', 'a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(1, 'DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(1, 'DETAIL_TEXT', 'N', ''),
(1, 'DETAIL_TEXT_TYPE', 'Y', 'text'),
(1, 'DETAIL_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(1, 'IBLOCK_SECTION', 'N', 'a:1:{s:22:\"KEEP_IBLOCK_SECTION_ID\";s:1:\"N\";}'),
(1, 'LOG_ELEMENT_ADD', 'N', NULL),
(1, 'LOG_ELEMENT_DELETE', 'N', NULL),
(1, 'LOG_ELEMENT_EDIT', 'N', NULL),
(1, 'LOG_SECTION_ADD', 'N', NULL),
(1, 'LOG_SECTION_DELETE', 'N', NULL),
(1, 'LOG_SECTION_EDIT', 'N', NULL),
(1, 'NAME', 'Y', ''),
(1, 'PREVIEW_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(1, 'PREVIEW_TEXT', 'N', ''),
(1, 'PREVIEW_TEXT_TYPE', 'Y', 'text'),
(1, 'PREVIEW_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(1, 'SECTION_CODE', 'N', 'a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(1, 'SECTION_DESCRIPTION', 'N', ''),
(1, 'SECTION_DESCRIPTION_TYPE', 'Y', 'text'),
(1, 'SECTION_DESCRIPTION_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(1, 'SECTION_DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(1, 'SECTION_NAME', 'Y', ''),
(1, 'SECTION_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(1, 'SECTION_XML_ID', 'N', ''),
(1, 'SORT', 'N', '0'),
(1, 'TAGS', 'N', ''),
(1, 'XML_ID', 'Y', ''),
(1, 'XML_IMPORT_START_TIME', 'N', NULL),
(3, 'ACTIVE', 'Y', 'Y'),
(3, 'ACTIVE_FROM', 'N', ''),
(3, 'ACTIVE_TO', 'N', ''),
(3, 'CODE', 'Y', 'a:8:{s:6:\"UNIQUE\";s:1:\"Y\";s:15:\"TRANSLITERATION\";s:1:\"Y\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(3, 'DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";i:1000;s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(3, 'DETAIL_TEXT', 'N', ''),
(3, 'DETAIL_TEXT_TYPE', 'Y', 'text'),
(3, 'DETAIL_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(3, 'IBLOCK_SECTION', 'N', 'a:1:{s:22:\"KEEP_IBLOCK_SECTION_ID\";s:1:\"N\";}'),
(3, 'LOG_ELEMENT_ADD', 'N', NULL),
(3, 'LOG_ELEMENT_DELETE', 'N', NULL),
(3, 'LOG_ELEMENT_EDIT', 'N', NULL),
(3, 'LOG_SECTION_ADD', 'N', NULL),
(3, 'LOG_SECTION_DELETE', 'N', NULL),
(3, 'LOG_SECTION_EDIT', 'N', NULL),
(3, 'NAME', 'Y', ''),
(3, 'PREVIEW_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";i:250;s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(3, 'PREVIEW_TEXT', 'N', ''),
(3, 'PREVIEW_TEXT_TYPE', 'Y', 'text'),
(3, 'PREVIEW_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(3, 'SECTION_CODE', 'Y', 'a:8:{s:6:\"UNIQUE\";s:1:\"Y\";s:15:\"TRANSLITERATION\";s:1:\"Y\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(3, 'SECTION_DESCRIPTION', 'N', ''),
(3, 'SECTION_DESCRIPTION_TYPE', 'Y', 'text'),
(3, 'SECTION_DESCRIPTION_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(3, 'SECTION_DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"Y\";s:5:\"WIDTH\";i:400;s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(3, 'SECTION_NAME', 'Y', ''),
(3, 'SECTION_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"Y\";s:5:\"WIDTH\";i:400;s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(3, 'SECTION_XML_ID', 'N', ''),
(3, 'SORT', 'N', '0'),
(3, 'TAGS', 'N', ''),
(3, 'XML_ID', 'Y', ''),
(3, 'XML_IMPORT_START_TIME', 'N', NULL),
(4, 'ACTIVE', 'Y', 'Y'),
(4, 'ACTIVE_FROM', 'N', ''),
(4, 'ACTIVE_TO', 'N', ''),
(4, 'CODE', 'N', 'a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(4, 'DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(4, 'DETAIL_TEXT', 'N', ''),
(4, 'DETAIL_TEXT_TYPE', 'Y', 'text'),
(4, 'DETAIL_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(4, 'IBLOCK_SECTION', 'N', 'a:1:{s:22:\"KEEP_IBLOCK_SECTION_ID\";s:1:\"N\";}'),
(4, 'LOG_ELEMENT_ADD', 'N', NULL),
(4, 'LOG_ELEMENT_DELETE', 'N', NULL),
(4, 'LOG_ELEMENT_EDIT', 'N', NULL),
(4, 'LOG_SECTION_ADD', 'N', NULL),
(4, 'LOG_SECTION_DELETE', 'N', NULL),
(4, 'LOG_SECTION_EDIT', 'N', NULL),
(4, 'NAME', 'Y', ''),
(4, 'PREVIEW_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(4, 'PREVIEW_TEXT', 'N', ''),
(4, 'PREVIEW_TEXT_TYPE', 'Y', 'text'),
(4, 'PREVIEW_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(4, 'SECTION_CODE', 'N', 'a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(4, 'SECTION_DESCRIPTION', 'N', ''),
(4, 'SECTION_DESCRIPTION_TYPE', 'Y', 'text'),
(4, 'SECTION_DESCRIPTION_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(4, 'SECTION_DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(4, 'SECTION_NAME', 'Y', ''),
(4, 'SECTION_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(4, 'SECTION_XML_ID', 'N', ''),
(4, 'SORT', 'N', '0'),
(4, 'TAGS', 'N', ''),
(4, 'XML_ID', 'Y', ''),
(4, 'XML_IMPORT_START_TIME', 'N', NULL),
(5, 'ACTIVE', 'Y', 'Y'),
(5, 'ACTIVE_FROM', 'N', ''),
(5, 'ACTIVE_TO', 'N', ''),
(5, 'CODE', 'N', 'a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(5, 'DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(5, 'DETAIL_TEXT', 'N', ''),
(5, 'DETAIL_TEXT_TYPE', 'Y', 'text'),
(5, 'DETAIL_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(5, 'IBLOCK_SECTION', 'N', 'a:1:{s:22:\"KEEP_IBLOCK_SECTION_ID\";s:1:\"N\";}'),
(5, 'LOG_ELEMENT_ADD', 'N', NULL),
(5, 'LOG_ELEMENT_DELETE', 'N', NULL),
(5, 'LOG_ELEMENT_EDIT', 'N', NULL),
(5, 'LOG_SECTION_ADD', 'N', NULL),
(5, 'LOG_SECTION_DELETE', 'N', NULL),
(5, 'LOG_SECTION_EDIT', 'N', NULL),
(5, 'NAME', 'Y', ''),
(5, 'PREVIEW_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(5, 'PREVIEW_TEXT', 'N', ''),
(5, 'PREVIEW_TEXT_TYPE', 'Y', 'text'),
(5, 'PREVIEW_TEXT_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(5, 'SECTION_CODE', 'N', 'a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
(5, 'SECTION_DESCRIPTION', 'N', ''),
(5, 'SECTION_DESCRIPTION_TYPE', 'Y', 'text'),
(5, 'SECTION_DESCRIPTION_TYPE_ALLOW_CHANGE', 'N', 'Y'),
(5, 'SECTION_DETAIL_PICTURE', 'N', 'a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(5, 'SECTION_NAME', 'Y', ''),
(5, 'SECTION_PICTURE', 'N', 'a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
(5, 'SECTION_XML_ID', 'N', ''),
(5, 'SORT', 'N', '0'),
(5, 'TAGS', 'N', ''),
(5, 'XML_ID', 'Y', ''),
(5, 'XML_IMPORT_START_TIME', 'N', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_group`
--

CREATE TABLE `b_iblock_group` (
  `IBLOCK_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `PERMISSION` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_group`
--

INSERT INTO `b_iblock_group` (`IBLOCK_ID`, `GROUP_ID`, `PERMISSION`) VALUES
(1, 1, 'X'),
(1, 2, 'R'),
(3, 1, 'X'),
(3, 2, 'R'),
(4, 1, 'X'),
(4, 2, 'R'),
(5, 1, 'X'),
(5, 2, 'R');

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_iblock_iprop`
--

CREATE TABLE `b_iblock_iblock_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_iproperty`
--

CREATE TABLE `b_iblock_iproperty` (
  `ID` int(11) NOT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `TEMPLATE` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_messages`
--

CREATE TABLE `b_iblock_messages` (
  `IBLOCK_ID` int(18) NOT NULL,
  `MESSAGE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_TEXT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_messages`
--

INSERT INTO `b_iblock_messages` (`IBLOCK_ID`, `MESSAGE_ID`, `MESSAGE_TEXT`) VALUES
(1, 'ELEMENT_ADD', 'Добавить слайд'),
(1, 'ELEMENT_DELETE', 'Удалить слайд'),
(1, 'ELEMENT_EDIT', 'Изменить слайд'),
(1, 'ELEMENT_NAME', 'Слайд'),
(1, 'ELEMENTS_NAME', 'Слайды'),
(1, 'SECTION_ADD', 'Добавить раздел'),
(1, 'SECTION_DELETE', 'Удалить раздел'),
(1, 'SECTION_EDIT', 'Изменить раздел'),
(1, 'SECTION_NAME', 'Раздел'),
(1, 'SECTIONS_NAME', 'Разделы'),
(3, 'ELEMENT_ADD', 'Добавить товар'),
(3, 'ELEMENT_DELETE', 'Удалить товар'),
(3, 'ELEMENT_EDIT', 'Изменить товар'),
(3, 'ELEMENT_NAME', 'Товар'),
(3, 'ELEMENTS_NAME', 'Товары'),
(3, 'SECTION_ADD', 'Добавить раздел'),
(3, 'SECTION_DELETE', 'Удалить раздел'),
(3, 'SECTION_EDIT', 'Изменить раздел'),
(3, 'SECTION_NAME', 'Раздел'),
(3, 'SECTIONS_NAME', 'Разделы'),
(4, 'ELEMENT_ADD', 'Добавить магазин'),
(4, 'ELEMENT_DELETE', 'Удалить магазин'),
(4, 'ELEMENT_EDIT', 'Изменить магазин'),
(4, 'ELEMENT_NAME', 'Магазин'),
(4, 'ELEMENTS_NAME', 'Магазины'),
(4, 'SECTION_ADD', 'Добавить раздел'),
(4, 'SECTION_DELETE', 'Удалить раздел'),
(4, 'SECTION_EDIT', 'Изменить раздел'),
(4, 'SECTION_NAME', 'Раздел'),
(4, 'SECTIONS_NAME', 'Разделы'),
(5, 'ELEMENT_ADD', 'Добавить слайд'),
(5, 'ELEMENT_DELETE', 'Удалить слайд'),
(5, 'ELEMENT_EDIT', 'Изменить слайд'),
(5, 'ELEMENT_NAME', 'Слайд'),
(5, 'ELEMENTS_NAME', 'Слайды'),
(5, 'SECTION_ADD', 'Добавить раздел'),
(5, 'SECTION_DELETE', 'Удалить раздел'),
(5, 'SECTION_EDIT', 'Изменить раздел'),
(5, 'SECTION_NAME', 'Раздел'),
(5, 'SECTIONS_NAME', 'Разделы');

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_offers_tmp`
--

CREATE TABLE `b_iblock_offers_tmp` (
  `ID` int(11) UNSIGNED NOT NULL,
  `PRODUCT_IBLOCK_ID` int(11) UNSIGNED NOT NULL,
  `OFFERS_IBLOCK_ID` int(11) UNSIGNED NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_property`
--

CREATE TABLE `b_iblock_property` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IBLOCK_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` text COLLATE utf8_unicode_ci,
  `PROPERTY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `ROW_COUNT` int(11) NOT NULL DEFAULT '1',
  `COL_COUNT` int(11) NOT NULL DEFAULT '30',
  `LIST_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_TYPE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MULTIPLE_CNT` int(11) DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_IBLOCK_ID` int(18) DEFAULT NULL,
  `WITH_DESCRIPTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `FILTRABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `USER_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_TYPE_SETTINGS` text COLLATE utf8_unicode_ci,
  `HINT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_property`
--

INSERT INTO `b_iblock_property` (`ID`, `TIMESTAMP_X`, `IBLOCK_ID`, `NAME`, `ACTIVE`, `SORT`, `CODE`, `DEFAULT_VALUE`, `PROPERTY_TYPE`, `ROW_COUNT`, `COL_COUNT`, `LIST_TYPE`, `MULTIPLE`, `XML_ID`, `FILE_TYPE`, `MULTIPLE_CNT`, `TMP_ID`, `LINK_IBLOCK_ID`, `WITH_DESCRIPTION`, `SEARCHABLE`, `FILTRABLE`, `IS_REQUIRED`, `VERSION`, `USER_TYPE`, `USER_TYPE_SETTINGS`, `HINT`) VALUES
(1, '2017-11-02 06:07:59', 3, 'Размеры одежды', 'Y', 300, 'CAT_SIZE', '', 'L', 1, 30, 'L', 'Y', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(2, '2017-11-09 08:43:44', 3, 'Цена', 'Y', 600, 'CAT_PRICE', '', 'N', 1, 30, 'L', 'N', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(3, '2017-11-09 08:43:44', 3, 'В наличии', 'Y', 500, 'CAT_AVAILABILITY', '', 'L', 1, 30, 'L', 'N', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(4, '2017-11-02 06:07:59', 3, 'Размер обуви', 'Y', 400, 'CAT_SIZE_SHOES', '', 'L', 1, 30, 'L', 'Y', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(5, '2017-11-14 09:20:36', 3, 'Фото', 'Y', 100, 'CAT_DETAIL_PHOTO', '', 'F', 1, 30, 'L', 'Y', NULL, 'jpg, gif, bmp, png, jpeg', 5, NULL, 0, 'Y', 'N', 'N', 'N', 1, NULL, NULL, ''),
(6, '2017-11-02 06:11:09', 3, 'Цвет', 'Y', 200, 'CAT_COLOR', '', 'L', 1, 30, 'L', 'Y', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(7, '2017-11-02 09:09:12', 4, 'Адрес магазина', 'Y', 500, 'ADDRESS', '', 'S', 1, 30, 'L', 'N', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(8, '2017-11-02 09:09:12', 4, 'Часы работы', 'Y', 500, 'HOURS', '', 'S', 1, 30, 'L', 'N', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(9, '2017-11-02 09:09:12', 4, 'Контактный телефон', 'Y', 500, 'PHONE', '', 'S', 1, 30, 'L', 'N', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(10, '2017-11-02 09:09:12', 4, 'ФИО руководителя', 'Y', 500, 'SHOP_MANAGER', '', 'S', 1, 30, 'L', 'N', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, NULL, NULL, ''),
(11, '2017-11-02 09:09:12', 4, 'Координаты', 'Y', 500, 'YANDEX_MAP', NULL, 'S', 1, 30, 'L', 'N', NULL, '', 5, NULL, 0, 'N', 'N', 'N', 'N', 1, 'map_yandex', 'a:0:{}', '');

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_property_enum`
--

CREATE TABLE `b_iblock_property_enum` (
  `ID` int(11) NOT NULL,
  `PROPERTY_ID` int(11) NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_property_enum`
--

INSERT INTO `b_iblock_property_enum` (`ID`, `PROPERTY_ID`, `VALUE`, `DEF`, `SORT`, `XML_ID`, `TMP_ID`) VALUES
(1, 1, '40-42', 'N', 500, '40-42', NULL),
(2, 1, '44-46', 'N', 500, '44-46', NULL),
(3, 1, '46-48', 'N', 500, '46-48', NULL),
(4, 1, '48-50', 'N', 500, '48-50', NULL),
(5, 1, '50-52', 'N', 500, '50-52', NULL),
(6, 1, '52-54', 'N', 500, '52-54', NULL),
(7, 3, 'В наличии', 'N', 500, 'availability-yes', NULL),
(8, 3, 'Под заказ', 'N', 500, 'availability-no', NULL),
(9, 4, '36', 'N', 500, '36', NULL),
(10, 4, '37', 'N', 500, '37', NULL),
(11, 4, '38', 'N', 500, '38', NULL),
(12, 4, '39', 'N', 500, '39', NULL),
(13, 4, '40', 'N', 500, '40', NULL),
(14, 6, 'белый', 'N', 500, 'CAT_WHITE', NULL),
(15, 6, 'зеленый', 'N', 500, 'CAT_GREEN', NULL),
(16, 6, 'красный', 'N', 500, 'CAT_RED', NULL),
(17, 6, 'синий', 'N', 500, 'CAT_BLUE', NULL),
(18, 6, 'черный', 'N', 500, 'CAT_BLACK', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_right`
--

CREATE TABLE `b_iblock_right` (
  `ID` int(11) NOT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `DO_INHERIT` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  `OP_SREAD` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `OP_EREAD` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `XML_ID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_rss`
--

CREATE TABLE `b_iblock_rss` (
  `ID` int(11) NOT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  `NODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NODE_VALUE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_section`
--

CREATE TABLE `b_iblock_section` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  `IBLOCK_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `GLOBAL_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PICTURE` int(18) DEFAULT NULL,
  `LEFT_MARGIN` int(18) DEFAULT NULL,
  `RIGHT_MARGIN` int(18) DEFAULT NULL,
  `DEPTH_LEVEL` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `SOCNET_GROUP_ID` int(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_section`
--

INSERT INTO `b_iblock_section` (`ID`, `TIMESTAMP_X`, `MODIFIED_BY`, `DATE_CREATE`, `CREATED_BY`, `IBLOCK_ID`, `IBLOCK_SECTION_ID`, `ACTIVE`, `GLOBAL_ACTIVE`, `SORT`, `NAME`, `PICTURE`, `LEFT_MARGIN`, `RIGHT_MARGIN`, `DEPTH_LEVEL`, `DESCRIPTION`, `DESCRIPTION_TYPE`, `SEARCHABLE_CONTENT`, `CODE`, `XML_ID`, `TMP_ID`, `DETAIL_PICTURE`, `SOCNET_GROUP_ID`) VALUES
(1, '2017-10-23 07:25:43', 1, '2017-10-20 14:06:38', 1, 3, NULL, 'Y', 'Y', 500, 'Легинсы и брюки', 32, 11, 12, 1, '', 'text', 'ЛЕГИНСЫ И БРЮКИ\r\n', 'leginsy-i-bryuki', NULL, NULL, NULL, NULL),
(2, '2017-10-23 07:27:50', 1, '2017-10-20 14:07:01', 1, 3, NULL, 'Y', 'Y', 500, 'Кардиганы', 38, 7, 8, 1, '', 'text', 'КАРДИГАНЫ\r\n', 'kardigany', NULL, NULL, NULL, NULL),
(3, '2017-10-23 07:25:30', 1, '2017-10-20 14:07:20', 1, 3, NULL, 'Y', 'Y', 500, 'Верхняя одежда', 31, 3, 4, 1, '', 'text', 'ВЕРХНЯЯ ОДЕЖДА\r\n', 'verkhnyaya-odezhda', NULL, NULL, NULL, NULL),
(4, '2017-10-23 07:14:49', 1, '2017-10-20 14:07:33', 1, 3, NULL, 'Y', 'Y', 500, 'Аксессуары', 28, 1, 2, 1, '', 'text', 'АКСЕССУАРЫ\r\n', 'accessories', NULL, NULL, NULL, NULL),
(5, '2017-10-23 07:26:17', 1, '2017-10-20 14:07:47', 1, 3, NULL, 'Y', 'Y', 500, 'Платья и блузы', 33, 17, 18, 1, '', 'text', 'ПЛАТЬЯ И БЛУЗЫ\r\n', 'platya-i-bluzy', NULL, NULL, NULL, NULL),
(6, '2017-10-23 07:28:40', 1, '2017-10-20 14:07:57', 1, 3, NULL, 'Y', 'Y', 500, 'Юбки', 39, 23, 24, 1, '', 'text', 'ЮБКИ\r\n', 'yubki', NULL, NULL, NULL, NULL),
(7, '2017-10-23 07:35:18', 1, '2017-10-20 14:08:10', 1, 3, NULL, 'Y', 'Y', 500, 'Шорты', 42, 21, 22, 1, '', 'text', 'ШОРТЫ\r\n', 'shorty', NULL, NULL, NULL, NULL),
(8, '2017-10-23 07:40:27', 1, '2017-10-20 14:08:21', 1, 3, NULL, 'Y', 'Y', 500, 'Обувь', 43, 15, 16, 1, '', 'text', 'ОБУВЬ\r\n', 'shoes', NULL, NULL, NULL, NULL),
(9, '2017-10-23 07:34:50', 1, '2017-10-20 14:08:59', 1, 3, NULL, 'Y', 'Y', 500, 'Спортивные товары', 40, 19, 20, 1, '', 'text', 'СПОРТИВНЫЕ ТОВАРЫ\r\n', 'sportivnye-tovary', NULL, NULL, NULL, NULL),
(10, '2017-10-23 07:43:40', 1, '2017-10-20 14:09:17', 1, 3, NULL, 'Y', 'Y', 500, 'Нижнее белье', 30, 13, 14, 1, 'Нижнее белье и купальники', 'text', 'НИЖНЕЕ БЕЛЬЕ\r\nНИЖНЕЕ БЕЛЬЕ И КУПАЛЬНИКИ', 'nizhnee-bele', NULL, NULL, NULL, NULL),
(11, '2017-10-23 07:35:03', 1, '2017-10-20 14:09:26', 1, 3, NULL, 'Y', 'Y', 500, 'Джинсы', 41, 5, 6, 1, '', 'text', 'ДЖИНСЫ\r\n', 'dzhinsy', NULL, NULL, NULL, NULL),
(12, '2017-10-23 06:00:52', 1, '2017-10-20 14:09:38', 1, 3, NULL, 'Y', 'Y', 500, 'Костюмы', 27, 9, 10, 1, '', 'text', 'КОСТЮМЫ\r\n', 'kostyumy', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_section_element`
--

CREATE TABLE `b_iblock_section_element` (
  `IBLOCK_SECTION_ID` int(11) NOT NULL,
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `ADDITIONAL_PROPERTY_ID` int(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_section_element`
--

INSERT INTO `b_iblock_section_element` (`IBLOCK_SECTION_ID`, `IBLOCK_ELEMENT_ID`, `ADDITIONAL_PROPERTY_ID`) VALUES
(5, 9, NULL),
(8, 7, NULL),
(8, 8, NULL),
(8, 10, NULL),
(8, 11, NULL),
(8, 12, NULL),
(8, 17, NULL),
(8, 18, NULL),
(10, 6, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_section_iprop`
--

CREATE TABLE `b_iblock_section_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_section_property`
--

CREATE TABLE `b_iblock_section_property` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `PROPERTY_ID` int(11) NOT NULL,
  `SMART_FILTER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISPLAY_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DISPLAY_EXPANDED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILTER_HINT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_section_property`
--

INSERT INTO `b_iblock_section_property` (`IBLOCK_ID`, `SECTION_ID`, `PROPERTY_ID`, `SMART_FILTER`, `DISPLAY_TYPE`, `DISPLAY_EXPANDED`, `FILTER_HINT`) VALUES
(3, 0, 1, 'Y', 'F', 'Y', ''),
(3, 0, 2, 'Y', 'A', 'Y', ''),
(3, 0, 3, 'Y', 'F', 'Y', ''),
(3, 0, 4, 'Y', 'F', 'Y', ''),
(3, 0, 5, 'N', NULL, 'N', ''),
(3, 0, 6, 'Y', 'F', 'Y', '');

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_section_right`
--

CREATE TABLE `b_iblock_section_right` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `RIGHT_ID` int(11) NOT NULL,
  `IS_INHERITED` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_sequence`
--

CREATE TABLE `b_iblock_sequence` (
  `IBLOCK_ID` int(18) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SEQ_VALUE` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_sequence`
--

INSERT INTO `b_iblock_sequence` (`IBLOCK_ID`, `CODE`, `SEQ_VALUE`) VALUES
(3, 'PROPERTY_2', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_site`
--

CREATE TABLE `b_iblock_site` (
  `IBLOCK_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_site`
--

INSERT INTO `b_iblock_site` (`IBLOCK_ID`, `SITE_ID`) VALUES
(1, 's1'),
(3, 's1'),
(4, 's1'),
(5, 's1');

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_type`
--

CREATE TABLE `b_iblock_type` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SECTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EDIT_FILE_BEFORE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_FILE_AFTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IN_RSS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(18) NOT NULL DEFAULT '500'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_type`
--

INSERT INTO `b_iblock_type` (`ID`, `SECTIONS`, `EDIT_FILE_BEFORE`, `EDIT_FILE_AFTER`, `IN_RSS`, `SORT`) VALUES
('assortment', 'Y', '', '', 'N', 500),
('dress_shop', 'Y', '', '', 'N', 500),
('slider_header', 'Y', '', '', 'N', 500);

-- --------------------------------------------------------

--
-- Структура таблицы `b_iblock_type_lang`
--

CREATE TABLE `b_iblock_type_lang` (
  `IBLOCK_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_iblock_type_lang`
--

INSERT INTO `b_iblock_type_lang` (`IBLOCK_TYPE_ID`, `LID`, `NAME`, `SECTION_NAME`, `ELEMENT_NAME`) VALUES
('assortment', 'ru', 'Ассортимент товаров', '', ''),
('assortment', 'en', 'Assortment', '', ''),
('dress_shop', 'ru', 'Магазин', '', ''),
('dress_shop', 'en', 'Shop', '', ''),
('slider_header', 'ru', 'Слайдеры', '', ''),
('slider_header', 'en', 'Sliders', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `b_lang`
--

CREATE TABLE `b_lang` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DIR` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOC_ROOT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DOMAIN_LIMITED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SERVER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_lang`
--

INSERT INTO `b_lang` (`LID`, `SORT`, `DEF`, `ACTIVE`, `NAME`, `DIR`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `LANGUAGE_ID`, `DOC_ROOT`, `DOMAIN_LIMITED`, `SERVER_NAME`, `SITE_NAME`, `EMAIL`, `CULTURE_ID`) VALUES
('s1', 1, 'Y', 'Y', 'Сайт модной одежды', '/', NULL, NULL, NULL, NULL, NULL, 'ru', '', 'N', '', '', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `b_language`
--

CREATE TABLE `b_language` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIRECTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_language`
--

INSERT INTO `b_language` (`LID`, `SORT`, `DEF`, `ACTIVE`, `NAME`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `DIRECTION`, `CULTURE_ID`) VALUES
('en', 2, 'N', 'Y', 'English', NULL, NULL, NULL, NULL, NULL, NULL, 2),
('ru', 1, 'Y', 'Y', 'Russian', NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `b_lang_domain`
--

CREATE TABLE `b_lang_domain` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOMAIN` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_medialib_collection`
--

CREATE TABLE `b_medialib_collection` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DATE_UPDATE` datetime NOT NULL,
  `OWNER_ID` int(11) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEMS_COUNT` int(11) DEFAULT NULL,
  `ML_TYPE` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_medialib_collection_item`
--

CREATE TABLE `b_medialib_collection_item` (
  `COLLECTION_ID` int(11) NOT NULL,
  `ITEM_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_medialib_item`
--

CREATE TABLE `b_medialib_item` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_TYPE` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `SOURCE_ID` int(11) NOT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_medialib_type`
--

CREATE TABLE `b_medialib_type` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `EXT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SYSTEM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DESCRIPTION` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_medialib_type`
--

INSERT INTO `b_medialib_type` (`ID`, `NAME`, `CODE`, `EXT`, `SYSTEM`, `DESCRIPTION`) VALUES
(1, 'image_name', 'image', 'jpg,jpeg,gif,png', 'Y', 'image_desc'),
(2, 'video_name', 'video', 'flv,mp4,wmv', 'Y', 'video_desc'),
(3, 'sound_name', 'sound', 'mp3,wma,aac', 'Y', 'sound_desc');

-- --------------------------------------------------------

--
-- Структура таблицы `b_module`
--

CREATE TABLE `b_module` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_ACTIVE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_module`
--

INSERT INTO `b_module` (`ID`, `DATE_ACTIVE`) VALUES
('bitrix.sitecorporate', '2017-10-16 02:36:37'),
('bitrixcloud', '2017-10-16 02:36:38'),
('clouds', '2017-10-16 02:36:41'),
('compression', '2017-10-16 02:36:43'),
('fileman', '2017-10-16 02:36:46'),
('highloadblock', '2017-10-16 02:36:52'),
('iblock', '2017-10-16 02:37:07'),
('main', '2017-10-16 02:36:23'),
('perfmon', '2017-10-16 02:37:20'),
('search', '2017-10-16 02:37:27'),
('seo', '2017-10-16 02:37:37'),
('socialservices', '2017-10-16 02:37:43'),
('translate', '2017-10-16 02:37:44');

-- --------------------------------------------------------

--
-- Структура таблицы `b_module_group`
--

CREATE TABLE `b_module_group` (
  `ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `G_ACCESS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_module_to_module`
--

CREATE TABLE `b_module_to_module` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `FROM_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TO_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TO_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_CLASS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD_ARG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_module_to_module`
--

INSERT INTO `b_module_to_module` (`ID`, `TIMESTAMP_X`, `SORT`, `FROM_MODULE_ID`, `MESSAGE_ID`, `TO_MODULE_ID`, `TO_PATH`, `TO_CLASS`, `TO_METHOD`, `TO_METHOD_ARG`, `VERSION`) VALUES
(1, '2017-10-16 02:36:23', 100, 'iblock', 'OnIBlockPropertyBuildList', 'main', '/modules/main/tools/prop_userid.php', 'CIBlockPropertyUserID', 'GetUserTypeDescription', '', 1),
(2, '2017-10-16 02:36:23', 100, 'main', 'OnUserDelete', 'main', '/modules/main/classes/mysql/favorites.php', 'CFavorites', 'OnUserDelete', '', 1),
(3, '2017-10-16 02:36:23', 100, 'main', 'OnLanguageDelete', 'main', '/modules/main/classes/mysql/favorites.php', 'CFavorites', 'OnLanguageDelete', '', 1),
(4, '2017-10-16 02:36:23', 100, 'main', 'OnUserDelete', 'main', '', 'CUserOptions', 'OnUserDelete', '', 1),
(5, '2017-10-16 02:36:23', 100, 'main', 'OnChangeFile', 'main', '', 'CMain', 'OnChangeFileComponent', '', 1),
(6, '2017-10-16 02:36:23', 100, 'main', 'OnUserTypeRightsCheck', 'main', '', 'CUser', 'UserTypeRightsCheck', '', 1),
(7, '2017-10-16 02:36:23', 100, 'main', 'OnUserLogin', 'main', '', 'UpdateTools', 'CheckUpdates', '', 1),
(8, '2017-10-16 02:36:23', 100, 'main', 'OnModuleUpdate', 'main', '', 'UpdateTools', 'SetUpdateResult', '', 1),
(9, '2017-10-16 02:36:23', 100, 'main', 'OnUpdateCheck', 'main', '', 'UpdateTools', 'SetUpdateError', '', 1),
(10, '2017-10-16 02:36:23', 100, 'main', 'OnPanelCreate', 'main', '', 'CUndo', 'CheckNotifyMessage', '', 1),
(11, '2017-10-16 02:36:23', 100, 'main', 'OnAfterAddRating', 'main', '', 'CRatingsComponentsMain', 'OnAfterAddRating', '', 1),
(12, '2017-10-16 02:36:24', 100, 'main', 'OnAfterUpdateRating', 'main', '', 'CRatingsComponentsMain', 'OnAfterUpdateRating', '', 1),
(13, '2017-10-16 02:36:24', 100, 'main', 'OnSetRatingsConfigs', 'main', '', 'CRatingsComponentsMain', 'OnSetRatingConfigs', '', 1),
(14, '2017-10-16 02:36:24', 100, 'main', 'OnGetRatingsConfigs', 'main', '', 'CRatingsComponentsMain', 'OnGetRatingConfigs', '', 1),
(15, '2017-10-16 02:36:24', 100, 'main', 'OnGetRatingsObjects', 'main', '', 'CRatingsComponentsMain', 'OnGetRatingObject', '', 1),
(16, '2017-10-16 02:36:24', 100, 'main', 'OnGetRatingContentOwner', 'main', '', 'CRatingsComponentsMain', 'OnGetRatingContentOwner', '', 1),
(17, '2017-10-16 02:36:24', 100, 'main', 'OnAfterAddRatingRule', 'main', '', 'CRatingRulesMain', 'OnAfterAddRatingRule', '', 1),
(18, '2017-10-16 02:36:24', 100, 'main', 'OnAfterUpdateRatingRule', 'main', '', 'CRatingRulesMain', 'OnAfterUpdateRatingRule', '', 1),
(19, '2017-10-16 02:36:24', 100, 'main', 'OnGetRatingRuleObjects', 'main', '', 'CRatingRulesMain', 'OnGetRatingRuleObjects', '', 1),
(20, '2017-10-16 02:36:24', 100, 'main', 'OnGetRatingRuleConfigs', 'main', '', 'CRatingRulesMain', 'OnGetRatingRuleConfigs', '', 1),
(21, '2017-10-16 02:36:25', 100, 'main', 'OnAfterUserAdd', 'main', '', 'CRatings', 'OnAfterUserRegister', '', 1),
(22, '2017-10-16 02:36:25', 100, 'main', 'OnUserDelete', 'main', '', 'CRatings', 'OnUserDelete', '', 1),
(23, '2017-10-16 02:36:25', 100, 'main', 'OnUserDelete', 'main', '', 'CAccess', 'OnUserDelete', '', 1),
(24, '2017-10-16 02:36:25', 100, 'main', 'OnAfterGroupAdd', 'main', '', 'CGroupAuthProvider', 'OnAfterGroupAdd', '', 1),
(25, '2017-10-16 02:36:25', 100, 'main', 'OnBeforeGroupUpdate', 'main', '', 'CGroupAuthProvider', 'OnBeforeGroupUpdate', '', 1),
(26, '2017-10-16 02:36:25', 100, 'main', 'OnBeforeGroupDelete', 'main', '', 'CGroupAuthProvider', 'OnBeforeGroupDelete', '', 1),
(27, '2017-10-16 02:36:25', 100, 'main', 'OnAfterSetUserGroup', 'main', '', 'CGroupAuthProvider', 'OnAfterSetUserGroup', '', 1),
(28, '2017-10-16 02:36:25', 100, 'main', 'OnUserLogin', 'main', '', 'CGroupAuthProvider', 'OnUserLogin', '', 1),
(29, '2017-10-16 02:36:25', 100, 'main', 'OnEventLogGetAuditTypes', 'main', '', 'CEventMain', 'GetAuditTypes', '', 1),
(30, '2017-10-16 02:36:25', 100, 'main', 'OnEventLogGetAuditHandlers', 'main', '', 'CEventMain', 'MakeMainObject', '', 1),
(31, '2017-10-16 02:36:25', 100, 'perfmon', 'OnGetTableSchema', 'main', '', 'CTableSchema', 'OnGetTableSchema', '', 1),
(32, '2017-10-16 02:36:25', 100, 'sender', 'OnConnectorList', 'main', '', '\\Bitrix\\Main\\SenderEventHandler', 'onConnectorListUser', '', 1),
(33, '2017-10-16 02:36:25', 110, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeString', 'GetUserTypeDescription', '', 1),
(34, '2017-10-16 02:36:25', 120, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeInteger', 'GetUserTypeDescription', '', 1),
(35, '2017-10-16 02:36:25', 130, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeDouble', 'GetUserTypeDescription', '', 1),
(36, '2017-10-16 02:36:25', 140, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeDateTime', 'GetUserTypeDescription', '', 1),
(37, '2017-10-16 02:36:25', 145, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeDate', 'GetUserTypeDescription', '', 1),
(38, '2017-10-16 02:36:26', 150, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeBoolean', 'GetUserTypeDescription', '', 1),
(39, '2017-10-16 02:36:26', 160, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeFile', 'GetUserTypeDescription', '', 1),
(40, '2017-10-16 02:36:26', 170, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeEnum', 'GetUserTypeDescription', '', 1),
(41, '2017-10-16 02:36:26', 180, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeIBlockSection', 'GetUserTypeDescription', '', 1),
(42, '2017-10-16 02:36:26', 190, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeIBlockElement', 'GetUserTypeDescription', '', 1),
(43, '2017-10-16 02:36:26', 200, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeStringFormatted', 'GetUserTypeDescription', '', 1),
(44, '2017-10-16 02:36:26', 210, 'main', 'OnUserTypeBuildList', 'main', '', '\\Bitrix\\Main\\UrlPreview\\UrlPreviewUserType', 'getUserTypeDescription', '', 1),
(45, '2017-10-16 02:36:26', 100, 'main', 'OnBeforeEndBufferContent', 'main', '', '\\Bitrix\\Main\\Analytics\\Counter', 'onBeforeEndBufferContent', '', 1),
(46, '2017-10-16 02:36:26', 100, 'main', 'OnBeforeRestartBuffer', 'main', '', '\\Bitrix\\Main\\Analytics\\Counter', 'onBeforeRestartBuffer', '', 1),
(47, '2017-10-16 02:36:26', 100, 'disk', 'onAfterAjaxActionCreateFolderWithSharing', 'main', '', '\\Bitrix\\Main\\FinderDestTable', 'onAfterDiskAjaxAction', '', 1),
(48, '2017-10-16 02:36:26', 100, 'disk', 'onAfterAjaxActionAppendSharing', 'main', '', '\\Bitrix\\Main\\FinderDestTable', 'onAfterDiskAjaxAction', '', 1),
(49, '2017-10-16 02:36:26', 100, 'disk', 'onAfterAjaxActionChangeSharingAndRights', 'main', '', '\\Bitrix\\Main\\FinderDestTable', 'onAfterDiskAjaxAction', '', 1),
(50, '2017-10-16 02:36:26', 100, 'socialnetwork', 'OnSocNetLogDelete', 'main', '', 'CUserCounter', 'OnSocNetLogDelete', '', 1),
(51, '2017-10-16 02:36:26', 100, 'socialnetwork', 'OnSocNetLogCommentDelete', 'main', '', 'CUserCounter', 'OnSocNetLogCommentDelete', '', 1),
(52, '2017-10-16 02:36:28', 100, 'sale', 'OnSaleBasketItemSaved', 'main', '', '\\Bitrix\\Main\\Analytics\\Catalog', 'catchCatalogBasket', '', 2),
(53, '2017-10-16 02:36:28', 100, 'sale', 'OnSaleOrderSaved', 'main', '', '\\Bitrix\\Main\\Analytics\\Catalog', 'catchCatalogOrder', '', 2),
(54, '2017-10-16 02:36:28', 100, 'sale', 'OnSaleOrderPaid', 'main', '', '\\Bitrix\\Main\\Analytics\\Catalog', 'catchCatalogOrderPayment', '', 2),
(55, '2017-10-16 02:36:36', 100, 'main', 'OnBuildGlobalMenu', 'b24connector', '', '\\Bitrix\\B24Connector\\Helper', 'onBuildGlobalMenu', '', 1),
(56, '2017-10-16 02:36:36', 100, 'main', 'OnBeforeProlog', 'b24connector', '', '\\Bitrix\\B24Connector\\Helper', 'onBeforeProlog', '', 1),
(57, '2017-10-16 02:36:37', 100, 'main', 'OnBeforeProlog', 'bitrix.sitecorporate', '', 'CSiteCorporate', 'ShowPanel', '', 1),
(58, '2017-10-16 02:36:38', 100, 'main', 'OnAdminInformerInsertItems', 'bitrixcloud', '', 'CBitrixCloudCDN', 'OnAdminInformerInsertItems', '', 1),
(59, '2017-10-16 02:36:38', 100, 'main', 'OnAdminInformerInsertItems', 'bitrixcloud', '', 'CBitrixCloudBackup', 'OnAdminInformerInsertItems', '', 1),
(60, '2017-10-16 02:36:38', 100, 'mobileapp', 'OnBeforeAdminMobileMenuBuild', 'bitrixcloud', '', 'CBitrixCloudMobile', 'OnBeforeAdminMobileMenuBuild', '', 1),
(61, '2017-10-16 02:36:41', 100, 'main', 'OnEventLogGetAuditTypes', 'clouds', '', 'CCloudStorage', 'GetAuditTypes', '', 1),
(62, '2017-10-16 02:36:41', 100, 'main', 'OnBeforeProlog', 'clouds', '', 'CCloudStorage', 'OnBeforeProlog', '', 1),
(63, '2017-10-16 02:36:41', 100, 'main', 'OnAdminListDisplay', 'clouds', '', 'CCloudStorage', 'OnAdminListDisplay', '', 1),
(64, '2017-10-16 02:36:41', 100, 'main', 'OnBuildGlobalMenu', 'clouds', '', 'CCloudStorage', 'OnBuildGlobalMenu', '', 1),
(65, '2017-10-16 02:36:41', 100, 'main', 'OnFileSave', 'clouds', '', 'CCloudStorage', 'OnFileSave', '', 1),
(66, '2017-10-16 02:36:41', 100, 'main', 'OnGetFileSRC', 'clouds', '', 'CCloudStorage', 'OnGetFileSRC', '', 1),
(67, '2017-10-16 02:36:41', 100, 'main', 'OnFileCopy', 'clouds', '', 'CCloudStorage', 'OnFileCopy', '', 1),
(68, '2017-10-16 02:36:42', 100, 'main', 'OnFileDelete', 'clouds', '', 'CCloudStorage', 'OnFileDelete', '', 1),
(69, '2017-10-16 02:36:42', 100, 'main', 'OnMakeFileArray', 'clouds', '', 'CCloudStorage', 'OnMakeFileArray', '', 1),
(70, '2017-10-16 02:36:42', 100, 'main', 'OnBeforeResizeImage', 'clouds', '', 'CCloudStorage', 'OnBeforeResizeImage', '', 1),
(71, '2017-10-16 02:36:42', 100, 'main', 'OnAfterResizeImage', 'clouds', '', 'CCloudStorage', 'OnAfterResizeImage', '', 1),
(72, '2017-10-16 02:36:42', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_AmazonS3', 'GetObjectInstance', '', 1),
(73, '2017-10-16 02:36:42', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_GoogleStorage', 'GetObjectInstance', '', 1),
(74, '2017-10-16 02:36:42', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_OpenStackStorage', 'GetObjectInstance', '', 1),
(75, '2017-10-16 02:36:42', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_RackSpaceCloudFiles', 'GetObjectInstance', '', 1),
(76, '2017-10-16 02:36:42', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_ClodoRU', 'GetObjectInstance', '', 1),
(77, '2017-10-16 02:36:42', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_Selectel', 'GetObjectInstance', '', 1),
(78, '2017-10-16 02:36:42', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_HotBox', 'GetObjectInstance', '', 1),
(79, '2017-10-16 02:36:43', 1, 'main', 'OnPageStart', 'compression', '', 'CCompress', 'OnPageStart', '', 1),
(80, '2017-10-16 02:36:43', 10000, 'main', 'OnAfterEpilog', 'compression', '', 'CCompress', 'OnAfterEpilog', '', 1),
(81, '2017-10-16 02:36:46', 100, 'main', 'OnGroupDelete', 'fileman', '', 'CFileman', 'OnGroupDelete', '', 1),
(82, '2017-10-16 02:36:47', 100, 'main', 'OnPanelCreate', 'fileman', '', 'CFileman', 'OnPanelCreate', '', 1),
(83, '2017-10-16 02:36:47', 100, 'main', 'OnModuleUpdate', 'fileman', '', 'CFileman', 'OnModuleUpdate', '', 1),
(84, '2017-10-16 02:36:47', 100, 'main', 'OnModuleInstalled', 'fileman', '', 'CFileman', 'ClearComponentsListCache', '', 1),
(85, '2017-10-16 02:36:47', 100, 'iblock', 'OnIBlockPropertyBuildList', 'fileman', '', 'CIBlockPropertyMapGoogle', 'GetUserTypeDescription', '', 1),
(86, '2017-10-16 02:36:47', 100, 'iblock', 'OnIBlockPropertyBuildList', 'fileman', '', 'CIBlockPropertyMapYandex', 'GetUserTypeDescription', '', 1),
(87, '2017-10-16 02:36:47', 100, 'iblock', 'OnIBlockPropertyBuildList', 'fileman', '', 'CIBlockPropertyVideo', 'GetUserTypeDescription', '', 1),
(88, '2017-10-16 02:36:47', 100, 'main', 'OnUserTypeBuildList', 'fileman', '', 'CUserTypeVideo', 'GetUserTypeDescription', '', 1),
(89, '2017-10-16 02:36:47', 100, 'main', 'OnEventLogGetAuditTypes', 'fileman', '', 'CEventFileman', 'GetAuditTypes', '', 1),
(90, '2017-10-16 02:36:47', 100, 'main', 'OnEventLogGetAuditHandlers', 'fileman', '', 'CEventFileman', 'MakeFilemanObject', '', 1),
(91, '2017-10-16 02:36:52', 100, 'main', 'OnBeforeUserTypeAdd', 'highloadblock', '', '\\Bitrix\\Highloadblock\\HighloadBlockTable', 'OnBeforeUserTypeAdd', '', 1),
(92, '2017-10-16 02:36:52', 100, 'main', 'OnAfterUserTypeAdd', 'highloadblock', '', '\\Bitrix\\Highloadblock\\HighloadBlockTable', 'onAfterUserTypeAdd', '', 1),
(93, '2017-10-16 02:36:53', 100, 'main', 'OnBeforeUserTypeDelete', 'highloadblock', '', '\\Bitrix\\Highloadblock\\HighloadBlockTable', 'OnBeforeUserTypeDelete', '', 1),
(94, '2017-10-16 02:36:53', 100, 'main', 'OnUserTypeBuildList', 'highloadblock', '', 'CUserTypeHlblock', 'GetUserTypeDescription', '', 1),
(95, '2017-10-16 02:36:53', 100, 'iblock', 'OnIBlockPropertyBuildList', 'highloadblock', '', 'CIBlockPropertyDirectory', 'GetUserTypeDescription', '', 1),
(96, '2017-10-16 02:37:07', 100, 'main', 'OnGroupDelete', 'iblock', '', 'CIBlock', 'OnGroupDelete', '', 1),
(97, '2017-10-16 02:37:07', 100, 'main', 'OnBeforeLangDelete', 'iblock', '', 'CIBlock', 'OnBeforeLangDelete', '', 1),
(98, '2017-10-16 02:37:07', 100, 'main', 'OnLangDelete', 'iblock', '', 'CIBlock', 'OnLangDelete', '', 1),
(99, '2017-10-16 02:37:07', 100, 'main', 'OnUserTypeRightsCheck', 'iblock', '', 'CIBlockSection', 'UserTypeRightsCheck', '', 1),
(100, '2017-10-16 02:37:07', 100, 'search', 'OnReindex', 'iblock', '', 'CIBlock', 'OnSearchReindex', '', 1),
(101, '2017-10-16 02:37:07', 100, 'search', 'OnSearchGetURL', 'iblock', '', 'CIBlock', 'OnSearchGetURL', '', 1),
(102, '2017-10-16 02:37:07', 100, 'main', 'OnEventLogGetAuditTypes', 'iblock', '', 'CIBlock', 'GetAuditTypes', '', 1),
(103, '2017-10-16 02:37:07', 100, 'main', 'OnEventLogGetAuditHandlers', 'iblock', '', 'CEventIBlock', 'MakeIBlockObject', '', 1),
(104, '2017-10-16 02:37:07', 200, 'main', 'OnGetRatingContentOwner', 'iblock', '', 'CRatingsComponentsIBlock', 'OnGetRatingContentOwner', '', 1),
(105, '2017-10-16 02:37:07', 100, 'main', 'OnTaskOperationsChanged', 'iblock', '', 'CIBlockRightsStorage', 'OnTaskOperationsChanged', '', 1),
(106, '2017-10-16 02:37:07', 100, 'main', 'OnGroupDelete', 'iblock', '', 'CIBlockRightsStorage', 'OnGroupDelete', '', 1),
(107, '2017-10-16 02:37:07', 100, 'main', 'OnUserDelete', 'iblock', '', 'CIBlockRightsStorage', 'OnUserDelete', '', 1),
(108, '2017-10-16 02:37:07', 100, 'perfmon', 'OnGetTableSchema', 'iblock', '', 'iblock', 'OnGetTableSchema', '', 1),
(109, '2017-10-16 02:37:07', 100, 'sender', 'OnConnectorList', 'iblock', '', '\\Bitrix\\Iblock\\SenderEventHandler', 'onConnectorListIblock', '', 1),
(110, '2017-10-16 02:37:07', 10, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertyDate', 'GetUserTypeDescription', '', 1),
(111, '2017-10-16 02:37:08', 20, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertyDateTime', 'GetUserTypeDescription', '', 1),
(112, '2017-10-16 02:37:08', 30, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertyXmlID', 'GetUserTypeDescription', '', 1),
(113, '2017-10-16 02:37:08', 40, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertyFileMan', 'GetUserTypeDescription', '', 1),
(114, '2017-10-16 02:37:08', 50, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertyHTML', 'GetUserTypeDescription', '', 1),
(115, '2017-10-16 02:37:08', 60, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertyElementList', 'GetUserTypeDescription', '', 1),
(116, '2017-10-16 02:37:08', 70, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertySequence', 'GetUserTypeDescription', '', 1),
(117, '2017-10-16 02:37:08', 80, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertyElementAutoComplete', 'GetUserTypeDescription', '', 1),
(118, '2017-10-16 02:37:08', 90, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertySKU', 'GetUserTypeDescription', '', 1),
(119, '2017-10-16 02:37:08', 100, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockPropertySectionAutoComplete', 'GetUserTypeDescription', '', 1),
(120, '2017-10-16 02:37:21', 100, 'perfmon', 'OnGetTableSchema', 'perfmon', '', 'perfmon', 'OnGetTableSchema', '', 1),
(121, '2017-10-16 02:37:28', 100, 'main', 'OnChangePermissions', 'search', '', 'CSearch', 'OnChangeFilePermissions', '', 1),
(122, '2017-10-16 02:37:28', 100, 'main', 'OnChangeFile', 'search', '', 'CSearch', 'OnChangeFile', '', 1),
(123, '2017-10-16 02:37:28', 100, 'main', 'OnGroupDelete', 'search', '', 'CSearch', 'OnGroupDelete', '', 1),
(124, '2017-10-16 02:37:28', 100, 'main', 'OnLangDelete', 'search', '', 'CSearch', 'OnLangDelete', '', 1),
(125, '2017-10-16 02:37:28', 100, 'main', 'OnAfterUserUpdate', 'search', '', 'CSearchUser', 'OnAfterUserUpdate', '', 1),
(126, '2017-10-16 02:37:28', 100, 'main', 'OnUserDelete', 'search', '', 'CSearchUser', 'DeleteByUserID', '', 1),
(127, '2017-10-16 02:37:28', 100, 'cluster', 'OnGetTableList', 'search', '', 'search', 'OnGetTableList', '', 1),
(128, '2017-10-16 02:37:28', 100, 'perfmon', 'OnGetTableSchema', 'search', '', 'search', 'OnGetTableSchema', '', 1),
(129, '2017-10-16 02:37:29', 90, 'main', 'OnEpilog', 'search', '', 'CSearchStatistic', 'OnEpilog', '', 1),
(130, '2017-10-16 02:37:38', 100, 'main', 'OnPanelCreate', 'seo', '', 'CSeoEventHandlers', 'SeoOnPanelCreate', '', 2),
(131, '2017-10-16 02:37:38', 100, 'fileman', 'OnIncludeHTMLEditorScript', 'seo', '', 'CSeoEventHandlers', 'OnIncludeHTMLEditorScript', '', 2),
(132, '2017-10-16 02:37:38', 100, 'fileman', 'OnBeforeHTMLEditorScriptRuns', 'seo', '', 'CSeoEventHandlers', 'OnBeforeHTMLEditorScriptRuns', '', 2),
(133, '2017-10-16 02:37:38', 100, 'iblock', 'OnAfterIBlockSectionAdd', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'addSection', '', 2),
(134, '2017-10-16 02:37:38', 100, 'iblock', 'OnAfterIBlockElementAdd', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'addElement', '', 2),
(135, '2017-10-16 02:37:38', 100, 'iblock', 'OnBeforeIBlockSectionDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeDeleteSection', '', 2),
(136, '2017-10-16 02:37:38', 100, 'iblock', 'OnBeforeIBlockElementDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeDeleteElement', '', 2),
(137, '2017-10-16 02:37:38', 100, 'iblock', 'OnAfterIBlockSectionDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'deleteSection', '', 2),
(138, '2017-10-16 02:37:38', 100, 'iblock', 'OnAfterIBlockElementDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'deleteElement', '', 2),
(139, '2017-10-16 02:37:38', 100, 'iblock', 'OnBeforeIBlockSectionUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeUpdateSection', '', 2),
(140, '2017-10-16 02:37:38', 100, 'iblock', 'OnBeforeIBlockElementUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeUpdateElement', '', 2),
(141, '2017-10-16 02:37:38', 100, 'iblock', 'OnAfterIBlockSectionUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'updateSection', '', 2),
(142, '2017-10-16 02:37:38', 100, 'iblock', 'OnAfterIBlockElementUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'updateElement', '', 2),
(143, '2017-10-16 02:37:38', 100, 'forum', 'onAfterTopicAdd', 'seo', '', '\\Bitrix\\Seo\\SitemapForum', 'addTopic', '', 2),
(144, '2017-10-16 02:37:38', 100, 'forum', 'onAfterTopicUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapForum', 'updateTopic', '', 2),
(145, '2017-10-16 02:37:38', 100, 'forum', 'onAfterTopicDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapForum', 'deleteTopic', '', 2),
(146, '2017-10-16 02:37:39', 100, 'main', 'OnAdminIBlockElementEdit', 'seo', '', '\\Bitrix\\Seo\\AdvTabEngine', 'eventHandler', '', 2),
(147, '2017-10-16 02:37:39', 100, 'main', 'OnBeforeProlog', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'checkSession', '', 2),
(148, '2017-10-16 02:37:39', 100, 'sale', 'OnOrderSave', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onOrderSave', '', 2),
(149, '2017-10-16 02:37:39', 100, 'sale', 'OnBasketOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onBasketOrder', '', 2),
(150, '2017-10-16 02:37:39', 100, 'sale', 'onSalePayOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSalePayOrder', '', 2),
(151, '2017-10-16 02:37:39', 100, 'sale', 'onSaleDeductOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSaleDeductOrder', '', 2),
(152, '2017-10-16 02:37:39', 100, 'sale', 'onSaleDeliveryOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSaleDeliveryOrder', '', 2),
(153, '2017-10-16 02:37:39', 100, 'sale', 'onSaleStatusOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSaleStatusOrder', '', 2),
(154, '2017-10-16 02:37:39', 100, 'conversion', 'OnSetDayContextAttributes', 'seo', '', '\\Bitrix\\Seo\\ConversionHandler', 'onSetDayContextAttributes', '', 2),
(155, '2017-10-16 02:37:39', 100, 'conversion', 'OnGetAttributeTypes', 'seo', '', '\\Bitrix\\Seo\\ConversionHandler', 'onGetAttributeTypes', '', 2),
(156, '2017-10-16 02:37:39', 100, 'catalog', 'OnProductUpdate', 'seo', '', '\\Bitrix\\Seo\\Adv\\Auto', 'checkQuantity', '', 2),
(157, '2017-10-16 02:37:39', 100, 'catalog', 'OnProductSetAvailableUpdate', 'seo', '', '\\Bitrix\\Seo\\Adv\\Auto', 'checkQuantity', '', 2),
(158, '2017-10-16 02:37:43', 100, 'main', 'OnUserDelete', 'socialservices', '', 'CSocServAuthDB', 'OnUserDelete', '', 1),
(159, '2017-10-16 02:37:43', 100, 'timeman', 'OnAfterTMReportDailyAdd', 'socialservices', '', 'CSocServAuthDB', 'OnAfterTMReportDailyAdd', '', 1),
(160, '2017-10-16 02:37:44', 100, 'timeman', 'OnAfterTMDayStart', 'socialservices', '', 'CSocServAuthDB', 'OnAfterTMDayStart', '', 1),
(161, '2017-10-16 02:37:44', 100, 'timeman', 'OnTimeManShow', 'socialservices', '', 'CSocServEventHandlers', 'OnTimeManShow', '', 1),
(162, '2017-10-16 02:37:44', 100, 'main', 'OnFindExternalUser', 'socialservices', '', 'CSocServAuthDB', 'OnFindExternalUser', '', 1),
(163, '2017-10-16 02:37:44', 100, 'socialservices', 'OnFindSocialservicesUser', 'socialservices', '', 'CSocServAuthManager', 'checkOldUser', '', 1),
(164, '2017-10-16 02:37:44', 100, 'socialservices', 'OnFindSocialservicesUser', 'socialservices', '', 'CSocServAuthManager', 'checkAbandonedUser', '', 1),
(165, '2017-10-16 02:37:45', 100, 'main', 'OnPanelCreate', 'translate', '', 'CTranslateEventHandlers', 'TranslatOnPanelCreate', '', 1),
(166, '2017-10-16 02:41:15', 100, 'main', 'OnBeforeProlog', 'main', '/modules/main/install/wizard_sol/panel_button.php', 'CWizardSolPanel', 'ShowPanel', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `b_operation`
--

CREATE TABLE `b_operation` (
  `ID` int(18) NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BINDING` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'module'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_operation`
--

INSERT INTO `b_operation` (`ID`, `NAME`, `MODULE_ID`, `DESCRIPTION`, `BINDING`) VALUES
(1, 'edit_php', 'main', NULL, 'module'),
(2, 'view_own_profile', 'main', NULL, 'module'),
(3, 'edit_own_profile', 'main', NULL, 'module'),
(4, 'view_all_users', 'main', NULL, 'module'),
(5, 'view_groups', 'main', NULL, 'module'),
(6, 'view_tasks', 'main', NULL, 'module'),
(7, 'view_other_settings', 'main', NULL, 'module'),
(8, 'view_subordinate_users', 'main', NULL, 'module'),
(9, 'edit_subordinate_users', 'main', NULL, 'module'),
(10, 'edit_all_users', 'main', NULL, 'module'),
(11, 'edit_groups', 'main', NULL, 'module'),
(12, 'edit_tasks', 'main', NULL, 'module'),
(13, 'edit_other_settings', 'main', NULL, 'module'),
(14, 'cache_control', 'main', NULL, 'module'),
(15, 'lpa_template_edit', 'main', NULL, 'module'),
(16, 'view_event_log', 'main', NULL, 'module'),
(17, 'edit_ratings', 'main', NULL, 'module'),
(18, 'manage_short_uri', 'main', NULL, 'module'),
(19, 'fm_view_permission', 'main', NULL, 'file'),
(20, 'fm_view_file', 'main', NULL, 'file'),
(21, 'fm_view_listing', 'main', NULL, 'file'),
(22, 'fm_edit_existent_folder', 'main', NULL, 'file'),
(23, 'fm_create_new_file', 'main', NULL, 'file'),
(24, 'fm_edit_existent_file', 'main', NULL, 'file'),
(25, 'fm_create_new_folder', 'main', NULL, 'file'),
(26, 'fm_delete_file', 'main', NULL, 'file'),
(27, 'fm_delete_folder', 'main', NULL, 'file'),
(28, 'fm_edit_in_workflow', 'main', NULL, 'file'),
(29, 'fm_rename_file', 'main', NULL, 'file'),
(30, 'fm_rename_folder', 'main', NULL, 'file'),
(31, 'fm_upload_file', 'main', NULL, 'file'),
(32, 'fm_add_to_menu', 'main', NULL, 'file'),
(33, 'fm_download_file', 'main', NULL, 'file'),
(34, 'fm_lpa', 'main', NULL, 'file'),
(35, 'fm_edit_permission', 'main', NULL, 'file'),
(36, 'bitrixcloud_monitoring', 'bitrixcloud', NULL, 'module'),
(37, 'bitrixcloud_backup', 'bitrixcloud', NULL, 'module'),
(38, 'bitrixcloud_cdn', 'bitrixcloud', NULL, 'module'),
(39, 'clouds_browse', 'clouds', NULL, 'module'),
(40, 'clouds_upload', 'clouds', NULL, 'module'),
(41, 'clouds_config', 'clouds', NULL, 'module'),
(42, 'fileman_view_all_settings', 'fileman', '', 'module'),
(43, 'fileman_edit_menu_types', 'fileman', '', 'module'),
(44, 'fileman_add_element_to_menu', 'fileman', '', 'module'),
(45, 'fileman_edit_menu_elements', 'fileman', '', 'module'),
(46, 'fileman_edit_existent_files', 'fileman', '', 'module'),
(47, 'fileman_edit_existent_folders', 'fileman', '', 'module'),
(48, 'fileman_admin_files', 'fileman', '', 'module'),
(49, 'fileman_admin_folders', 'fileman', '', 'module'),
(50, 'fileman_view_permissions', 'fileman', '', 'module'),
(51, 'fileman_edit_all_settings', 'fileman', '', 'module'),
(52, 'fileman_upload_files', 'fileman', '', 'module'),
(53, 'fileman_view_file_structure', 'fileman', '', 'module'),
(54, 'fileman_install_control', 'fileman', '', 'module'),
(55, 'medialib_view_collection', 'fileman', '', 'medialib'),
(56, 'medialib_new_collection', 'fileman', '', 'medialib'),
(57, 'medialib_edit_collection', 'fileman', '', 'medialib'),
(58, 'medialib_del_collection', 'fileman', '', 'medialib'),
(59, 'medialib_access', 'fileman', '', 'medialib'),
(60, 'medialib_new_item', 'fileman', '', 'medialib'),
(61, 'medialib_edit_item', 'fileman', '', 'medialib'),
(62, 'medialib_del_item', 'fileman', '', 'medialib'),
(63, 'sticker_view', 'fileman', '', 'stickers'),
(64, 'sticker_edit', 'fileman', '', 'stickers'),
(65, 'sticker_new', 'fileman', '', 'stickers'),
(66, 'sticker_del', 'fileman', '', 'stickers'),
(67, 'hl_element_read', 'highloadblock', NULL, 'module'),
(68, 'hl_element_write', 'highloadblock', NULL, 'module'),
(69, 'hl_element_delete', 'highloadblock', NULL, 'module'),
(70, 'section_read', 'iblock', NULL, 'iblock'),
(71, 'element_read', 'iblock', NULL, 'iblock'),
(72, 'section_element_bind', 'iblock', NULL, 'iblock'),
(73, 'iblock_admin_display', 'iblock', NULL, 'iblock'),
(74, 'element_edit', 'iblock', NULL, 'iblock'),
(75, 'element_edit_price', 'iblock', NULL, 'iblock'),
(76, 'element_delete', 'iblock', NULL, 'iblock'),
(77, 'element_bizproc_start', 'iblock', NULL, 'iblock'),
(78, 'section_edit', 'iblock', NULL, 'iblock'),
(79, 'section_delete', 'iblock', NULL, 'iblock'),
(80, 'section_section_bind', 'iblock', NULL, 'iblock'),
(81, 'element_edit_any_wf_status', 'iblock', NULL, 'iblock'),
(82, 'iblock_edit', 'iblock', NULL, 'iblock'),
(83, 'iblock_delete', 'iblock', NULL, 'iblock'),
(84, 'iblock_rights_edit', 'iblock', NULL, 'iblock'),
(85, 'iblock_export', 'iblock', NULL, 'iblock'),
(86, 'section_rights_edit', 'iblock', NULL, 'iblock'),
(87, 'element_rights_edit', 'iblock', NULL, 'iblock'),
(88, 'seo_settings', 'seo', '', 'module'),
(89, 'seo_tools', 'seo', '', 'module');

-- --------------------------------------------------------

--
-- Структура таблицы `b_option`
--

CREATE TABLE `b_option` (
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_option`
--

INSERT INTO `b_option` (`MODULE_ID`, `NAME`, `VALUE`, `DESCRIPTION`, `SITE_ID`) VALUES
('main', 'rating_authority_rating', '2', NULL, NULL),
('main', 'rating_assign_rating_group_add', '1', NULL, NULL),
('main', 'rating_assign_rating_group_delete', '1', NULL, NULL),
('main', 'rating_assign_rating_group', '3', NULL, NULL),
('main', 'rating_assign_authority_group_add', '2', NULL, NULL),
('main', 'rating_assign_authority_group_delete', '2', NULL, NULL),
('main', 'rating_assign_authority_group', '4', NULL, NULL),
('main', 'rating_community_size', '1', NULL, NULL),
('main', 'rating_community_authority', '30', NULL, NULL),
('main', 'rating_vote_weight', '10', NULL, NULL),
('main', 'rating_normalization_type', 'auto', NULL, NULL),
('main', 'rating_normalization', '10', NULL, NULL),
('main', 'rating_count_vote', '10', NULL, NULL),
('main', 'rating_authority_weight_formula', 'Y', NULL, NULL),
('main', 'rating_community_last_visit', '90', NULL, NULL),
('main', 'rating_text_like_y', 'Нравится', NULL, NULL),
('main', 'rating_text_like_n', 'Не нравится', NULL, NULL),
('main', 'rating_text_like_d', 'Это нравится', NULL, NULL),
('main', 'rating_assign_type', 'auto', NULL, NULL),
('main', 'rating_vote_type', 'like', NULL, NULL),
('main', 'rating_self_vote', 'Y', NULL, NULL),
('main', 'rating_vote_show', 'Y', NULL, NULL),
('main', 'rating_vote_template', 'like', NULL, NULL),
('main', 'rating_start_authority', '3', NULL, NULL),
('main', 'PARAM_MAX_SITES', '2', NULL, NULL),
('main', 'PARAM_MAX_USERS', '0', NULL, NULL),
('main', 'distributive6', 'Y', NULL, NULL),
('main', '~new_license11_sign', 'Y', NULL, NULL),
('main', 'GROUP_DEFAULT_TASK', '1', NULL, NULL),
('main', 'vendor', '1c_bitrix', NULL, NULL),
('main', 'admin_lid', 'ru', NULL, NULL),
('main', 'update_site', 'www.bitrixsoft.com', NULL, NULL),
('main', 'update_site_ns', 'Y', NULL, NULL),
('main', 'optimize_css_files', 'Y', NULL, NULL),
('main', 'optimize_js_files', 'Y', NULL, NULL),
('main', 'admin_passwordh', 'FVkQemYUBwYtCUVcABcECgsTAQ==', NULL, NULL),
('main', 'server_uniq_id', '92614ccc2474220a2013db41ade04aba', NULL, NULL),
('fileman', 'use_editor_3', 'Y', NULL, NULL),
('search', 'version', 'v2.0', NULL, NULL),
('search', 'dbnode_id', 'N', NULL, NULL),
('search', 'dbnode_status', 'ok', NULL, NULL),
('main', 'email_from', 'lena1687@mail.ru', NULL, NULL),
('fileman', 'stickers_use_hotkeys', 'N', NULL, NULL),
('main', 'signer_default_key', 'e10139747b1ed85976214cdd671fd1b05af8b266598fadd8a8afb5e08db7532b1a63abb21981205241383b5aa43548d10b7454af09bf1fb68639d3d6443738fe', NULL, NULL),
('perfmon', 'bitrix_optimal', 'N', NULL, NULL),
('main', 'site_checker_success', 'N', NULL, NULL),
('main', 'dump_bucket_id', '0', NULL, NULL),
('main', 'dump_encrypt', '0', NULL, NULL),
('main', 'dump_use_compression', '1', NULL, NULL),
('main', 'dump_max_exec_time', '20', NULL, NULL),
('main', 'dump_max_exec_time_sleep', '1', NULL, NULL),
('main', 'dump_archive_size_limit', '104857600', NULL, NULL),
('main', 'dump_integrity_check', '1', NULL, NULL),
('main', 'dump_max_file_size', '0', NULL, NULL),
('main', 'dump_file_public', '1', NULL, NULL),
('main', 'dump_file_kernel', '1', NULL, NULL),
('main', 'dump_base', '1', NULL, NULL),
('main', 'dump_base_skip_stat', '0', NULL, NULL),
('main', 'dump_base_skip_search', '0', NULL, NULL),
('main', 'dump_base_skip_log', '0', NULL, NULL),
('main', 'skip_symlinks', '0', NULL, NULL),
('main', 'skip_mask', '0', NULL, NULL),
('main', 'dump_site_id', 'a:0:{}', NULL, NULL),
('main', 'last_files_count', '48291', NULL, NULL),
('fileman', 'use_pspell', 'N', NULL, NULL),
('fileman', 'GROUP_DEFAULT_TASK', '18', NULL, NULL),
('fileman', 'default_edit', 'text', NULL, NULL),
('fileman', 'use_medialib', 'Y', NULL, NULL),
('fileman', 'replace_new_lines', 'Y', NULL, NULL),
('fileman', 'user_dics_path', '/bitrix/modules/fileman/u_dics', NULL, NULL),
('fileman', 'use_separeted_dics', 'N', NULL, NULL),
('fileman', 'use_custom_spell', 'N', NULL, NULL),
('fileman', 'ar_entities', 'none', NULL, NULL),
('fileman', 'editor_body_id', '', NULL, NULL),
('fileman', 'editor_body_class', '', NULL, NULL),
('fileman', 'ml_thumb_width', '140', NULL, NULL),
('fileman', 'ml_thumb_height', '105', NULL, NULL),
('fileman', 'ml_media_extentions', 'jpg,jpeg,gif,png,flv,mp4,wmv,wma,mp3,ppt', NULL, NULL),
('fileman', 'ml_max_width', '1024', NULL, NULL),
('fileman', 'ml_max_height', '1024', NULL, NULL),
('fileman', 'ml_media_available_ext', 'jpg,jpeg,gif,png,flv,mp4,wmv,wma,mp3,ppt,aac', NULL, NULL),
('fileman', 'ml_use_default', '1', NULL, NULL),
('fileman', '~script_files', 'php,php3,php4,php5,php6,phtml,pl,asp,aspx,cgi,exe,ico,shtm,shtml', NULL, NULL),
('fileman', '~allowed_components', '', NULL, NULL),
('fileman', 'different_set', 'N', NULL, NULL),
('fileman', 'num_menu_param', '1', NULL, NULL),
('fileman', 'menutypes', 'a:2:{s:4:\\\"left\\\";s:19:\\\"Левое меню\\\";s:3:\\\"top\\\";s:23:\\\"Верхнее меню\\\";}', NULL, NULL),
('fileman', 'propstypes', 'a:2:{s:11:\\\"description\\\";s:16:\\\"Описание\\\";s:8:\\\"keywords\\\";s:27:\\\"Ключевые слова\\\";}', NULL, NULL),
('fileman', 'search_max_open_file_size', '1024', NULL, NULL),
('fileman', 'search_max_res_count', '', NULL, NULL),
('fileman', 'search_time_step', '5', NULL, NULL),
('fileman', 'search_mask', '*.php', NULL, NULL),
('fileman', 'show_inc_icons', 'N', NULL, NULL),
('fileman', 'hide_physical_struc', '', NULL, NULL),
('fileman', 'use_translit', '1', NULL, NULL),
('fileman', 'use_translit_google', '1', NULL, NULL),
('fileman', 'log_menu', 'Y', NULL, NULL),
('fileman', 'log_page', 'Y', NULL, NULL),
('fileman', 'use_code_editor', 'Y', NULL, NULL),
('fileman', 'google_map_api_key', '', NULL, NULL),
('fileman', 'default_edit_groups', '', NULL, NULL),
('fileman', 'archive_step_time', '30', NULL, NULL),
('fileman', 'GROUP_DEFAULT_RIGHT', 'D', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_cache`
--

CREATE TABLE `b_perf_cache` (
  `ID` int(18) NOT NULL,
  `HIT_ID` int(18) DEFAULT NULL,
  `COMPONENT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `CACHE_SIZE` float DEFAULT NULL,
  `OP_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODULE_NAME` text COLLATE utf8_unicode_ci,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  `BASE_DIR` text COLLATE utf8_unicode_ci,
  `INIT_DIR` text COLLATE utf8_unicode_ci,
  `FILE_NAME` text COLLATE utf8_unicode_ci,
  `FILE_PATH` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_cluster`
--

CREATE TABLE `b_perf_cluster` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `THREADS` int(11) DEFAULT NULL,
  `HITS` int(11) DEFAULT NULL,
  `ERRORS` int(11) DEFAULT NULL,
  `PAGES_PER_SECOND` float DEFAULT NULL,
  `PAGE_EXEC_TIME` float DEFAULT NULL,
  `PAGE_RESP_TIME` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_component`
--

CREATE TABLE `b_perf_component` (
  `ID` int(18) NOT NULL,
  `HIT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `CACHE_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SIZE` int(11) DEFAULT NULL,
  `CACHE_COUNT_R` int(11) DEFAULT NULL,
  `CACHE_COUNT_W` int(11) DEFAULT NULL,
  `CACHE_COUNT_C` int(11) DEFAULT NULL,
  `COMPONENT_TIME` float DEFAULT NULL,
  `QUERIES` int(11) DEFAULT NULL,
  `QUERIES_TIME` float DEFAULT NULL,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_error`
--

CREATE TABLE `b_perf_error` (
  `ID` int(18) NOT NULL,
  `HIT_ID` int(18) DEFAULT NULL,
  `ERRNO` int(18) DEFAULT NULL,
  `ERRSTR` text COLLATE utf8_unicode_ci,
  `ERRFILE` text COLLATE utf8_unicode_ci,
  `ERRLINE` int(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_history`
--

CREATE TABLE `b_perf_history` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TOTAL_MARK` float DEFAULT NULL,
  `ACCELERATOR_ENABLED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_hit`
--

CREATE TABLE `b_perf_hit` (
  `ID` int(11) NOT NULL,
  `DATE_HIT` datetime DEFAULT NULL,
  `IS_ADMIN` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REQUEST_METHOD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SERVER_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SERVER_PORT` int(11) DEFAULT NULL,
  `SCRIPT_NAME` text COLLATE utf8_unicode_ci,
  `REQUEST_URI` text COLLATE utf8_unicode_ci,
  `INCLUDED_FILES` int(11) DEFAULT NULL,
  `MEMORY_PEAK_USAGE` int(11) DEFAULT NULL,
  `CACHE_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SIZE` int(11) DEFAULT NULL,
  `CACHE_COUNT_R` int(11) DEFAULT NULL,
  `CACHE_COUNT_W` int(11) DEFAULT NULL,
  `CACHE_COUNT_C` int(11) DEFAULT NULL,
  `QUERIES` int(11) DEFAULT NULL,
  `QUERIES_TIME` float DEFAULT NULL,
  `COMPONENTS` int(11) DEFAULT NULL,
  `COMPONENTS_TIME` float DEFAULT NULL,
  `SQL_LOG` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAGE_TIME` float DEFAULT NULL,
  `PROLOG_TIME` float DEFAULT NULL,
  `PROLOG_BEFORE_TIME` float DEFAULT NULL,
  `AGENTS_TIME` float DEFAULT NULL,
  `PROLOG_AFTER_TIME` float DEFAULT NULL,
  `WORK_AREA_TIME` float DEFAULT NULL,
  `EPILOG_TIME` float DEFAULT NULL,
  `EPILOG_BEFORE_TIME` float DEFAULT NULL,
  `EVENTS_TIME` float DEFAULT NULL,
  `EPILOG_AFTER_TIME` float DEFAULT NULL,
  `MENU_RECALC` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_index_ban`
--

CREATE TABLE `b_perf_index_ban` (
  `ID` int(11) NOT NULL,
  `BAN_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_index_complete`
--

CREATE TABLE `b_perf_index_complete` (
  `ID` int(11) NOT NULL,
  `BANNED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INDEX_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_index_suggest`
--

CREATE TABLE `b_perf_index_suggest` (
  `ID` int(11) NOT NULL,
  `SQL_MD5` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SQL_COUNT` int(11) DEFAULT NULL,
  `SQL_TIME` float DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_ALIAS` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SQL_TEXT` text COLLATE utf8_unicode_ci,
  `SQL_EXPLAIN` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_index_suggest_sql`
--

CREATE TABLE `b_perf_index_suggest_sql` (
  `SUGGEST_ID` int(11) NOT NULL,
  `SQL_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_sql`
--

CREATE TABLE `b_perf_sql` (
  `ID` int(18) NOT NULL,
  `HIT_ID` int(18) DEFAULT NULL,
  `COMPONENT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `QUERY_TIME` float DEFAULT NULL,
  `NODE_ID` int(18) DEFAULT NULL,
  `MODULE_NAME` text COLLATE utf8_unicode_ci,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  `SQL_TEXT` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_sql_backtrace`
--

CREATE TABLE `b_perf_sql_backtrace` (
  `SQL_ID` int(18) NOT NULL,
  `NN` int(18) NOT NULL,
  `FILE_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINE_NO` int(18) DEFAULT NULL,
  `CLASS_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FUNCTION_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_tab_column_stat`
--

CREATE TABLE `b_perf_tab_column_stat` (
  `ID` int(11) NOT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_ROWS` float DEFAULT NULL,
  `COLUMN_ROWS` float DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_tab_stat`
--

CREATE TABLE `b_perf_tab_stat` (
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TABLE_SIZE` float DEFAULT NULL,
  `TABLE_ROWS` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_perf_test`
--

CREATE TABLE `b_perf_test` (
  `ID` int(18) NOT NULL,
  `REFERENCE_ID` int(18) DEFAULT NULL,
  `NAME` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating`
--

CREATE TABLE `b_rating` (
  `ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CALCULATION_METHOD` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'SUM',
  `CREATED` datetime DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `POSITION` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `AUTHORITY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `CALCULATED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CONFIGS` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_rating`
--

INSERT INTO `b_rating` (`ID`, `ACTIVE`, `NAME`, `ENTITY_ID`, `CALCULATION_METHOD`, `CREATED`, `LAST_MODIFIED`, `LAST_CALCULATED`, `POSITION`, `AUTHORITY`, `CALCULATED`, `CONFIGS`) VALUES
(1, 'N', 'Рейтинг', 'USER', 'SUM', '2017-10-16 08:36:20', NULL, NULL, 'Y', 'N', 'N', 'a:3:{s:4:\"MAIN\";a:2:{s:4:\"VOTE\";a:1:{s:4:\"USER\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:5:\"BONUS\";a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}}}s:5:\"FORUM\";a:2:{s:4:\"VOTE\";a:2:{s:5:\"TOPIC\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.5\";s:5:\"LIMIT\";s:2:\"30\";}s:4:\"POST\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:16:\"TODAY_TOPIC_COEF\";s:3:\"0.4\";s:15:\"WEEK_TOPIC_COEF\";s:3:\"0.2\";s:16:\"MONTH_TOPIC_COEF\";s:3:\"0.1\";s:14:\"ALL_TOPIC_COEF\";s:1:\"0\";s:15:\"TODAY_POST_COEF\";s:3:\"0.2\";s:14:\"WEEK_POST_COEF\";s:3:\"0.1\";s:15:\"MONTH_POST_COEF\";s:4:\"0.05\";s:13:\"ALL_POST_COEF\";s:1:\"0\";}}}s:4:\"BLOG\";a:2:{s:4:\"VOTE\";a:2:{s:4:\"POST\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.5\";s:5:\"LIMIT\";s:2:\"30\";}s:7:\"COMMENT\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";s:18:\"TODAY_COMMENT_COEF\";s:3:\"0.2\";s:17:\"WEEK_COMMENT_COEF\";s:3:\"0.1\";s:18:\"MONTH_COMMENT_COEF\";s:4:\"0.05\";s:16:\"ALL_COMMENT_COEF\";s:1:\"0\";}}}}'),
(2, 'N', 'Авторитет', 'USER', 'SUM', '2017-10-16 08:36:20', NULL, NULL, 'Y', 'Y', 'N', 'a:3:{s:4:\"MAIN\";a:2:{s:4:\"VOTE\";a:1:{s:4:\"USER\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:1:\"0\";}}s:6:\"RATING\";a:1:{s:5:\"BONUS\";a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}}}s:5:\"FORUM\";a:2:{s:4:\"VOTE\";a:2:{s:5:\"TOPIC\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}s:4:\"POST\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:8:{s:16:\"TODAY_TOPIC_COEF\";s:2:\"20\";s:15:\"WEEK_TOPIC_COEF\";s:2:\"10\";s:16:\"MONTH_TOPIC_COEF\";s:1:\"5\";s:14:\"ALL_TOPIC_COEF\";s:1:\"0\";s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";}}}s:4:\"BLOG\";a:2:{s:4:\"VOTE\";a:2:{s:4:\"POST\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}s:7:\"COMMENT\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:8:{s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";s:18:\"TODAY_COMMENT_COEF\";s:3:\"0.2\";s:17:\"WEEK_COMMENT_COEF\";s:3:\"0.1\";s:18:\"MONTH_COMMENT_COEF\";s:4:\"0.05\";s:16:\"ALL_COMMENT_COEF\";s:1:\"0\";}}}}');

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_component`
--

CREATE TABLE `b_rating_component` (
  `ID` int(11) NOT NULL,
  `RATING_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ENTITY_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `RATING_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `COMPLEX_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CALC_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `EXCEPTION_METHOD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `NEXT_CALCULATION` datetime DEFAULT NULL,
  `REFRESH_INTERVAL` int(11) NOT NULL,
  `CONFIG` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_component_results`
--

CREATE TABLE `b_rating_component_results` (
  `ID` int(11) NOT NULL,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `RATING_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `COMPLEX_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CURRENT_VALUE` decimal(18,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_prepare`
--

CREATE TABLE `b_rating_prepare` (
  `ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_results`
--

CREATE TABLE `b_rating_results` (
  `ID` int(11) NOT NULL,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `CURRENT_VALUE` decimal(18,4) DEFAULT NULL,
  `PREVIOUS_VALUE` decimal(18,4) DEFAULT NULL,
  `CURRENT_POSITION` int(11) DEFAULT '0',
  `PREVIOUS_POSITION` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_rule`
--

CREATE TABLE `b_rating_rule` (
  `ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_MODULE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONDITION_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_CONFIG` text COLLATE utf8_unicode_ci,
  `ACTION_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ACTION_CONFIG` text COLLATE utf8_unicode_ci,
  `ACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVATE_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVATE_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DEACTIVATE_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEACTIVATE_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_APPLIED` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_rating_rule`
--

INSERT INTO `b_rating_rule` (`ID`, `ACTIVE`, `NAME`, `ENTITY_TYPE_ID`, `CONDITION_NAME`, `CONDITION_MODULE`, `CONDITION_CLASS`, `CONDITION_METHOD`, `CONDITION_CONFIG`, `ACTION_NAME`, `ACTION_CONFIG`, `ACTIVATE`, `ACTIVATE_CLASS`, `ACTIVATE_METHOD`, `DEACTIVATE`, `DEACTIVATE_CLASS`, `DEACTIVATE_METHOD`, `CREATED`, `LAST_MODIFIED`, `LAST_APPLIED`) VALUES
(1, 'N', 'Добавление в группу пользователей, имеющих право голосовать за рейтинг', 'USER', 'AUTHORITY', NULL, 'CRatingRulesMain', 'ratingCheck', 'a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:1;s:12:\"RATING_VALUE\";i:1;}}', 'ADD_TO_GROUP', 'a:1:{s:12:\"ADD_TO_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"3\";}}', 'N', 'CRatingRulesMain', 'addToGroup', 'N', 'CRatingRulesMain ', 'addToGroup', '2017-10-16 08:36:20', '2017-10-16 08:36:20', NULL),
(2, 'N', 'Удаление из группы пользователей, не имеющих права голосовать за рейтинг', 'USER', 'AUTHORITY', NULL, 'CRatingRulesMain', 'ratingCheck', 'a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:2;s:12:\"RATING_VALUE\";i:1;}}', 'REMOVE_FROM_GROUP', 'a:1:{s:17:\"REMOVE_FROM_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"3\";}}', 'N', 'CRatingRulesMain', 'removeFromGroup', 'N', 'CRatingRulesMain ', 'removeFromGroup', '2017-10-16 08:36:20', '2017-10-16 08:36:20', NULL),
(3, 'N', 'Добавление в группу пользователей, имеющих право голосовать за авторитет', 'USER', 'AUTHORITY', NULL, 'CRatingRulesMain', 'ratingCheck', 'a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:1;s:12:\"RATING_VALUE\";i:2;}}', 'ADD_TO_GROUP', 'a:1:{s:12:\"ADD_TO_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"4\";}}', 'N', 'CRatingRulesMain', 'addToGroup', 'N', 'CRatingRulesMain ', 'addToGroup', '2017-10-16 08:36:21', '2017-10-16 08:36:21', NULL),
(4, 'N', 'Удаление из группы пользователей, не имеющих права голосовать за авторитет', 'USER', 'AUTHORITY', NULL, 'CRatingRulesMain', 'ratingCheck', 'a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:2;s:12:\"RATING_VALUE\";i:2;}}', 'REMOVE_FROM_GROUP', 'a:1:{s:17:\"REMOVE_FROM_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"4\";}}', 'N', 'CRatingRulesMain', 'removeFromGroup', 'N', 'CRatingRulesMain ', 'removeFromGroup', '2017-10-16 08:36:21', '2017-10-16 08:36:21', NULL),
(5, 'Y', 'Автоматическое голосование за авторитет пользователя', 'USER', 'VOTE', NULL, 'CRatingRulesMain', 'voteCheck', 'a:1:{s:4:\"VOTE\";a:6:{s:10:\"VOTE_LIMIT\";i:90;s:11:\"VOTE_RESULT\";i:10;s:16:\"VOTE_FORUM_TOPIC\";d:0.5;s:15:\"VOTE_FORUM_POST\";d:0.10000000000000001;s:14:\"VOTE_BLOG_POST\";d:0.5;s:17:\"VOTE_BLOG_COMMENT\";d:0.10000000000000001;}}', 'empty', 'a:0:{}', 'N', 'empty', 'empty', 'N', 'empty ', 'empty', '2017-10-16 08:36:21', '2017-10-16 08:36:21', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_rule_vetting`
--

CREATE TABLE `b_rating_rule_vetting` (
  `ID` int(11) NOT NULL,
  `RULE_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `ACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `APPLIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_user`
--

CREATE TABLE `b_rating_user` (
  `ID` int(11) NOT NULL,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `BONUS` decimal(18,4) DEFAULT '0.0000',
  `VOTE_WEIGHT` decimal(18,4) DEFAULT '0.0000',
  `VOTE_COUNT` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_rating_user`
--

INSERT INTO `b_rating_user` (`ID`, `RATING_ID`, `ENTITY_ID`, `BONUS`, `VOTE_WEIGHT`, `VOTE_COUNT`) VALUES
(1, 2, 1, '3.0000', '30.0000', 13);

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_vote`
--

CREATE TABLE `b_rating_vote` (
  `ID` int(11) NOT NULL,
  `RATING_VOTING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `VALUE` decimal(18,4) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `USER_IP` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_vote_group`
--

CREATE TABLE `b_rating_vote_group` (
  `ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_rating_vote_group`
--

INSERT INTO `b_rating_vote_group` (`ID`, `GROUP_ID`, `TYPE`) VALUES
(5, 1, 'A'),
(1, 1, 'R'),
(3, 1, 'R'),
(2, 3, 'R'),
(4, 3, 'R'),
(6, 4, 'A');

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_voting`
--

CREATE TABLE `b_rating_voting` (
  `ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `TOTAL_VALUE` decimal(18,4) NOT NULL,
  `TOTAL_VOTES` int(11) NOT NULL,
  `TOTAL_POSITIVE_VOTES` int(11) NOT NULL,
  `TOTAL_NEGATIVE_VOTES` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_voting_prepare`
--

CREATE TABLE `b_rating_voting_prepare` (
  `ID` int(11) NOT NULL,
  `RATING_VOTING_ID` int(11) NOT NULL,
  `TOTAL_VALUE` decimal(18,4) NOT NULL,
  `TOTAL_VOTES` int(11) NOT NULL,
  `TOTAL_POSITIVE_VOTES` int(11) NOT NULL,
  `TOTAL_NEGATIVE_VOTES` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_rating_weight`
--

CREATE TABLE `b_rating_weight` (
  `ID` int(11) NOT NULL,
  `RATING_FROM` decimal(18,4) NOT NULL,
  `RATING_TO` decimal(18,4) NOT NULL,
  `WEIGHT` decimal(18,4) DEFAULT '0.0000',
  `COUNT` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_rating_weight`
--

INSERT INTO `b_rating_weight` (`ID`, `RATING_FROM`, `RATING_TO`, `WEIGHT`, `COUNT`) VALUES
(1, '-1000000.0000', '1000000.0000', '1.0000', 10);

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content`
--

CREATE TABLE `b_search_content` (
  `ID` int(11) NOT NULL,
  `DATE_CHANGE` datetime NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CUSTOM_RANK` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) DEFAULT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENTITY_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  `TITLE` text COLLATE utf8_unicode_ci,
  `BODY` longtext COLLATE utf8_unicode_ci,
  `TAGS` text COLLATE utf8_unicode_ci,
  `PARAM1` text COLLATE utf8_unicode_ci,
  `PARAM2` text COLLATE utf8_unicode_ci,
  `UPD` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_FROM` datetime DEFAULT NULL,
  `DATE_TO` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_search_content`
--

INSERT INTO `b_search_content` (`ID`, `DATE_CHANGE`, `MODULE_ID`, `ITEM_ID`, `CUSTOM_RANK`, `USER_ID`, `ENTITY_TYPE_ID`, `ENTITY_ID`, `URL`, `TITLE`, `BODY`, `TAGS`, `PARAM1`, `PARAM2`, `UPD`, `DATE_FROM`, `DATE_TO`) VALUES
(1, '2017-11-14 17:26:16', 'main', 's1|/index.php', 0, NULL, NULL, NULL, '/index.php', 'Магазин модной одежды', 'Напишите нам\rНаши клиенты о нас', '', '', '', NULL, NULL, NULL),
(2, '2017-10-19 09:32:09', 'iblock', '1', 0, NULL, NULL, NULL, '=ID=1&EXTERNAL_ID=1&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=slider_header&IBLOCK_ID=1&IBLOCK_CODE=slider_in_header&IBLOCK_EXTERNAL_ID=&CODE=slide_1', 'Слайд-1', '', '', 'slider_header', '1', NULL, NULL, NULL),
(3, '2017-10-19 09:32:59', 'iblock', '2', 0, NULL, NULL, NULL, '=ID=2&EXTERNAL_ID=2&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=slider_header&IBLOCK_ID=1&IBLOCK_CODE=slider_in_header&IBLOCK_EXTERNAL_ID=&CODE=slaid_2', 'Слайд-2', '', '', 'slider_header', '1', NULL, NULL, NULL),
(4, '2017-10-19 14:05:29', 'iblock', '3', 0, NULL, NULL, NULL, '=ID=3&EXTERNAL_ID=3&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=slider_header&IBLOCK_ID=1&IBLOCK_CODE=slider_in_header&IBLOCK_EXTERNAL_ID=&CODE=slide_3', 'Слайд-3', '', '', 'slider_header', '1', NULL, NULL, NULL),
(5, '2017-10-20 09:06:46', 'iblock', '4', 0, NULL, NULL, NULL, '=ID=4&EXTERNAL_ID=4&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=slider_header&IBLOCK_ID=1&IBLOCK_CODE=slider_in_header&IBLOCK_EXTERNAL_ID=&CODE=slide_4', 'Слайд-4', '', '', 'slider_header', '1', NULL, NULL, NULL),
(7, '2017-10-23 13:25:43', 'iblock', 'S1', 0, NULL, NULL, NULL, '=ID=1&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=leginsy-i-bryuki', 'Легинсы и брюки', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(8, '2017-10-23 13:27:50', 'iblock', 'S2', 0, NULL, NULL, NULL, '=ID=2&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=kardigany', 'Кардиганы', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(9, '2017-10-23 13:25:30', 'iblock', 'S3', 0, NULL, NULL, NULL, '=ID=3&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=verkhnyaya-odezhda', 'Верхняя одежда', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(10, '2017-10-23 13:14:49', 'iblock', 'S4', 0, NULL, NULL, NULL, '=ID=4&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=accessories', 'Аксессуары', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(11, '2017-10-23 13:26:17', 'iblock', 'S5', 0, NULL, NULL, NULL, '=ID=5&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=platya-i-bluzy', 'Платья и блузы', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(12, '2017-10-23 13:28:40', 'iblock', 'S6', 0, NULL, NULL, NULL, '=ID=6&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=yubki', 'Юбки', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(13, '2017-10-23 13:35:18', 'iblock', 'S7', 0, NULL, NULL, NULL, '=ID=7&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=shorty', 'Шорты', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(14, '2017-10-23 13:40:27', 'iblock', 'S8', 0, NULL, NULL, NULL, '=ID=8&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=shoes', 'Обувь', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(15, '2017-10-23 13:34:50', 'iblock', 'S9', 0, NULL, NULL, NULL, '=ID=9&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=sportivnye-tovary', 'Спортивные товары', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(16, '2017-10-23 13:43:40', 'iblock', 'S10', 0, NULL, NULL, NULL, '=ID=10&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=nizhnee-bele', 'Нижнее белье', 'Нижнее белье и купальники', NULL, 'assortment', '3', NULL, NULL, NULL),
(17, '2017-10-23 13:35:03', 'iblock', 'S11', 0, NULL, NULL, NULL, '=ID=11&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=dzhinsy', 'Джинсы', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(18, '2017-10-23 12:00:52', 'iblock', 'S12', 0, NULL, NULL, NULL, '=ID=12&EXTERNAL_ID=&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=kostyumy', 'Костюмы', '', NULL, 'assortment', '3', NULL, NULL, NULL),
(19, '2017-10-20 14:39:20', 'iblock', '6', 0, NULL, NULL, NULL, '=ID=6&EXTERNAL_ID=6&IBLOCK_SECTION_ID=10&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=kupalnik-gloriya', 'Купальник \"Глория\"', '', '', 'assortment', '3', NULL, NULL, NULL),
(20, '2017-11-14 15:44:00', 'iblock', '7', 0, NULL, NULL, NULL, '=ID=7&EXTERNAL_ID=7&IBLOCK_SECTION_ID=8&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=krossovki-rio', 'Кроссовки \"Rio\"', '', '', 'assortment', '3', NULL, NULL, NULL),
(21, '2017-11-14 15:43:44', 'iblock', '8', 0, NULL, NULL, NULL, '=ID=8&EXTERNAL_ID=8&IBLOCK_SECTION_ID=8&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=tufli-karina', 'Tуфли \"Карина\"', '', '', 'assortment', '3', NULL, NULL, NULL),
(22, '2017-11-10 15:22:01', 'iblock', '9', 0, NULL, NULL, NULL, '=ID=9&EXTERNAL_ID=9&IBLOCK_SECTION_ID=5&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=plate-mila', 'Платье \"Мила\"', 'Красивое и нежное!', '', 'assortment', '3', NULL, NULL, NULL),
(23, '2017-11-13 09:00:11', 'iblock', '10', 0, NULL, NULL, NULL, '=ID=10&EXTERNAL_ID=10&IBLOCK_SECTION_ID=8&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=bossonozhki-milissa', 'Боссоножки \"Милисса\"', 'Женственные и утонченные!', '', 'assortment', '3', NULL, NULL, NULL),
(24, '2017-11-14 15:35:18', 'iblock', '11', 0, NULL, NULL, NULL, '=ID=11&EXTERNAL_ID=11&IBLOCK_SECTION_ID=8&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=kedy-alissport', 'Кеды \"ALISSport\"', 'Мягкие, удобные, модные!', '', 'assortment', '3', NULL, NULL, NULL),
(25, '2017-11-14 15:43:48', 'iblock', '12', 0, NULL, NULL, NULL, '=ID=12&EXTERNAL_ID=12&IBLOCK_SECTION_ID=8&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=bossonozhki-silvi', 'Боссоножки \"Сильви\"', '', '', 'assortment', '3', NULL, NULL, NULL),
(26, '2017-11-02 15:14:14', 'iblock', '13', 0, NULL, NULL, NULL, '=ID=13&EXTERNAL_ID=13&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=dress_shop&IBLOCK_ID=4&IBLOCK_CODE=shop_contacts&IBLOCK_EXTERNAL_ID=&CODE=', 'Модный бутик \"Люварис\"', '', '', 'dress_shop', '4', NULL, NULL, NULL),
(27, '2017-11-08 12:53:36', 'iblock', '14', 0, NULL, NULL, NULL, '=ID=14&EXTERNAL_ID=14&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=slider_header&IBLOCK_ID=5&IBLOCK_CODE=slider-reviews&IBLOCK_EXTERNAL_ID=&CODE=', 'Наталья Киркова', 'Недавно вновь открыла для себя модный бутик \"Люварис\"! Очень радует огромный ассортимент, чуткое внимание к каждому клиенту, а главное эксклюзивность!', '', 'slider_header', '5', NULL, NULL, NULL),
(28, '2017-11-02 17:12:42', 'iblock', '15', 0, NULL, NULL, NULL, '=ID=15&EXTERNAL_ID=15&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=slider_header&IBLOCK_ID=5&IBLOCK_CODE=slider-reviews&IBLOCK_EXTERNAL_ID=&CODE=', 'Мариша Линт', 'Отличный магазин, знакома с ним больше года, качественные вещи, хорошие добрые люди сейчас это редкость , да ещё и розыгрыши устраивают!', '', 'slider_header', '5', NULL, NULL, NULL),
(29, '2017-11-03 09:59:20', 'iblock', '16', 0, NULL, NULL, NULL, '=ID=16&EXTERNAL_ID=16&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=slider_header&IBLOCK_ID=5&IBLOCK_CODE=slider-reviews&IBLOCK_EXTERNAL_ID=&CODE=', 'Иришка Листовцева', 'Магазин шикарный тут вам подберут грамотный образ и честно скажут подходит или нет , а это очень важно . Продолжайте в том же духе спасибо что вы есть!!!', '', 'slider_header', '5', NULL, NULL, NULL),
(30, '2017-11-14 15:42:57', 'iblock', '17', 0, NULL, NULL, NULL, '=ID=17&EXTERNAL_ID=17&IBLOCK_SECTION_ID=8&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=polusapogi-malvin', 'Полусапоги \"Malvin\"', '', '', 'assortment', '3', NULL, NULL, NULL),
(31, '2017-11-14 15:42:29', 'iblock', '18', 0, NULL, NULL, NULL, '=ID=18&EXTERNAL_ID=18&IBLOCK_SECTION_ID=8&IBLOCK_TYPE_ID=assortment&IBLOCK_ID=3&IBLOCK_CODE=assortment&IBLOCK_EXTERNAL_ID=&CODE=sapogi-centi', 'Сапоги \"Centi\"', '', '', 'assortment', '3', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content_freq`
--

CREATE TABLE `b_search_content_freq` (
  `STEM` int(11) NOT NULL DEFAULT '0',
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FREQ` float DEFAULT NULL,
  `TF` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content_param`
--

CREATE TABLE `b_search_content_param` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `PARAM_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARAM_VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content_right`
--

CREATE TABLE `b_search_content_right` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_search_content_right`
--

INSERT INTO `b_search_content_right` (`SEARCH_CONTENT_ID`, `GROUP_CODE`) VALUES
(1, 'G2'),
(2, 'G2'),
(3, 'G2'),
(4, 'G2'),
(5, 'G1'),
(5, 'G2'),
(7, 'G1'),
(7, 'G2'),
(8, 'G1'),
(8, 'G2'),
(9, 'G1'),
(9, 'G2'),
(10, 'G1'),
(10, 'G2'),
(11, 'G1'),
(11, 'G2'),
(12, 'G1'),
(12, 'G2'),
(13, 'G1'),
(13, 'G2'),
(14, 'G1'),
(14, 'G2'),
(15, 'G1'),
(15, 'G2'),
(16, 'G1'),
(16, 'G2'),
(17, 'G1'),
(17, 'G2'),
(18, 'G1'),
(18, 'G2'),
(19, 'G1'),
(19, 'G2'),
(20, 'G1'),
(20, 'G2'),
(21, 'G1'),
(21, 'G2'),
(22, 'G1'),
(22, 'G2'),
(23, 'G1'),
(23, 'G2'),
(24, 'G1'),
(24, 'G2'),
(25, 'G1'),
(25, 'G2'),
(26, 'G2'),
(27, 'G1'),
(27, 'G2'),
(28, 'G1'),
(28, 'G2'),
(29, 'G1'),
(29, 'G2'),
(30, 'G1'),
(30, 'G2'),
(31, 'G1'),
(31, 'G2');

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content_site`
--

CREATE TABLE `b_search_content_site` (
  `SEARCH_CONTENT_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `URL` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_search_content_site`
--

INSERT INTO `b_search_content_site` (`SEARCH_CONTENT_ID`, `SITE_ID`, `URL`) VALUES
(1, 's1', ''),
(2, 's1', ''),
(3, 's1', ''),
(4, 's1', ''),
(5, 's1', ''),
(7, 's1', ''),
(8, 's1', ''),
(9, 's1', ''),
(10, 's1', ''),
(11, 's1', ''),
(12, 's1', ''),
(13, 's1', ''),
(14, 's1', ''),
(15, 's1', ''),
(16, 's1', ''),
(17, 's1', ''),
(18, 's1', ''),
(19, 's1', ''),
(20, 's1', ''),
(21, 's1', ''),
(22, 's1', ''),
(23, 's1', ''),
(24, 's1', ''),
(25, 's1', ''),
(26, 's1', ''),
(27, 's1', ''),
(28, 's1', ''),
(29, 's1', ''),
(30, 's1', ''),
(31, 's1', '');

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content_stem`
--

CREATE TABLE `b_search_content_stem` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `STEM` int(11) NOT NULL,
  `TF` float NOT NULL,
  `PS` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1;

--
-- Дамп данных таблицы `b_search_content_stem`
--

INSERT INTO `b_search_content_stem` (`SEARCH_CONTENT_ID`, `LANGUAGE_ID`, `STEM`, `TF`, `PS`) VALUES
(2, 'ru', 4, 0.2314, 1),
(3, 'ru', 5, 0.2314, 1),
(4, 'ru', 6, 0.2314, 1),
(5, 'ru', 7, 0.2314, 1),
(7, 'ru', 8, 0.2314, 3),
(7, 'ru', 9, 0.2314, 1),
(8, 'ru', 10, 0.2314, 1),
(9, 'ru', 11, 0.2314, 1),
(9, 'ru', 12, 0.2314, 2),
(1, 'ru', 12, 0.2314, 3),
(10, 'ru', 13, 0.2314, 1),
(11, 'ru', 14, 0.2314, 1),
(22, 'ru', 14, 0.2314, 1),
(11, 'ru', 15, 0.2314, 3),
(12, 'ru', 16, 0.2314, 1),
(13, 'ru', 17, 0.2314, 1),
(14, 'ru', 18, 0.2314, 1),
(15, 'ru', 19, 0.2314, 1),
(15, 'ru', 20, 0.2314, 2),
(16, 'ru', 21, 0.3667, 2),
(16, 'ru', 22, 0.3667, 3),
(17, 'ru', 23, 0.2314, 1),
(18, 'ru', 24, 0.2314, 1),
(19, 'ru', 25, 0.2314, 1),
(16, 'ru', 25, 0.2314, 6),
(19, 'ru', 26, 0.2314, 2),
(20, 'ru', 28, 0.2314, 1),
(20, 'ru', 29, 0.2314, 2),
(21, 'ru', 30, 0.2314, 1),
(21, 'ru', 31, 0.2314, 2),
(22, 'ru', 32, 0.2314, 2),
(1, 'ru', 33, 0.2314, 4),
(1, 'ru', 34, 0.2314, 5),
(23, 'ru', 35, 0.2314, 1),
(25, 'ru', 35, 0.2314, 1),
(23, 'ru', 36, 0.2314, 2),
(24, 'ru', 37, 0.2314, 1),
(24, 'ru', 38, 0.2314, 2),
(25, 'ru', 39, 0.2314, 2),
(24, 'ru', 40, 0.2314, 3),
(24, 'ru', 41, 0.2314, 4),
(26, 'ru', 42, 0.2314, 1),
(1, 'ru', 42, 0.2314, 2),
(24, 'ru', 42, 0.2314, 5),
(27, 'ru', 42, 0.2314, 8),
(26, 'ru', 43, 0.2314, 2),
(27, 'ru', 43, 0.2314, 9),
(26, 'ru', 44, 0.2314, 3),
(27, 'ru', 44, 0.2314, 10),
(27, 'ru', 45, 0.2314, 1),
(27, 'ru', 46, 0.2314, 2),
(27, 'ru', 47, 0.2314, 2),
(27, 'ru', 48, 0.2314, 3),
(27, 'ru', 49, 0.2314, 4),
(27, 'ru', 50, 0.2314, 5),
(27, 'ru', 51, 0.2314, 17),
(27, 'ru', 52, 0.2314, 18),
(27, 'ru', 53, 0.2314, 19),
(27, 'ru', 54, 0.2314, 20),
(27, 'ru', 55, 0.2314, 21),
(27, 'ru', 56, 0.2314, 23),
(1, 'ru', 57, 0.2314, 7),
(27, 'ru', 57, 0.2314, 24),
(27, 'ru', 58, 0.2314, 26),
(27, 'ru', 59, 0.2314, 27),
(29, 'ru', 62, 0.2314, 19),
(28, 'ru', 67, 0.2314, 3),
(1, 'ru', 68, 0.2314, 1),
(29, 'ru', 68, 0.2314, 3),
(28, 'ru', 68, 0.2314, 4),
(28, 'ru', 70, 0.2314, 7),
(28, 'ru', 71, 0.2314, 8),
(28, 'ru', 72, 0.2314, 9),
(28, 'ru', 73, 0.2314, 10),
(28, 'ru', 74, 0.2314, 11),
(28, 'ru', 75, 0.2314, 12),
(28, 'ru', 76, 0.2314, 13),
(28, 'ru', 77, 0.2314, 14),
(28, 'ru', 78, 0.2314, 15),
(28, 'ru', 79, 0.2314, 17),
(28, 'ru', 80, 0.2314, 21),
(28, 'ru', 81, 0.2314, 22),
(29, 'ru', 83, 0.2314, 4),
(29, 'ru', 84, 0.2314, 7),
(29, 'ru', 85, 0.2314, 8),
(29, 'ru', 86, 0.2314, 9),
(29, 'ru', 87, 0.2314, 11),
(29, 'ru', 88, 0.2314, 12),
(29, 'ru', 89, 0.2314, 13),
(29, 'ru', 90, 0.2314, 25),
(29, 'ru', 91, 0.2314, 27),
(29, 'ru', 92, 0.2314, 29),
(29, 'ru', 93, 0.2314, 30),
(28, 'ru', 94, 0.2314, 1),
(28, 'ru', 95, 0.2314, 2),
(28, 'ru', 96, 0.2314, 5),
(29, 'ru', 97, 0.2314, 1),
(29, 'ru', 98, 0.2314, 2),
(29, 'ru', 99, 0.2314, 2),
(1, 'ru', 100, 0.2314, 6),
(1, 'ru', 101, 0.2314, 9),
(30, 'ru', 102, 0.2314, 1),
(30, 'ru', 103, 0.2314, 2),
(31, 'ru', 104, 0.2314, 1),
(31, 'ru', 105, 0.2314, 2),
(22, 'ru', 106, 0.2314, 3),
(22, 'ru', 107, 0.2314, 5),
(23, 'ru', 108, 0.2314, 3),
(23, 'ru', 109, 0.2314, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content_text`
--

CREATE TABLE `b_search_content_text` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SEARCH_CONTENT_MD5` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `SEARCHABLE_CONTENT` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_search_content_text`
--

INSERT INTO `b_search_content_text` (`SEARCH_CONTENT_ID`, `SEARCH_CONTENT_MD5`, `SEARCHABLE_CONTENT`) VALUES
(1, '8841329a0c07586d24943119f6cd54ef', 'МАГАЗИН МОДНОЙ ОДЕЖДЫ\r\nНАПИШИТЕ НАМ\rНАШИ КЛИЕНТЫ О НАС\r\n'),
(2, '8a5a1d04a1072a3b4ecca68c43309f92', 'СЛАЙД-1\r\n\r\n'),
(3, '1dba4b6c92f5e3d77e10fdb67b524f08', 'СЛАЙД-2\r\n\r\n'),
(4, '22936f6878a145ca4667f3d99faa78c2', 'СЛАЙД-3\r\n\r\n'),
(5, '6257b6fab586c47914e48c460415053b', 'СЛАЙД-4\r\n\r\n'),
(7, '89ec4afb9053d9d59b81356bd020c20b', 'ЛЕГИНСЫ И БРЮКИ\r\n\r\n'),
(8, '8a59141d0f2393c167e1c5dec2ce8fc0', 'КАРДИГАНЫ\r\n\r\n'),
(9, '3a5ffac2d636bb37e37a0a775611d227', 'ВЕРХНЯЯ ОДЕЖДА\r\n\r\n'),
(10, 'd1d2f112dfacadc90706bf4e4f226021', 'АКСЕССУАРЫ\r\n\r\n'),
(11, 'a4e9a7d0f32fb49a2aa8fb2aefc12c98', 'ПЛАТЬЯ И БЛУЗЫ\r\n\r\n'),
(12, '090721916cf9df5cf662d800ef8eca81', 'ЮБКИ\r\n\r\n'),
(13, '1058f749ffea4e3046e45917a7935b87', 'ШОРТЫ\r\n\r\n'),
(14, 'a58b681dfe05b055ce8d590d62160d85', 'ОБУВЬ\r\n\r\n'),
(15, 'ca70b88c3710b936755999cc71c0cea3', 'СПОРТИВНЫЕ ТОВАРЫ\r\n\r\n'),
(16, '41649618a7f913d285387b7313c46370', 'НИЖНЕЕ БЕЛЬЕ\r\nНИЖНЕЕ БЕЛЬЕ И КУПАЛЬНИКИ\r\n'),
(17, 'd1459afff32444a064788bfa744008e5', 'ДЖИНСЫ\r\n\r\n'),
(18, '0a3286cf5ea8950625b5689fe2ebea2a', 'КОСТЮМЫ\r\n\r\n'),
(19, '063a18525e32ac02c3396e4b7c27dbb8', 'КУПАЛЬНИК \"ГЛОРИЯ\"\r\n\r\n'),
(20, '7e098d532fc7b6ffed2aa50a38cbb864', 'КРОССОВКИ \"RIO\"\r\n\r\n'),
(21, '3c86e170bd66954a909bcbfec66fe463', 'TУФЛИ \"КАРИНА\"\r\n\r\n'),
(22, '7625b83e964642199de78535557b0de4', 'ПЛАТЬЕ \"МИЛА\"\r\nКРАСИВОЕ И НЕЖНОЕ!\r\n'),
(23, '3e0ab9aa3cfad7911852fac42e21a542', 'БОССОНОЖКИ \"МИЛИССА\"\r\nЖЕНСТВЕННЫЕ И УТОНЧЕННЫЕ!\r\n'),
(24, '9eb2bcee49dc6afcb5f7c85bdf1be408', 'КЕДЫ \"ALISSPORT\"\r\nМЯГКИЕ, УДОБНЫЕ, МОДНЫЕ!\r\n'),
(25, '374cdf056c63f09f8af895023939f32d', 'БОССОНОЖКИ \"СИЛЬВИ\"\r\n\r\n'),
(26, '82d318486647c8895b891d54962685b8', 'МОДНЫЙ БУТИК \"ЛЮВАРИС\"\r\n\r\n'),
(27, '276b83cf79214d40e977a3668daa48de', 'НАТАЛЬЯ КИРКОВА\r\nНЕДАВНО ВНОВЬ ОТКРЫЛА ДЛЯ СЕБЯ МОДНЫЙ БУТИК \"ЛЮВАРИС\"! ОЧЕНЬ РАДУЕТ ОГРОМНЫЙ АССОРТИМЕНТ, ЧУТКОЕ ВНИМАНИЕ К КАЖДОМУ КЛИЕНТУ, А ГЛАВНОЕ ЭКСКЛЮЗИВНОСТЬ!\r\n'),
(28, 'b2b71e8dfa670baf42f5a48cbfa1efad', 'МАРИША ЛИНТ\r\nОТЛИЧНЫЙ МАГАЗИН, ЗНАКОМА С НИМ БОЛЬШЕ ГОДА, КАЧЕСТВЕННЫЕ ВЕЩИ, ХОРОШИЕ ДОБРЫЕ ЛЮДИ СЕЙЧАС ЭТО РЕДКОСТЬ , ДА ЕЩЁ И РОЗЫГРЫШИ УСТРАИВАЮТ!\r\n'),
(29, 'e33c434614a0bd1a1a880723b8b63019', 'ИРИШКА ЛИСТОВЦЕВА\r\nМАГАЗИН ШИКАРНЫЙ ТУТ ВАМ ПОДБЕРУТ ГРАМОТНЫЙ ОБРАЗ И ЧЕСТНО СКАЖУТ ПОДХОДИТ ИЛИ НЕТ , А ЭТО ОЧЕНЬ ВАЖНО . ПРОДОЛЖАЙТЕ В ТОМ ЖЕ ДУХЕ СПАСИБО ЧТО ВЫ ЕСТЬ!!!\r\n'),
(30, '7275db3815187e83c59b98d86ae72834', 'ПОЛУСАПОГИ \"MALVIN\"\r\n\r\n'),
(31, '086cf9a475eabd62f9471fde90c3cbdf', 'САПОГИ \"CENTI\"\r\n\r\n');

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_content_title`
--

CREATE TABLE `b_search_content_title` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `POS` int(11) NOT NULL,
  `WORD` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1;

--
-- Дамп данных таблицы `b_search_content_title`
--

INSERT INTO `b_search_content_title` (`SEARCH_CONTENT_ID`, `SITE_ID`, `POS`, `WORD`) VALUES
(24, 's1', 6, 'ALISSPORT'),
(31, 's1', 8, 'CENTI'),
(30, 's1', 12, 'MALVIN'),
(20, 's1', 11, 'RIO'),
(21, 's1', 0, 'TУФЛИ'),
(10, 's1', 0, 'АКСЕССУАРЫ'),
(16, 's1', 7, 'БЕЛЬЕ'),
(11, 's1', 9, 'БЛУЗЫ'),
(23, 's1', 0, 'БОССОНОЖКИ'),
(25, 's1', 0, 'БОССОНОЖКИ'),
(7, 's1', 10, 'БРЮКИ'),
(26, 's1', 7, 'БУТИК'),
(9, 's1', 0, 'ВЕРХНЯЯ'),
(19, 's1', 11, 'ГЛОРИЯ'),
(17, 's1', 0, 'ДЖИНСЫ'),
(7, 's1', 3, 'И'),
(11, 's1', 7, 'И'),
(29, 's1', 0, 'ИРИШКА'),
(8, 's1', 0, 'КАРДИГАНЫ'),
(21, 's1', 7, 'КАРИНА'),
(24, 's1', 0, 'КЕДЫ'),
(27, 's1', 8, 'КИРКОВА'),
(18, 's1', 0, 'КОСТЮМЫ'),
(20, 's1', 0, 'КРОССОВКИ'),
(19, 's1', 0, 'КУПАЛЬНИК'),
(7, 's1', 0, 'ЛЕГИНСЫ'),
(28, 's1', 7, 'ЛИНТ'),
(29, 's1', 7, 'ЛИСТОВЦЕВА'),
(26, 's1', 14, 'ЛЮВАРИС'),
(1, 's1', 0, 'МАГАЗИН'),
(28, 's1', 0, 'МАРИША'),
(22, 's1', 8, 'МИЛА'),
(23, 's1', 12, 'МИЛИССА'),
(1, 's1', 8, 'МОДНОЙ'),
(26, 's1', 0, 'МОДНЫЙ'),
(27, 's1', 0, 'НАТАЛЬЯ'),
(16, 's1', 0, 'НИЖНЕЕ'),
(14, 's1', 0, 'ОБУВЬ'),
(9, 's1', 8, 'ОДЕЖДА'),
(1, 's1', 15, 'ОДЕЖДЫ'),
(22, 's1', 0, 'ПЛАТЬЕ'),
(11, 's1', 0, 'ПЛАТЬЯ'),
(30, 's1', 0, 'ПОЛУСАПОГИ'),
(31, 's1', 0, 'САПОГИ'),
(25, 's1', 12, 'СИЛЬВИ'),
(2, 's1', 0, 'СЛАЙД-1'),
(3, 's1', 0, 'СЛАЙД-2'),
(4, 's1', 0, 'СЛАЙД-3'),
(5, 's1', 0, 'СЛАЙД-4'),
(15, 's1', 0, 'СПОРТИВНЫЕ'),
(15, 's1', 11, 'ТОВАРЫ'),
(13, 's1', 0, 'ШОРТЫ'),
(12, 's1', 0, 'ЮБКИ');

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_custom_rank`
--

CREATE TABLE `b_search_custom_rank` (
  `ID` int(11) NOT NULL,
  `APPLIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RANK` int(11) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `PARAM1` text COLLATE utf8_unicode_ci,
  `PARAM2` text COLLATE utf8_unicode_ci,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_phrase`
--

CREATE TABLE `b_search_phrase` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `RESULT_COUNT` int(11) NOT NULL,
  `PAGES` int(11) NOT NULL,
  `SESSION_ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `PHRASE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TO` text COLLATE utf8_unicode_ci,
  `URL_TO_404` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TO_SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_SESS_ID` int(18) DEFAULT NULL,
  `EVENT1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_stem`
--

CREATE TABLE `b_search_stem` (
  `ID` int(11) NOT NULL,
  `STEM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_search_stem`
--

INSERT INTO `b_search_stem` (`ID`, `STEM`) VALUES
(1, '1С-БИТРИКС'),
(38, 'ALISSPORT'),
(105, 'CENTI'),
(103, 'MALVIN'),
(29, 'RIO'),
(27, 'TEST'),
(30, 'TУФЛ'),
(13, 'АКСЕССУАР'),
(53, 'АССОРТИМЕНТ'),
(22, 'БЕЛ'),
(15, 'БЛУЗ'),
(71, 'БОЛЬШ'),
(35, 'БОССОНОЖК'),
(8, 'БРЮК'),
(43, 'БУТИК'),
(62, 'ВАЖН'),
(60, 'ВЕД'),
(11, 'ВЕРХН'),
(74, 'ВЕЩ'),
(55, 'ВНИМАН'),
(49, 'ВНОВ'),
(58, 'ГЛАВН'),
(26, 'ГЛОР'),
(72, 'ГОД'),
(85, 'ГРАМОТН'),
(61, 'ДЕВУШК'),
(23, 'ДЖИНС'),
(76, 'ДОБР'),
(92, 'ДУХ'),
(108, 'ЖЕНСТВЕН'),
(69, 'ЗНАК'),
(96, 'ЗНАКОМ'),
(97, 'ИРИШК'),
(82, 'ИРИШКА-МАЛЫШК'),
(56, 'КАЖД'),
(10, 'КАРДИГА'),
(31, 'КАРИН'),
(73, 'КАЧЕСТВЕН'),
(37, 'КЕД'),
(47, 'КИРК'),
(46, 'КИРКОВ'),
(57, 'КЛИЕНТ'),
(24, 'КОСТЮМ'),
(106, 'КРАСИВ'),
(28, 'КРОССОВК'),
(25, 'КУПАЛЬНИК'),
(9, 'ЛЕГИНС'),
(95, 'ЛИНТ'),
(99, 'ЛИСТОВЦ'),
(98, 'ЛИСТОВЦЕВ'),
(44, 'ЛЮВАРИС'),
(77, 'ЛЮД'),
(68, 'МАГАЗИН'),
(94, 'МАРИШ'),
(32, 'МИЛ'),
(36, 'МИЛИСС'),
(66, 'МИШ'),
(42, 'МОДН'),
(40, 'МЯГК'),
(34, 'НАМ'),
(33, 'НАПИШ'),
(101, 'НАС'),
(45, 'НАТАЛ'),
(100, 'НАШ'),
(48, 'НЕДАВН'),
(107, 'НЕЖН'),
(65, 'НЕПОВТОРИМ'),
(21, 'НИЖН'),
(70, 'НИМ'),
(86, 'ОБРАЗ'),
(18, 'ОБУВ'),
(52, 'ОГРОМН'),
(12, 'ОДЕЖД'),
(64, 'ОСОБЕН'),
(50, 'ОТКР'),
(67, 'ОТЛИЧН'),
(14, 'ПЛАТ'),
(84, 'ПОДБЕРУТ'),
(89, 'ПОДХОД'),
(102, 'ПОЛУСАПОГ'),
(90, 'ПРОДОЛЖА'),
(51, 'РАД'),
(79, 'РЕДКОСТ'),
(80, 'РОЗЫГРЫШ'),
(3, 'САЙТ'),
(104, 'САПОГ'),
(78, 'СЕЙЧАС'),
(39, 'СИЛЬВ'),
(88, 'СКАЖУТ'),
(4, 'СЛАЙД-1'),
(5, 'СЛАЙД-2'),
(6, 'СЛАЙД-3'),
(7, 'СЛАЙД-4'),
(93, 'СПАСИБ'),
(19, 'СПОРТИВН'),
(20, 'ТОВАР'),
(91, 'ТОМ'),
(41, 'УДОБН'),
(2, 'УПРАВЛЕН'),
(81, 'УСТРАИВА'),
(109, 'УТОНЧЕН'),
(75, 'ХОРОШ'),
(87, 'ЧЕСТН'),
(63, 'ЧУВСТВОВА'),
(54, 'ЧУТК'),
(83, 'ШИКАРН'),
(17, 'ШОРТ'),
(59, 'ЭКСКЛЮЗИВН'),
(16, 'ЮБК');

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_suggest`
--

CREATE TABLE `b_search_suggest` (
  `ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `FILTER_MD5` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `PHRASE` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `RATE` float NOT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  `RESULT_COUNT` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_tags`
--

CREATE TABLE `b_search_tags` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1;

-- --------------------------------------------------------

--
-- Структура таблицы `b_search_user_right`
--

CREATE TABLE `b_search_user_right` (
  `USER_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_autolog`
--

CREATE TABLE `b_seo_adv_autolog` (
  `ID` int(11) NOT NULL,
  `ENGINE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `CAMPAIGN_XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BANNER_ID` int(11) NOT NULL,
  `BANNER_XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CAUSE_CODE` int(11) DEFAULT '0',
  `SUCCESS` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_banner`
--

CREATE TABLE `b_seo_adv_banner` (
  `ID` int(11) NOT NULL,
  `ENGINE_ID` int(11) NOT NULL,
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) DEFAULT NULL,
  `AUTO_QUANTITY_OFF` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `AUTO_QUANTITY_ON` char(1) COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_campaign`
--

CREATE TABLE `b_seo_adv_campaign` (
  `ID` int(11) NOT NULL,
  `ENGINE_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_group`
--

CREATE TABLE `b_seo_adv_group` (
  `ID` int(11) NOT NULL,
  `ENGINE_ID` int(11) NOT NULL,
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `CAMPAIGN_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_link`
--

CREATE TABLE `b_seo_adv_link` (
  `LINK_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `LINK_ID` int(18) NOT NULL,
  `BANNER_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_log`
--

CREATE TABLE `b_seo_adv_log` (
  `ID` int(11) NOT NULL,
  `ENGINE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `REQUEST_URI` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `REQUEST_DATA` text COLLATE utf8_unicode_ci,
  `RESPONSE_TIME` float NOT NULL,
  `RESPONSE_STATUS` int(5) DEFAULT NULL,
  `RESPONSE_DATA` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_order`
--

CREATE TABLE `b_seo_adv_order` (
  `ID` int(11) NOT NULL,
  `ENGINE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `BANNER_ID` int(11) NOT NULL,
  `ORDER_ID` int(11) NOT NULL,
  `SUM` float DEFAULT '0',
  `PROCESSED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_adv_region`
--

CREATE TABLE `b_seo_adv_region` (
  `ID` int(11) NOT NULL,
  `ENGINE_ID` int(11) NOT NULL,
  `OWNER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `OWNER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `PARENT_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_keywords`
--

CREATE TABLE `b_seo_keywords` (
  `ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_search_engine`
--

CREATE TABLE `b_seo_search_engine` (
  `ID` int(11) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SORT` int(5) DEFAULT '100',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLIENT_SECRET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REDIRECT_URI` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_seo_search_engine`
--

INSERT INTO `b_seo_search_engine` (`ID`, `CODE`, `ACTIVE`, `SORT`, `NAME`, `CLIENT_ID`, `CLIENT_SECRET`, `REDIRECT_URI`, `SETTINGS`) VALUES
(1, 'google', 'Y', 200, 'Google', '868942902147-qrrd6ce1ajfkpse8ieq4gkpdeanvtnno.apps.googleusercontent.com', 'EItMlJpZLC2WRPKB6QsA5bV9', 'urn:ietf:wg:oauth:2.0:oob', NULL),
(2, 'yandex', 'Y', 300, 'Yandex', 'f848c7bfc1d34a94ba6d05439f81bbd7', 'da0e73b2d9cc4e809f3170e49cb9df01', 'https://oauth.yandex.ru/verification_code', NULL),
(3, 'yandex_direct', 'Y', 400, 'Yandex.Direct', '', '', 'https://oauth.yandex.ru/verification_code', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_service_log`
--

CREATE TABLE `b_seo_service_log` (
  `ID` int(11) NOT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `TYPE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_service_rtg_queue`
--

CREATE TABLE `b_seo_service_rtg_queue` (
  `ID` int(11) NOT NULL,
  `DATE_INSERT` datetime DEFAULT NULL,
  `TYPE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ACCOUNT_ID` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUDIENCE_ID` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `CONTACT_TYPE` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTION` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_AUTO_REMOVE` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_sitemap`
--

CREATE TABLE `b_seo_sitemap` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `DATE_RUN` datetime DEFAULT NULL,
  `SETTINGS` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_sitemap_entity`
--

CREATE TABLE `b_seo_sitemap_entity` (
  `ID` int(11) NOT NULL,
  `ENTITY_TYPE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `SITEMAP_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_sitemap_iblock`
--

CREATE TABLE `b_seo_sitemap_iblock` (
  `ID` int(11) NOT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  `SITEMAP_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_sitemap_runtime`
--

CREATE TABLE `b_seo_sitemap_runtime` (
  `ID` int(11) NOT NULL,
  `PID` int(11) NOT NULL,
  `PROCESSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ITEM_PATH` varchar(700) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEM_ID` int(11) DEFAULT NULL,
  `ITEM_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `ACTIVE_ELEMENT` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_seo_yandex_direct_stat`
--

CREATE TABLE `b_seo_yandex_direct_stat` (
  `ID` int(18) NOT NULL,
  `CAMPAIGN_ID` int(11) NOT NULL,
  `BANNER_ID` int(11) NOT NULL,
  `DATE_DAY` date NOT NULL,
  `CURRENCY` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUM` float DEFAULT '0',
  `SUM_SEARCH` float DEFAULT '0',
  `SUM_CONTEXT` float DEFAULT '0',
  `CLICKS` int(7) DEFAULT '0',
  `CLICKS_SEARCH` int(7) DEFAULT '0',
  `CLICKS_CONTEXT` int(7) DEFAULT '0',
  `SHOWS` int(7) DEFAULT '0',
  `SHOWS_SEARCH` int(7) DEFAULT '0',
  `SHOWS_CONTEXT` int(7) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_short_uri`
--

CREATE TABLE `b_short_uri` (
  `ID` int(18) NOT NULL,
  `URI` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `URI_CRC` int(18) NOT NULL,
  `SHORT_URI` varbinary(250) NOT NULL,
  `SHORT_URI_CRC` int(18) NOT NULL,
  `STATUS` int(18) NOT NULL DEFAULT '301',
  `MODIFIED` datetime NOT NULL,
  `LAST_USED` datetime DEFAULT NULL,
  `NUMBER_USED` int(18) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_site_template`
--

CREATE TABLE `b_site_template` (
  `ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `TEMPLATE` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_site_template`
--

INSERT INTO `b_site_template` (`ID`, `SITE_ID`, `CONDITION`, `SORT`, `TEMPLATE`) VALUES
(1, 's1', '', 1, 'dress');

-- --------------------------------------------------------

--
-- Структура таблицы `b_smile`
--

CREATE TABLE `b_smile` (
  `ID` int(18) NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `SET_ID` int(18) NOT NULL DEFAULT '0',
  `SORT` int(10) NOT NULL DEFAULT '150',
  `TYPING` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLICKABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `HIDDEN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IMAGE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `IMAGE_DEFINITION` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'SD',
  `IMAGE_WIDTH` int(11) NOT NULL DEFAULT '0',
  `IMAGE_HEIGHT` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_smile`
--

INSERT INTO `b_smile` (`ID`, `TYPE`, `SET_ID`, `SORT`, `TYPING`, `CLICKABLE`, `HIDDEN`, `IMAGE`, `IMAGE_DEFINITION`, `IMAGE_WIDTH`, `IMAGE_HEIGHT`) VALUES
(1, 'S', 2, 100, ':) :-)', 'Y', 'N', 'bx_smile_smile.png', 'UHD', 20, 20),
(2, 'S', 2, 105, ';) ;-)', 'Y', 'N', 'bx_smile_wink.png', 'UHD', 20, 20),
(3, 'S', 2, 110, ':D :-D', 'Y', 'N', 'bx_smile_biggrin.png', 'UHD', 20, 20),
(4, 'S', 2, 115, '8) 8-)', 'Y', 'N', 'bx_smile_cool.png', 'UHD', 20, 20),
(5, 'S', 2, 120, ':facepalm:', 'Y', 'N', 'bx_smile_facepalm.png', 'UHD', 20, 20),
(6, 'S', 2, 125, ':{} :-{}', 'Y', 'N', 'bx_smile_kiss.png', 'UHD', 20, 20),
(7, 'S', 2, 130, ':( :-(', 'Y', 'N', 'bx_smile_sad.png', 'UHD', 20, 20),
(8, 'S', 2, 135, ':| :-|', 'Y', 'N', 'bx_smile_neutral.png', 'UHD', 20, 20),
(9, 'S', 2, 140, ':oops:', 'Y', 'N', 'bx_smile_redface.png', 'UHD', 20, 20),
(10, 'S', 2, 145, ':cry: :~(', 'Y', 'N', 'bx_smile_cry.png', 'UHD', 20, 20),
(11, 'S', 2, 150, ':evil: >:-<', 'Y', 'N', 'bx_smile_evil.png', 'UHD', 20, 20),
(12, 'S', 2, 155, ':o :-o :shock:', 'Y', 'N', 'bx_smile_eek.png', 'UHD', 20, 20),
(13, 'S', 2, 160, ':/ :-/', 'Y', 'N', 'bx_smile_confuse.png', 'UHD', 20, 20),
(14, 'S', 2, 165, ':idea:', 'Y', 'N', 'bx_smile_idea.png', 'UHD', 20, 20),
(15, 'S', 2, 170, ':?:', 'Y', 'N', 'bx_smile_question.png', 'UHD', 20, 20),
(16, 'S', 2, 175, ':!:', 'Y', 'N', 'bx_smile_exclaim.png', 'UHD', 20, 20),
(17, 'S', 2, 180, ':like:', 'Y', 'N', 'bx_smile_like.png', 'UHD', 20, 20),
(18, 'I', 2, 175, 'ICON_NOTE', 'Y', 'N', 'bx_icon_1.gif', 'SD', 15, 15),
(19, 'I', 2, 180, 'ICON_DIRRECTION', 'Y', 'N', 'bx_icon_2.gif', 'SD', 15, 15),
(20, 'I', 2, 185, 'ICON_IDEA', 'Y', 'N', 'bx_icon_3.gif', 'SD', 15, 15),
(21, 'I', 2, 190, 'ICON_ATTANSION', 'Y', 'N', 'bx_icon_4.gif', 'SD', 15, 15),
(22, 'I', 2, 195, 'ICON_QUESTION', 'Y', 'N', 'bx_icon_5.gif', 'SD', 15, 15),
(23, 'I', 2, 200, 'ICON_BAD', 'Y', 'N', 'bx_icon_6.gif', 'SD', 15, 15),
(24, 'I', 2, 205, 'ICON_GOOD', 'Y', 'N', 'bx_icon_7.gif', 'SD', 15, 15);

-- --------------------------------------------------------

--
-- Структура таблицы `b_smile_lang`
--

CREATE TABLE `b_smile_lang` (
  `ID` int(18) NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `SID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_smile_lang`
--

INSERT INTO `b_smile_lang` (`ID`, `TYPE`, `SID`, `LID`, `NAME`) VALUES
(1, 'P', 1, 'ru', 'Стандартная галерея'),
(2, 'P', 1, 'en', 'Standard gallery'),
(3, 'G', 2, 'ru', 'Основной набор'),
(4, 'G', 2, 'en', 'Default pack'),
(5, 'S', 1, 'ru', 'С улыбкой'),
(6, 'S', 1, 'en', 'Smile'),
(7, 'S', 2, 'ru', 'Шутливо'),
(8, 'S', 2, 'en', 'Wink'),
(9, 'S', 3, 'ru', 'Широкая улыбка'),
(10, 'S', 3, 'en', 'Big grin'),
(11, 'S', 4, 'ru', 'Здорово'),
(12, 'S', 4, 'en', 'Cool'),
(13, 'S', 5, 'ru', 'Разочарование'),
(14, 'S', 5, 'en', 'Facepalm'),
(15, 'S', 6, 'ru', 'Поцелуй'),
(16, 'S', 6, 'en', 'Kiss'),
(17, 'S', 7, 'ru', 'Печально'),
(18, 'S', 7, 'en', 'Sad'),
(19, 'S', 8, 'ru', 'Скептически'),
(20, 'S', 8, 'en', 'Skeptic'),
(21, 'S', 9, 'ru', 'Смущенный'),
(22, 'S', 9, 'en', 'Embarrassed'),
(23, 'S', 10, 'ru', 'Очень грустно'),
(24, 'S', 10, 'en', 'Crying'),
(25, 'S', 11, 'ru', 'Со злостью'),
(26, 'S', 11, 'en', 'Angry'),
(27, 'S', 12, 'ru', 'Удивленно'),
(28, 'S', 12, 'en', 'Surprised'),
(29, 'S', 13, 'ru', 'Смущенно'),
(30, 'S', 13, 'en', 'Confused'),
(31, 'S', 14, 'ru', 'Идея'),
(32, 'S', 14, 'en', 'Idea'),
(33, 'S', 15, 'ru', 'Вопрос'),
(34, 'S', 15, 'en', 'Question'),
(35, 'S', 16, 'ru', 'Восклицание'),
(36, 'S', 16, 'en', 'Exclamation'),
(37, 'S', 17, 'ru', 'Нравится'),
(38, 'S', 17, 'en', 'Like');

-- --------------------------------------------------------

--
-- Структура таблицы `b_smile_set`
--

CREATE TABLE `b_smile_set` (
  `ID` int(18) NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'G',
  `PARENT_ID` int(18) NOT NULL DEFAULT '0',
  `STRING_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(10) NOT NULL DEFAULT '150'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_smile_set`
--

INSERT INTO `b_smile_set` (`ID`, `TYPE`, `PARENT_ID`, `STRING_ID`, `SORT`) VALUES
(1, 'P', 0, 'bitrix', 150),
(2, 'G', 1, 'bitrix_main', 150);

-- --------------------------------------------------------

--
-- Структура таблицы `b_socialservices_ap`
--

CREATE TABLE `b_socialservices_ap` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `USER_ID` int(11) NOT NULL,
  `DOMAIN` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ENDPOINT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGIN` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_AUTHORIZE` datetime DEFAULT NULL,
  `SETTINGS` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_socialservices_contact`
--

CREATE TABLE `b_socialservices_contact` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `USER_ID` int(11) NOT NULL,
  `CONTACT_USER_ID` int(11) DEFAULT NULL,
  `CONTACT_XML_ID` int(11) DEFAULT NULL,
  `CONTACT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTACT_LAST_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTACT_PHOTO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_AUTHORIZE` datetime DEFAULT NULL,
  `NOTIFY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_socialservices_contact_connect`
--

CREATE TABLE `b_socialservices_contact_connect` (
  `ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `CONTACT_ID` int(11) DEFAULT NULL,
  `LINK_ID` int(11) DEFAULT NULL,
  `CONTACT_PROFILE_ID` int(11) NOT NULL,
  `CONTACT_PORTAL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONNECT_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT 'P',
  `LAST_AUTHORIZE` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_socialservices_message`
--

CREATE TABLE `b_socialservices_message` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `SOCSERV_USER_ID` int(11) NOT NULL,
  `PROVIDER` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  `SUCCES_SENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_socialservices_user`
--

CREATE TABLE `b_socialservices_user` (
  `ID` int(11) NOT NULL,
  `LOGIN` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PHOTO` int(11) DEFAULT NULL,
  `EXTERNAL_AUTH_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `CAN_DELETE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PERSONAL_WWW` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS` varchar(555) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OATOKEN` varchar(3000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OATOKEN_EXPIRES` int(11) DEFAULT NULL,
  `OASECRET` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REFRESH_TOKEN` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEND_ACTIVITY` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SITE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INITIALIZED` char(1) COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_socialservices_user_link`
--

CREATE TABLE `b_socialservices_user_link` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `SOCSERV_USER_ID` int(11) NOT NULL,
  `LINK_USER_ID` int(11) DEFAULT NULL,
  `LINK_UID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LINK_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_LAST_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_PICTURE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMESTAMP_X` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_sticker`
--

CREATE TABLE `b_sticker` (
  `ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAGE_URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PAGE_TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `MODIFIED_BY` int(18) NOT NULL,
  `CREATED_BY` int(18) NOT NULL,
  `PERSONAL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CONTENT` text COLLATE utf8_unicode_ci,
  `POS_TOP` int(11) DEFAULT NULL,
  `POS_LEFT` int(11) DEFAULT NULL,
  `WIDTH` int(11) DEFAULT NULL,
  `HEIGHT` int(11) DEFAULT NULL,
  `COLOR` int(11) DEFAULT NULL,
  `COLLAPSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `COMPLETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CLOSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DELETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `MARKER_TOP` int(11) DEFAULT NULL,
  `MARKER_LEFT` int(11) DEFAULT NULL,
  `MARKER_WIDTH` int(11) DEFAULT NULL,
  `MARKER_HEIGHT` int(11) DEFAULT NULL,
  `MARKER_ADJUST` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_sticker_group_task`
--

CREATE TABLE `b_sticker_group_task` (
  `GROUP_ID` int(11) NOT NULL,
  `TASK_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_task`
--

CREATE TABLE `b_task` (
  `ID` int(18) NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LETTER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SYS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BINDING` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'module'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_task`
--

INSERT INTO `b_task` (`ID`, `NAME`, `LETTER`, `MODULE_ID`, `SYS`, `DESCRIPTION`, `BINDING`) VALUES
(1, 'main_denied', 'D', 'main', 'Y', NULL, 'module'),
(2, 'main_change_profile', 'P', 'main', 'Y', NULL, 'module'),
(3, 'main_view_all_settings', 'R', 'main', 'Y', NULL, 'module'),
(4, 'main_view_all_settings_change_profile', 'T', 'main', 'Y', NULL, 'module'),
(5, 'main_edit_subordinate_users', 'V', 'main', 'Y', NULL, 'module'),
(6, 'main_full_access', 'W', 'main', 'Y', NULL, 'module'),
(7, 'fm_folder_access_denied', 'D', 'main', 'Y', NULL, 'file'),
(8, 'fm_folder_access_read', 'R', 'main', 'Y', NULL, 'file'),
(9, 'fm_folder_access_write', 'W', 'main', 'Y', NULL, 'file'),
(10, 'fm_folder_access_full', 'X', 'main', 'Y', NULL, 'file'),
(11, 'fm_folder_access_workflow', 'U', 'main', 'Y', NULL, 'file'),
(12, 'bitrixcloud_deny', 'D', 'bitrixcloud', 'Y', NULL, 'module'),
(13, 'bitrixcloud_control', 'W', 'bitrixcloud', 'Y', NULL, 'module'),
(14, 'clouds_denied', 'D', 'clouds', 'Y', NULL, 'module'),
(15, 'clouds_browse', 'F', 'clouds', 'Y', NULL, 'module'),
(16, 'clouds_upload', 'U', 'clouds', 'Y', NULL, 'module'),
(17, 'clouds_full_access', 'W', 'clouds', 'Y', NULL, 'module'),
(18, 'fileman_denied', 'D', 'fileman', 'Y', '', 'module'),
(19, 'fileman_allowed_folders', 'F', 'fileman', 'Y', '', 'module'),
(20, 'fileman_full_access', 'W', 'fileman', 'Y', '', 'module'),
(21, 'medialib_denied', 'D', 'fileman', 'Y', '', 'medialib'),
(22, 'medialib_view', 'F', 'fileman', 'Y', '', 'medialib'),
(23, 'medialib_only_new', 'R', 'fileman', 'Y', '', 'medialib'),
(24, 'medialib_edit_items', 'V', 'fileman', 'Y', '', 'medialib'),
(25, 'medialib_editor', 'W', 'fileman', 'Y', '', 'medialib'),
(26, 'medialib_full', 'X', 'fileman', 'Y', '', 'medialib'),
(27, 'stickers_denied', 'D', 'fileman', 'Y', '', 'stickers'),
(28, 'stickers_read', 'R', 'fileman', 'Y', '', 'stickers'),
(29, 'stickers_edit', 'W', 'fileman', 'Y', '', 'stickers'),
(30, 'hblock_denied', 'D', 'highloadblock', 'Y', NULL, 'module'),
(31, 'hblock_read', 'R', 'highloadblock', 'Y', NULL, 'module'),
(32, 'hblock_write', 'W', 'highloadblock', 'Y', NULL, 'module'),
(33, 'iblock_deny', 'D', 'iblock', 'Y', NULL, 'iblock'),
(34, 'iblock_read', 'R', 'iblock', 'Y', NULL, 'iblock'),
(35, 'iblock_element_add', 'E', 'iblock', 'Y', NULL, 'iblock'),
(36, 'iblock_admin_read', 'S', 'iblock', 'Y', NULL, 'iblock'),
(37, 'iblock_admin_add', 'T', 'iblock', 'Y', NULL, 'iblock'),
(38, 'iblock_limited_edit', 'U', 'iblock', 'Y', NULL, 'iblock'),
(39, 'iblock_full_edit', 'W', 'iblock', 'Y', NULL, 'iblock'),
(40, 'iblock_full', 'X', 'iblock', 'Y', NULL, 'iblock'),
(41, 'seo_denied', 'D', 'seo', 'Y', '', 'module'),
(42, 'seo_edit', 'F', 'seo', 'Y', '', 'module'),
(43, 'seo_full_access', 'W', 'seo', 'Y', '', 'module');

-- --------------------------------------------------------

--
-- Структура таблицы `b_task_operation`
--

CREATE TABLE `b_task_operation` (
  `TASK_ID` int(18) NOT NULL,
  `OPERATION_ID` int(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_task_operation`
--

INSERT INTO `b_task_operation` (`TASK_ID`, `OPERATION_ID`) VALUES
(2, 2),
(2, 3),
(3, 2),
(3, 4),
(3, 5),
(3, 6),
(3, 7),
(4, 2),
(4, 3),
(4, 4),
(4, 5),
(4, 6),
(4, 7),
(5, 2),
(5, 3),
(5, 5),
(5, 6),
(5, 7),
(5, 8),
(5, 9),
(6, 2),
(6, 3),
(6, 4),
(6, 5),
(6, 6),
(6, 7),
(6, 10),
(6, 11),
(6, 12),
(6, 13),
(6, 14),
(6, 15),
(6, 16),
(6, 17),
(6, 18),
(8, 19),
(8, 20),
(8, 21),
(9, 19),
(9, 20),
(9, 21),
(9, 22),
(9, 23),
(9, 24),
(9, 25),
(9, 26),
(9, 27),
(9, 28),
(9, 29),
(9, 30),
(9, 31),
(9, 32),
(9, 33),
(9, 34),
(10, 19),
(10, 20),
(10, 21),
(10, 22),
(10, 23),
(10, 24),
(10, 25),
(10, 26),
(10, 27),
(10, 28),
(10, 29),
(10, 30),
(10, 31),
(10, 32),
(10, 33),
(10, 34),
(10, 35),
(11, 19),
(11, 20),
(11, 21),
(11, 24),
(11, 28),
(13, 36),
(13, 37),
(13, 38),
(15, 39),
(16, 39),
(16, 40),
(17, 39),
(17, 40),
(17, 41),
(19, 44),
(19, 45),
(19, 46),
(19, 47),
(19, 48),
(19, 49),
(19, 50),
(19, 52),
(19, 53),
(20, 42),
(20, 43),
(20, 44),
(20, 45),
(20, 46),
(20, 47),
(20, 48),
(20, 49),
(20, 50),
(20, 51),
(20, 52),
(20, 53),
(20, 54),
(22, 55),
(23, 55),
(23, 56),
(23, 60),
(24, 55),
(24, 60),
(24, 61),
(24, 62),
(25, 55),
(25, 56),
(25, 57),
(25, 58),
(25, 60),
(25, 61),
(25, 62),
(26, 55),
(26, 56),
(26, 57),
(26, 58),
(26, 59),
(26, 60),
(26, 61),
(26, 62),
(28, 63),
(29, 63),
(29, 64),
(29, 65),
(29, 66),
(31, 67),
(32, 68),
(32, 69),
(34, 70),
(34, 71),
(35, 72),
(36, 70),
(36, 71),
(36, 73),
(37, 70),
(37, 71),
(37, 72),
(37, 73),
(38, 70),
(38, 71),
(38, 72),
(38, 73),
(38, 74),
(38, 75),
(38, 76),
(38, 77),
(39, 70),
(39, 71),
(39, 72),
(39, 73),
(39, 74),
(39, 75),
(39, 76),
(39, 77),
(39, 78),
(39, 79),
(39, 80),
(39, 81),
(40, 70),
(40, 71),
(40, 72),
(40, 73),
(40, 74),
(40, 75),
(40, 76),
(40, 77),
(40, 78),
(40, 79),
(40, 80),
(40, 81),
(40, 82),
(40, 83),
(40, 84),
(40, 85),
(40, 86),
(40, 87),
(42, 89),
(43, 88),
(43, 89);

-- --------------------------------------------------------

--
-- Структура таблицы `b_undo`
--

CREATE TABLE `b_undo` (
  `ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNDO_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNDO_HANDLER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTENT` mediumtext COLLATE utf8_unicode_ci,
  `USER_ID` int(11) DEFAULT NULL,
  `TIMESTAMP_X` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_undo`
--

INSERT INTO `b_undo` (`ID`, `MODULE_ID`, `UNDO_TYPE`, `UNDO_HANDLER`, `CONTENT`, `USER_ID`, `TIMESTAMP_X`) VALUES
('100358d43a5f2605891d53579a9530c88', 'fileman', 'edit_component_props', 'CFileman::UndoEditFile', 'a:2:{s:7:\"absPath\";s:29:\"/var/www/dress-shop/index.php\";s:7:\"content\";s:18258:\"<?\nrequire($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/header.php\");\n$APPLICATION->SetTitle(\"Магазин модной одежды\");\n    ?><main>\n<? if ($APPLICATION->GetCurPage() !== \'/\'): ?>\n<section class=\"breadcrumb-section clearfix\">\n    <?$APPLICATION->IncludeComponent(\n    \"bitrix:breadcrumb\",\n    \"breadcrumb\",\n    array(\n        \"PATH\" => \"\",\n        \"SITE_ID\" => \"s1\",\n        \"START_FROM\" => \"0\",\n        \"COMPONENT_TEMPLATE\" => \"breadcrumb\"\n    ),\n    false\n);?>\n</section>\n<? endif; ?>\n<? if ($APPLICATION->GetCurPage(false) === \'/\'): ?>\n <section class=\"features-slider clearfix\">\n<div class=\"my-slider\">\n	 <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"N\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"1\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"N\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?>\n</div>\n<div class=\"features\">\n	 <?$APPLICATION->IncludeFile(\n        SITE_DIR.\"include/features.php\",\n        array(),\n        array(\n            \"MORE\" => \"html\"\n        )\n    );?>\n</div>\n </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"mycatalog-top\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.top\",\n	\"mytop\",\n	Array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPARE_NAME\" => \"CATALOG_COMPARE_LIST\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mytop\",\n		\"DETAIL_URL\" => \"/catalog/#SECTION_CODE#/#ELEMENT_CODE#/\",\n		\"DISPLAY_COMPARE\" => \"N\",\n		\"ELEMENT_COUNT\" => \"6\",\n		\"ELEMENT_SORT_FIELD\" => \"shows\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"ENLARGE_PRODUCT\" => \"PROP\",\n		\"ENLARGE_PROP\" => \"-\",\n		\"FILTER_NAME\" => \"\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"LABEL_PROP\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнить\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"OFFERS_LIMIT\" => \"5\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"PRODUCT_SUBSCRIPTION\" => \"N\",\n		\"PROPERTY_CODE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",5=>\"\",),\n		\"PROPERTY_CODE_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",),\n		\"ROTATE_TIMER\" => \"2\",\n		\"SECTION_ID_VARIABLE\" => \"\",\n		\"SECTION_URL\" => \"/catalog/#SECTION_CODE#/\",\n		\"SEF_MODE\" => \"N\",\n		\"SEF_RULE\" => \"\",\n		\"SHOW_PAGINATION\" => \"Y\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_SLIDER\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"VIEW_MODE\" => \"SECTION\"\n	)\n);?> </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"feedback clearfix\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section>\n<? endif; ?>\n\n<?$pageArray = array(\"/\", \"/catalog/shoes/../\");\nif(!in_array($APPLICATION->GetCurPage(), $pageArray)):?>\n    <section class=\"filter\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.smart.filter\",\n	\"myfilter\",\n	Array(\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"DISPLAY_ELEMENT_COUNT\" => \"N\",\n		\"FILTER_NAME\" => \"arrFilter\",\n		\"FILTER_VIEW_MODE\" => \"horizontal\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"PAGER_PARAMS_NAME\" => \"arrPager\",\n		\"POPUP_POSITION\" => \"left\",\n		\"SAVE_IN_SESSION\" => \"N\",\n		\"SECTION_CODE\" => \"\",\n		\"SECTION_DESCRIPTION\" => \"-\",\n		\"SECTION_ID\" => $_REQUEST[\"SECTION_ID\"],\n		\"SECTION_TITLE\" => \"-\",\n		\"SEF_MODE\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"XML_EXPORT\" => \"N\"\n	)\n);?> </section>\n<? endif; ?> <section class=\"catalog\" id=\"catalog-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog\", \n	\"mycatalog\", \n	array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_ELEMENT_CHAIN\" => \"Y\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mycatalog\",\n		\"DETAIL_ADD_DETAIL_TO_SLIDER\" => \"N\",\n		\"DETAIL_BACKGROUND_IMAGE\" => \"-\",\n		\"DETAIL_BRAND_USE\" => \"N\",\n		\"DETAIL_BROWSER_TITLE\" => \"NAME\",\n		\"DETAIL_CHECK_SECTION_ID_VARIABLE\" => \"N\",\n		\"DETAIL_DETAIL_PICTURE_MODE\" => array(\n			0 => \"MAGNIFIER\",\n		),\n		\"DETAIL_DISPLAY_NAME\" => \"Y\",\n		\"DETAIL_DISPLAY_PREVIEW_TEXT_MODE\" => \"E\",\n		\"DETAIL_IMAGE_RESOLUTION\" => \"1by1\",\n		\"DETAIL_MAIN_BLOCK_PROPERTY_CODE\" => array(\n			0 => \"CAT_DETAIL_PHOTO\",\n		),\n		\"DETAIL_META_DESCRIPTION\" => \"-\",\n		\"DETAIL_META_KEYWORDS\" => \"-\",\n		\"DETAIL_PRODUCT_INFO_BLOCK_ORDER\" => \"props,sku\",\n		\"DETAIL_PRODUCT_PAY_BLOCK_ORDER\" => \"price,rating,priceRanges,quantity,buttons,quantityLimit\",\n		\"DETAIL_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"CAT_DETAIL_PHOTO\",\n			6 => \"\",\n		),\n		\"DETAIL_SET_CANONICAL_URL\" => \"Y\",\n		\"DETAIL_SHOW_POPULAR\" => \"Y\",\n		\"DETAIL_SHOW_SLIDER\" => \"N\",\n		\"DETAIL_SHOW_VIEWED\" => \"Y\",\n		\"DETAIL_SLIDER_INTERVAL\" => \"5000\",\n		\"DETAIL_SLIDER_PROGRESS\" => \"N\",\n		\"DETAIL_STRICT_SECTION_CHECK\" => \"N\",\n		\"DETAIL_USE_COMMENTS\" => \"N\",\n		\"DETAIL_USE_VOTE_RATING\" => \"N\",\n		\"DISABLE_INIT_JS_IN_COMPONENT\" => \"N\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"N\",\n		\"DISPLAY_TOP_PAGER\" => \"Y\",\n		\"ELEMENT_SORT_FIELD\" => \"sort\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"FILE_404\" => \"\",\n		\"FILTER_FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_HIDE_ON_MOBILE\" => \"N\",\n		\"FILTER_NAME\" => \"\",\n		\"FILTER_PRICE_CODE\" => array(\n			0 => \"CAT_PRICE\",\n		),\n		\"FILTER_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"FILTER_VIEW_MODE\" => \"HORIZONTAL\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"INSTANT_RELOAD\" => \"Y\",\n		\"LABEL_PROP\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n		),\n		\"LABEL_PROP_MOBILE\" => array(\n		),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LAZY_LOAD\" => \"N\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"LINK_ELEMENTS_URL\" => \"link.php?PARENT_ELEMENT_ID=#ELEMENT_ID#\",\n		\"LINK_IBLOCK_ID\" => \"\",\n		\"LINK_IBLOCK_TYPE\" => \"\",\n		\"LINK_PROPERTY_SID\" => \"\",\n		\"LIST_BROWSER_TITLE\" => \"-\",\n		\"LIST_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"LIST_META_DESCRIPTION\" => \"-\",\n		\"LIST_META_KEYWORDS\" => \"-\",\n		\"LIST_PRODUCT_BLOCKS_ORDER\" => \"props,price,sku,quantityLimit,quantity,buttons,compare\",\n		\"LIST_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"LIST_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"LIST_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n		),\n		\"LIST_SHOW_SLIDER\" => \"N\",\n		\"LIST_SLIDER_INTERVAL\" => \"3000\",\n		\"LIST_SLIDER_PROGRESS\" => \"N\",\n		\"LOAD_ON_SCROLL\" => \"N\",\n		\"MESSAGE_404\" => \"\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнение\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_BTN_SUBSCRIBE\" => \"Подписаться\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"Y\",\n		\"PAGER_SHOW_ALWAYS\" => \"Y\",\n		\"PAGER_TEMPLATE\" => \"orange\",\n		\"PAGER_TITLE\" => \"Товары\",\n		\"PAGE_ELEMENT_COUNT\" => \"30\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(\n		),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRICE_VAT_SHOW_VALUE\" => \"N\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(\n		),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"SEARCH_CHECK_DATES\" => \"Y\",\n		\"SEARCH_NO_WORD_LOGIC\" => \"Y\",\n		\"SEARCH_PAGE_RESULT_COUNT\" => \"50\",\n		\"SEARCH_RESTART\" => \"N\",\n		\"SEARCH_USE_LANGUAGE_GUESS\" => \"Y\",\n		\"SECTIONS_HIDE_SECTION_NAME\" => \"N\",\n		\"SECTIONS_SHOW_PARENT_NAME\" => \"Y\",\n		\"SECTIONS_VIEW_MODE\" => \"TILE\",\n		\"SECTION_BACKGROUND_IMAGE\" => \"-\",\n		\"SECTION_COUNT_ELEMENTS\" => \"N\",\n		\"SECTION_ID_VARIABLE\" => \"SECTION_CODE\",\n		\"SECTION_TOP_DEPTH\" => \"2\",\n		\"SEF_FOLDER\" => \"/catalog/\",\n		\"SEF_MODE\" => \"Y\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SHOW_DEACTIVATED\" => \"N\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_TOP_ELEMENTS\" => \"N\",\n		\"SIDEBAR_DETAIL_SHOW\" => \"N\",\n		\"SIDEBAR_PATH\" => \"\",\n		\"SIDEBAR_SECTION_SHOW\" => \"Y\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"TOP_ELEMENT_COUNT\" => \"3\",\n		\"TOP_ELEMENT_SORT_FIELD\" => \"sort\",\n		\"TOP_ELEMENT_SORT_FIELD2\" => \"id\",\n		\"TOP_ELEMENT_SORT_ORDER\" => \"asc\",\n		\"TOP_ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"TOP_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"TOP_LINE_ELEMENT_COUNT\" => \"3\",\n		\"TOP_PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"TOP_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'2\',\'BIG_DATA\':false}]\",\n		\"TOP_PROPERTY_CODE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n			4 => \"\",\n		),\n		\"TOP_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n		),\n		\"TOP_ROTATE_TIMER\" => \"30\",\n		\"TOP_SHOW_SLIDER\" => \"N\",\n		\"TOP_SLIDER_INTERVAL\" => \"3000\",\n		\"TOP_SLIDER_PROGRESS\" => \"N\",\n		\"TOP_VIEW_MODE\" => \"SECTION\",\n		\"USE_COMPARE\" => \"N\",\n		\"USE_ELEMENT_COUNTER\" => \"Y\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_FILTER\" => \"Y\",\n		\"USE_MAIN_ELEMENT_SECTION\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"USE_STORE\" => \"N\",\n		\"SEF_URL_TEMPLATES\" => array(\n			\"sections\" => \"\",\n			\"section\" => \"#SECTION_CODE#/\",\n			\"element\" => \"#SECTION_CODE#/#ELEMENT_CODE#/\",\n			\"compare\" => \"compare/\",\n			\"smart_filter\" => \"#SECTION_CODE#/filter/#SMART_FILTER_PATH#/apply/\",\n		)\n	),\n	false\n);?> </section> <section class=\"shipping\" id=\"shipping-anchor\">\n<?$APPLICATION->IncludeFile(\n                        SITE_DIR.\"include/shipping.php\",\n                        array(),\n                        array(\n                            \"MORE\" => \"html\"\n                        )\n                    );?> </section> <section class=\"communication-block\" id=\"contacts-anchor\">\n<div class=\"address-tel\" id=\"address-tel\">\n	 <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/adress-info.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?> <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/telefon.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?>\n</div>\n<div class=\"contacts-form\" id=\"contacts-form\">\n <a href=\"#feedback-anchor\">Напишите нам</a>\n</div>\n </section> <section class=\"yandex-map\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\", \n	\"mymap\", \n	array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mymap\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"Y\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"4\",\n		\"IBLOCK_TYPE\" => \"dress_shop\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(\n			0 => \"ADDRESS\",\n			1 => \"PHONE\",\n			2 => \"YANDEX_MAP\",\n			3 => \"SHOP_MANAGER\",\n			4 => \"HOURS\",\n			5 => \"\",\n		),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	),\n	false\n);?> </section> <section class=\"feedback clearfix\" id=\"feedback-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section> <section class=\"slider-preview\">\n<h1>Наши клиенты о нас</h1>\n <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider-rewiev\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider-rewiev\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"N\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"5\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?> </section> <a href=\"#\" class=\"go-top\"></a> </main><?require($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/footer.php\");?>\";}', 1, 1510656811),
('11ac2c641ec17bacced43c456d806b7a4', 'fileman', 'edit_component_props', 'CFileman::UndoEditFile', 'a:2:{s:7:\"absPath\";s:29:\"/var/www/dress-shop/index.php\";s:7:\"content\";s:18527:\"<?\nrequire($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/header.php\");\n$APPLICATION->SetTitle(\"Магазин модной одежды\");\n    ?><main>\n<? if ($APPLICATION->GetCurPage() !== \'/\'): ?>\n<section class=\"breadcrumb-section clearfix\">\n    <?$APPLICATION->IncludeComponent(\n    \"bitrix:breadcrumb\",\n    \"breadcrumb\",\n    array(\n        \"PATH\" => \"\",\n        \"SITE_ID\" => \"s1\",\n        \"START_FROM\" => \"0\",\n        \"COMPONENT_TEMPLATE\" => \"breadcrumb\"\n    ),\n    false\n);?>\n</section>\n<? endif; ?>\n<? if ($APPLICATION->GetCurPage(false) === \'/\'): ?>\n <section class=\"features-slider clearfix\">\n<div class=\"my-slider\">\n	 <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"N\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"1\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"N\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?>\n</div>\n<div class=\"features\">\n	 <?$APPLICATION->IncludeFile(\n        SITE_DIR.\"include/features.php\",\n        array(),\n        array(\n            \"MORE\" => \"html\"\n        )\n    );?>\n</div>\n </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"mycatalog-top\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.top\",\n	\"mytop\",\n	Array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPARE_NAME\" => \"CATALOG_COMPARE_LIST\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mytop\",\n		\"DETAIL_URL\" => \"/catalog/#SECTION_CODE#/#ELEMENT_CODE#/\",\n		\"DISPLAY_COMPARE\" => \"N\",\n		\"ELEMENT_COUNT\" => \"6\",\n		\"ELEMENT_SORT_FIELD\" => \"shows\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"ENLARGE_PRODUCT\" => \"PROP\",\n		\"ENLARGE_PROP\" => \"-\",\n		\"FILTER_NAME\" => \"\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"LABEL_PROP\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнить\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"OFFERS_LIMIT\" => \"5\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"PRODUCT_SUBSCRIPTION\" => \"N\",\n		\"PROPERTY_CODE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",5=>\"\",),\n		\"PROPERTY_CODE_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",),\n		\"ROTATE_TIMER\" => \"2\",\n		\"SECTION_ID_VARIABLE\" => \"\",\n		\"SECTION_URL\" => \"/catalog/#SECTION_CODE#/\",\n		\"SEF_MODE\" => \"N\",\n		\"SEF_RULE\" => \"\",\n		\"SHOW_PAGINATION\" => \"Y\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_SLIDER\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"VIEW_MODE\" => \"SECTION\"\n	)\n);?> </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"feedback clearfix\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section>\n<? endif; ?>\n\n<?//$NoPageArray = array(\"/\");\n//$YesPageArray = array(\"/catalog/shoes/\");\n//if(!in_array($APPLICATION->GetCurPage(), $pageArray)):?>\n\n    <? if ($APPLICATION->GetCurPage(false) !== \'/\' && $APPLICATION->GetCurPage(false) === \'/catalog/shoes/\'): ?>\n\n    <section class=\"filter\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.smart.filter\", \n	\"myfilter\", \n	array(\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"DISPLAY_ELEMENT_COUNT\" => \"N\",\n		\"FILTER_NAME\" => \"arrFilter\",\n		\"FILTER_VIEW_MODE\" => \"horizontal\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"PAGER_PARAMS_NAME\" => \"arrPager\",\n		\"POPUP_POSITION\" => \"left\",\n		\"SAVE_IN_SESSION\" => \"N\",\n		\"SECTION_CODE\" => \"\",\n		\"SECTION_DESCRIPTION\" => \"-\",\n		\"SECTION_ID\" => $_REQUEST[\"SECTION_ID\"],\n		\"SECTION_TITLE\" => \"-\",\n		\"SEF_MODE\" => \"Y\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"XML_EXPORT\" => \"N\",\n		\"COMPONENT_TEMPLATE\" => \"myfilter\",\n		\"SEF_RULE\" => \"\",\n		\"SECTION_CODE_PATH\" => \"\",\n		\"SMART_FILTER_PATH\" => \"\"\n	),\n	false\n);?> </section>\n<? endif; ?> <section class=\"catalog\" id=\"catalog-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog\", \n	\"mycatalog\", \n	array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_ELEMENT_CHAIN\" => \"Y\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mycatalog\",\n		\"DETAIL_ADD_DETAIL_TO_SLIDER\" => \"N\",\n		\"DETAIL_BACKGROUND_IMAGE\" => \"-\",\n		\"DETAIL_BRAND_USE\" => \"N\",\n		\"DETAIL_BROWSER_TITLE\" => \"NAME\",\n		\"DETAIL_CHECK_SECTION_ID_VARIABLE\" => \"N\",\n		\"DETAIL_DETAIL_PICTURE_MODE\" => array(\n			0 => \"MAGNIFIER\",\n		),\n		\"DETAIL_DISPLAY_NAME\" => \"Y\",\n		\"DETAIL_DISPLAY_PREVIEW_TEXT_MODE\" => \"E\",\n		\"DETAIL_IMAGE_RESOLUTION\" => \"1by1\",\n		\"DETAIL_MAIN_BLOCK_PROPERTY_CODE\" => array(\n			0 => \"CAT_DETAIL_PHOTO\",\n		),\n		\"DETAIL_META_DESCRIPTION\" => \"-\",\n		\"DETAIL_META_KEYWORDS\" => \"-\",\n		\"DETAIL_PRODUCT_INFO_BLOCK_ORDER\" => \"props,sku\",\n		\"DETAIL_PRODUCT_PAY_BLOCK_ORDER\" => \"price,rating,priceRanges,quantity,buttons,quantityLimit\",\n		\"DETAIL_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"CAT_DETAIL_PHOTO\",\n			6 => \"\",\n		),\n		\"DETAIL_SET_CANONICAL_URL\" => \"Y\",\n		\"DETAIL_SHOW_POPULAR\" => \"Y\",\n		\"DETAIL_SHOW_SLIDER\" => \"N\",\n		\"DETAIL_SHOW_VIEWED\" => \"Y\",\n		\"DETAIL_SLIDER_INTERVAL\" => \"5000\",\n		\"DETAIL_SLIDER_PROGRESS\" => \"N\",\n		\"DETAIL_STRICT_SECTION_CHECK\" => \"N\",\n		\"DETAIL_USE_COMMENTS\" => \"N\",\n		\"DETAIL_USE_VOTE_RATING\" => \"N\",\n		\"DISABLE_INIT_JS_IN_COMPONENT\" => \"N\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"N\",\n		\"DISPLAY_TOP_PAGER\" => \"Y\",\n		\"ELEMENT_SORT_FIELD\" => \"sort\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"FILE_404\" => \"\",\n		\"FILTER_FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_HIDE_ON_MOBILE\" => \"N\",\n		\"FILTER_NAME\" => \"\",\n		\"FILTER_PRICE_CODE\" => array(\n			0 => \"CAT_PRICE\",\n		),\n		\"FILTER_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"FILTER_VIEW_MODE\" => \"HORIZONTAL\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"INSTANT_RELOAD\" => \"Y\",\n		\"LABEL_PROP\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n		),\n		\"LABEL_PROP_MOBILE\" => array(\n		),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LAZY_LOAD\" => \"N\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"LINK_ELEMENTS_URL\" => \"link.php?PARENT_ELEMENT_ID=#ELEMENT_ID#\",\n		\"LINK_IBLOCK_ID\" => \"\",\n		\"LINK_IBLOCK_TYPE\" => \"\",\n		\"LINK_PROPERTY_SID\" => \"\",\n		\"LIST_BROWSER_TITLE\" => \"-\",\n		\"LIST_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"LIST_META_DESCRIPTION\" => \"-\",\n		\"LIST_META_KEYWORDS\" => \"-\",\n		\"LIST_PRODUCT_BLOCKS_ORDER\" => \"props,price,sku,quantityLimit,quantity,buttons,compare\",\n		\"LIST_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"LIST_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"LIST_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n		),\n		\"LIST_SHOW_SLIDER\" => \"N\",\n		\"LIST_SLIDER_INTERVAL\" => \"3000\",\n		\"LIST_SLIDER_PROGRESS\" => \"N\",\n		\"LOAD_ON_SCROLL\" => \"N\",\n		\"MESSAGE_404\" => \"\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнение\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_BTN_SUBSCRIBE\" => \"Подписаться\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"Y\",\n		\"PAGER_SHOW_ALWAYS\" => \"Y\",\n		\"PAGER_TEMPLATE\" => \"orange\",\n		\"PAGER_TITLE\" => \"Товары\",\n		\"PAGE_ELEMENT_COUNT\" => \"30\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(\n		),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRICE_VAT_SHOW_VALUE\" => \"N\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(\n		),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"SEARCH_CHECK_DATES\" => \"Y\",\n		\"SEARCH_NO_WORD_LOGIC\" => \"Y\",\n		\"SEARCH_PAGE_RESULT_COUNT\" => \"50\",\n		\"SEARCH_RESTART\" => \"N\",\n		\"SEARCH_USE_LANGUAGE_GUESS\" => \"Y\",\n		\"SECTIONS_HIDE_SECTION_NAME\" => \"N\",\n		\"SECTIONS_SHOW_PARENT_NAME\" => \"Y\",\n		\"SECTIONS_VIEW_MODE\" => \"TILE\",\n		\"SECTION_BACKGROUND_IMAGE\" => \"-\",\n		\"SECTION_COUNT_ELEMENTS\" => \"N\",\n		\"SECTION_ID_VARIABLE\" => \"SECTION_CODE\",\n		\"SECTION_TOP_DEPTH\" => \"2\",\n		\"SEF_FOLDER\" => \"/catalog/\",\n		\"SEF_MODE\" => \"Y\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SHOW_DEACTIVATED\" => \"N\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_TOP_ELEMENTS\" => \"N\",\n		\"SIDEBAR_DETAIL_SHOW\" => \"N\",\n		\"SIDEBAR_PATH\" => \"\",\n		\"SIDEBAR_SECTION_SHOW\" => \"Y\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"TOP_ELEMENT_COUNT\" => \"3\",\n		\"TOP_ELEMENT_SORT_FIELD\" => \"sort\",\n		\"TOP_ELEMENT_SORT_FIELD2\" => \"id\",\n		\"TOP_ELEMENT_SORT_ORDER\" => \"asc\",\n		\"TOP_ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"TOP_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"TOP_LINE_ELEMENT_COUNT\" => \"3\",\n		\"TOP_PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"TOP_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'2\',\'BIG_DATA\':false}]\",\n		\"TOP_PROPERTY_CODE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n			4 => \"\",\n		),\n		\"TOP_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n		),\n		\"TOP_ROTATE_TIMER\" => \"30\",\n		\"TOP_SHOW_SLIDER\" => \"N\",\n		\"TOP_SLIDER_INTERVAL\" => \"3000\",\n		\"TOP_SLIDER_PROGRESS\" => \"N\",\n		\"TOP_VIEW_MODE\" => \"SECTION\",\n		\"USE_COMPARE\" => \"N\",\n		\"USE_ELEMENT_COUNTER\" => \"Y\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_FILTER\" => \"Y\",\n		\"USE_MAIN_ELEMENT_SECTION\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"USE_STORE\" => \"N\",\n		\"SEF_URL_TEMPLATES\" => array(\n			\"sections\" => \"\",\n			\"section\" => \"#SECTION_CODE#/\",\n			\"element\" => \"#SECTION_CODE#/#ELEMENT_CODE#/\",\n			\"compare\" => \"compare/\",\n			\"smart_filter\" => \"#SECTION_CODE#/filter/#SMART_FILTER_PATH#/apply/\",\n		)\n	),\n	false\n);?> </section> <section class=\"shipping\" id=\"shipping-anchor\">\n<?$APPLICATION->IncludeFile(\n                        SITE_DIR.\"include/shipping.php\",\n                        array(),\n                        array(\n                            \"MORE\" => \"html\"\n                        )\n                    );?> </section> <section class=\"communication-block\" id=\"contacts-anchor\">\n<div class=\"address-tel\" id=\"address-tel\">\n	 <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/adress-info.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?> <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/telefon.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?>\n</div>\n<div class=\"contacts-form\" id=\"contacts-form\">\n <a href=\"#feedback-anchor\">Напишите нам</a>\n</div>\n </section> <section class=\"yandex-map\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\", \n	\"mymap\", \n	array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mymap\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"Y\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"4\",\n		\"IBLOCK_TYPE\" => \"dress_shop\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(\n			0 => \"ADDRESS\",\n			1 => \"PHONE\",\n			2 => \"YANDEX_MAP\",\n			3 => \"SHOP_MANAGER\",\n			4 => \"HOURS\",\n			5 => \"\",\n		),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	),\n	false\n);?> </section> <section class=\"feedback clearfix\" id=\"feedback-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section> <section class=\"slider-preview\">\n<h1>Наши клиенты о нас</h1>\n <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider-rewiev\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider-rewiev\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"N\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"5\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?> </section> <a href=\"#\" class=\"go-top\"></a> </main><?require($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/footer.php\");?>\";}', 1, 1510658553);
INSERT INTO `b_undo` (`ID`, `MODULE_ID`, `UNDO_TYPE`, `UNDO_HANDLER`, `CONTENT`, `USER_ID`, `TIMESTAMP_X`) VALUES
('14032e7d174d167da66d37d802ca20d70', 'fileman', 'edit_component_props', 'CFileman::UndoEditFile', 'a:2:{s:7:\"absPath\";s:29:\"/var/www/dress-shop/index.php\";s:7:\"content\";s:18539:\"<?\nrequire($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/header.php\");\n$APPLICATION->SetTitle(\"Магазин модной одежды\");\n    ?><main>\n<? if ($APPLICATION->GetCurPage() !== \'/\'): ?>\n<section class=\"breadcrumb-section clearfix\">\n    <?$APPLICATION->IncludeComponent(\n    \"bitrix:breadcrumb\",\n    \"breadcrumb\",\n    array(\n        \"PATH\" => \"\",\n        \"SITE_ID\" => \"s1\",\n        \"START_FROM\" => \"0\",\n        \"COMPONENT_TEMPLATE\" => \"breadcrumb\"\n    ),\n    false\n);?>\n</section>\n<? endif; ?>\n<? if ($APPLICATION->GetCurPage(false) === \'/\'): ?>\n <section class=\"features-slider clearfix\">\n<div class=\"my-slider\">\n	 <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"N\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"1\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"N\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?>\n</div>\n<div class=\"features\">\n	 <?$APPLICATION->IncludeFile(\n        SITE_DIR.\"include/features.php\",\n        array(),\n        array(\n            \"MORE\" => \"html\"\n        )\n    );?>\n</div>\n </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"mycatalog-top\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.top\",\n	\"mytop\",\n	Array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPARE_NAME\" => \"CATALOG_COMPARE_LIST\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mytop\",\n		\"DETAIL_URL\" => \"/catalog/#SECTION_CODE#/#ELEMENT_CODE#/\",\n		\"DISPLAY_COMPARE\" => \"N\",\n		\"ELEMENT_COUNT\" => \"6\",\n		\"ELEMENT_SORT_FIELD\" => \"shows\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"ENLARGE_PRODUCT\" => \"PROP\",\n		\"ENLARGE_PROP\" => \"-\",\n		\"FILTER_NAME\" => \"\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"LABEL_PROP\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнить\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"OFFERS_LIMIT\" => \"5\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"PRODUCT_SUBSCRIPTION\" => \"N\",\n		\"PROPERTY_CODE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",5=>\"\",),\n		\"PROPERTY_CODE_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",),\n		\"ROTATE_TIMER\" => \"2\",\n		\"SECTION_ID_VARIABLE\" => \"\",\n		\"SECTION_URL\" => \"/catalog/#SECTION_CODE#/\",\n		\"SEF_MODE\" => \"N\",\n		\"SEF_RULE\" => \"\",\n		\"SHOW_PAGINATION\" => \"Y\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_SLIDER\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"VIEW_MODE\" => \"SECTION\"\n	)\n);?> </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"feedback clearfix\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section>\n<? endif; ?>\n\n<?//$NoPageArray = array(\"/\");\n//$YesPageArray = array(\"/catalog/shoes/\");\n//if(!in_array($APPLICATION->GetCurPage(), $pageArray)):?>\n\n    <? if ($APPLICATION->GetCurPage(false) !== \'/\' && $APPLICATION->GetCurPage(false) === \'/catalog/shoes/\'): ?>\n\n    <section class=\"filter\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.smart.filter\", \n	\"myfilter\", \n	array(\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"DISPLAY_ELEMENT_COUNT\" => \"N\",\n		\"FILTER_NAME\" => \"arrFilter\",\n		\"FILTER_VIEW_MODE\" => \"horizontal\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"PAGER_PARAMS_NAME\" => \"arrPager\",\n		\"POPUP_POSITION\" => \"left\",\n		\"SAVE_IN_SESSION\" => \"N\",\n		\"SECTION_CODE\" => \"SECTION_CODE\",\n		\"SECTION_DESCRIPTION\" => \"-\",\n		\"SECTION_ID\" => $_REQUEST[\"SECTION_ID\"],\n		\"SECTION_TITLE\" => \"-\",\n		\"SEF_MODE\" => \"Y\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"XML_EXPORT\" => \"N\",\n		\"COMPONENT_TEMPLATE\" => \"myfilter\",\n		\"SEF_RULE\" => \"\",\n		\"SECTION_CODE_PATH\" => \"\",\n		\"SMART_FILTER_PATH\" => \"\"\n	),\n	false\n);?> </section>\n<? endif; ?> <section class=\"catalog\" id=\"catalog-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog\", \n	\"mycatalog\", \n	array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_ELEMENT_CHAIN\" => \"Y\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mycatalog\",\n		\"DETAIL_ADD_DETAIL_TO_SLIDER\" => \"N\",\n		\"DETAIL_BACKGROUND_IMAGE\" => \"-\",\n		\"DETAIL_BRAND_USE\" => \"N\",\n		\"DETAIL_BROWSER_TITLE\" => \"NAME\",\n		\"DETAIL_CHECK_SECTION_ID_VARIABLE\" => \"N\",\n		\"DETAIL_DETAIL_PICTURE_MODE\" => array(\n			0 => \"MAGNIFIER\",\n		),\n		\"DETAIL_DISPLAY_NAME\" => \"Y\",\n		\"DETAIL_DISPLAY_PREVIEW_TEXT_MODE\" => \"E\",\n		\"DETAIL_IMAGE_RESOLUTION\" => \"1by1\",\n		\"DETAIL_MAIN_BLOCK_PROPERTY_CODE\" => array(\n			0 => \"CAT_DETAIL_PHOTO\",\n		),\n		\"DETAIL_META_DESCRIPTION\" => \"-\",\n		\"DETAIL_META_KEYWORDS\" => \"-\",\n		\"DETAIL_PRODUCT_INFO_BLOCK_ORDER\" => \"props,sku\",\n		\"DETAIL_PRODUCT_PAY_BLOCK_ORDER\" => \"price,rating,priceRanges,quantity,buttons,quantityLimit\",\n		\"DETAIL_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"CAT_DETAIL_PHOTO\",\n			6 => \"\",\n		),\n		\"DETAIL_SET_CANONICAL_URL\" => \"Y\",\n		\"DETAIL_SHOW_POPULAR\" => \"Y\",\n		\"DETAIL_SHOW_SLIDER\" => \"N\",\n		\"DETAIL_SHOW_VIEWED\" => \"Y\",\n		\"DETAIL_SLIDER_INTERVAL\" => \"5000\",\n		\"DETAIL_SLIDER_PROGRESS\" => \"N\",\n		\"DETAIL_STRICT_SECTION_CHECK\" => \"N\",\n		\"DETAIL_USE_COMMENTS\" => \"N\",\n		\"DETAIL_USE_VOTE_RATING\" => \"N\",\n		\"DISABLE_INIT_JS_IN_COMPONENT\" => \"N\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"N\",\n		\"DISPLAY_TOP_PAGER\" => \"Y\",\n		\"ELEMENT_SORT_FIELD\" => \"sort\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"FILE_404\" => \"\",\n		\"FILTER_FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_HIDE_ON_MOBILE\" => \"N\",\n		\"FILTER_NAME\" => \"\",\n		\"FILTER_PRICE_CODE\" => array(\n			0 => \"CAT_PRICE\",\n		),\n		\"FILTER_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"FILTER_VIEW_MODE\" => \"HORIZONTAL\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"INSTANT_RELOAD\" => \"Y\",\n		\"LABEL_PROP\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n		),\n		\"LABEL_PROP_MOBILE\" => array(\n		),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LAZY_LOAD\" => \"N\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"LINK_ELEMENTS_URL\" => \"link.php?PARENT_ELEMENT_ID=#ELEMENT_ID#\",\n		\"LINK_IBLOCK_ID\" => \"\",\n		\"LINK_IBLOCK_TYPE\" => \"\",\n		\"LINK_PROPERTY_SID\" => \"\",\n		\"LIST_BROWSER_TITLE\" => \"-\",\n		\"LIST_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"LIST_META_DESCRIPTION\" => \"-\",\n		\"LIST_META_KEYWORDS\" => \"-\",\n		\"LIST_PRODUCT_BLOCKS_ORDER\" => \"props,price,sku,quantityLimit,quantity,buttons,compare\",\n		\"LIST_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"LIST_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"LIST_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n		),\n		\"LIST_SHOW_SLIDER\" => \"N\",\n		\"LIST_SLIDER_INTERVAL\" => \"3000\",\n		\"LIST_SLIDER_PROGRESS\" => \"N\",\n		\"LOAD_ON_SCROLL\" => \"N\",\n		\"MESSAGE_404\" => \"\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнение\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_BTN_SUBSCRIBE\" => \"Подписаться\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"Y\",\n		\"PAGER_SHOW_ALWAYS\" => \"Y\",\n		\"PAGER_TEMPLATE\" => \"orange\",\n		\"PAGER_TITLE\" => \"Товары\",\n		\"PAGE_ELEMENT_COUNT\" => \"30\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(\n		),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRICE_VAT_SHOW_VALUE\" => \"N\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(\n		),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"SEARCH_CHECK_DATES\" => \"Y\",\n		\"SEARCH_NO_WORD_LOGIC\" => \"Y\",\n		\"SEARCH_PAGE_RESULT_COUNT\" => \"50\",\n		\"SEARCH_RESTART\" => \"N\",\n		\"SEARCH_USE_LANGUAGE_GUESS\" => \"Y\",\n		\"SECTIONS_HIDE_SECTION_NAME\" => \"N\",\n		\"SECTIONS_SHOW_PARENT_NAME\" => \"Y\",\n		\"SECTIONS_VIEW_MODE\" => \"TILE\",\n		\"SECTION_BACKGROUND_IMAGE\" => \"-\",\n		\"SECTION_COUNT_ELEMENTS\" => \"N\",\n		\"SECTION_ID_VARIABLE\" => \"SECTION_CODE\",\n		\"SECTION_TOP_DEPTH\" => \"2\",\n		\"SEF_FOLDER\" => \"/catalog/\",\n		\"SEF_MODE\" => \"Y\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SHOW_DEACTIVATED\" => \"N\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_TOP_ELEMENTS\" => \"N\",\n		\"SIDEBAR_DETAIL_SHOW\" => \"N\",\n		\"SIDEBAR_PATH\" => \"\",\n		\"SIDEBAR_SECTION_SHOW\" => \"Y\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"TOP_ELEMENT_COUNT\" => \"3\",\n		\"TOP_ELEMENT_SORT_FIELD\" => \"sort\",\n		\"TOP_ELEMENT_SORT_FIELD2\" => \"id\",\n		\"TOP_ELEMENT_SORT_ORDER\" => \"asc\",\n		\"TOP_ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"TOP_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"TOP_LINE_ELEMENT_COUNT\" => \"3\",\n		\"TOP_PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"TOP_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'2\',\'BIG_DATA\':false}]\",\n		\"TOP_PROPERTY_CODE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n			4 => \"\",\n		),\n		\"TOP_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n		),\n		\"TOP_ROTATE_TIMER\" => \"30\",\n		\"TOP_SHOW_SLIDER\" => \"N\",\n		\"TOP_SLIDER_INTERVAL\" => \"3000\",\n		\"TOP_SLIDER_PROGRESS\" => \"N\",\n		\"TOP_VIEW_MODE\" => \"SECTION\",\n		\"USE_COMPARE\" => \"N\",\n		\"USE_ELEMENT_COUNTER\" => \"Y\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_FILTER\" => \"Y\",\n		\"USE_MAIN_ELEMENT_SECTION\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"USE_STORE\" => \"N\",\n		\"SEF_URL_TEMPLATES\" => array(\n			\"sections\" => \"\",\n			\"section\" => \"#SECTION_CODE#/\",\n			\"element\" => \"#SECTION_CODE#/#ELEMENT_CODE#/\",\n			\"compare\" => \"compare/\",\n			\"smart_filter\" => \"#SECTION_CODE#/filter/#SMART_FILTER_PATH#/apply/\",\n		)\n	),\n	false\n);?> </section> <section class=\"shipping\" id=\"shipping-anchor\">\n<?$APPLICATION->IncludeFile(\n                        SITE_DIR.\"include/shipping.php\",\n                        array(),\n                        array(\n                            \"MORE\" => \"html\"\n                        )\n                    );?> </section> <section class=\"communication-block\" id=\"contacts-anchor\">\n<div class=\"address-tel\" id=\"address-tel\">\n	 <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/adress-info.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?> <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/telefon.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?>\n</div>\n<div class=\"contacts-form\" id=\"contacts-form\">\n <a href=\"#feedback-anchor\">Напишите нам</a>\n</div>\n </section> <section class=\"yandex-map\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\", \n	\"mymap\", \n	array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mymap\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"Y\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"4\",\n		\"IBLOCK_TYPE\" => \"dress_shop\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(\n			0 => \"ADDRESS\",\n			1 => \"PHONE\",\n			2 => \"YANDEX_MAP\",\n			3 => \"SHOP_MANAGER\",\n			4 => \"HOURS\",\n			5 => \"\",\n		),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	),\n	false\n);?> </section> <section class=\"feedback clearfix\" id=\"feedback-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section> <section class=\"slider-preview\">\n<h1>Наши клиенты о нас</h1>\n <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider-rewiev\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider-rewiev\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"N\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"5\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?> </section> <a href=\"#\" class=\"go-top\"></a> </main><?require($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/footer.php\");?>\";}', 1, 1510658776),
('1d8762239ba790867172616aae670773b', 'fileman', 'edit_component_props', 'CFileman::UndoEditFile', 'a:2:{s:7:\"absPath\";s:29:\"/var/www/dress-shop/index.php\";s:7:\"content\";s:18401:\"<?\nrequire($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/header.php\");\n$APPLICATION->SetTitle(\"Магазин модной одежды\");\n    ?><main>\n<? if ($APPLICATION->GetCurPage() !== \'/\'): ?>\n<section class=\"breadcrumb-section clearfix\">\n    <?$APPLICATION->IncludeComponent(\n    \"bitrix:breadcrumb\",\n    \"breadcrumb\",\n    array(\n        \"PATH\" => \"\",\n        \"SITE_ID\" => \"s1\",\n        \"START_FROM\" => \"0\",\n        \"COMPONENT_TEMPLATE\" => \"breadcrumb\"\n    ),\n    false\n);?>\n</section>\n<? endif; ?>\n<? if ($APPLICATION->GetCurPage(false) === \'/\'): ?>\n <section class=\"features-slider clearfix\">\n<div class=\"my-slider\">\n	 <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"N\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"1\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"N\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?>\n</div>\n<div class=\"features\">\n	 <?$APPLICATION->IncludeFile(\n        SITE_DIR.\"include/features.php\",\n        array(),\n        array(\n            \"MORE\" => \"html\"\n        )\n    );?>\n</div>\n </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"mycatalog-top\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.top\",\n	\"mytop\",\n	Array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPARE_NAME\" => \"CATALOG_COMPARE_LIST\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mytop\",\n		\"DETAIL_URL\" => \"/catalog/#SECTION_CODE#/#ELEMENT_CODE#/\",\n		\"DISPLAY_COMPARE\" => \"N\",\n		\"ELEMENT_COUNT\" => \"6\",\n		\"ELEMENT_SORT_FIELD\" => \"shows\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"ENLARGE_PRODUCT\" => \"PROP\",\n		\"ENLARGE_PROP\" => \"-\",\n		\"FILTER_NAME\" => \"\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"LABEL_PROP\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнить\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"OFFERS_LIMIT\" => \"5\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"PRODUCT_SUBSCRIPTION\" => \"N\",\n		\"PROPERTY_CODE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",5=>\"\",),\n		\"PROPERTY_CODE_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",),\n		\"ROTATE_TIMER\" => \"2\",\n		\"SECTION_ID_VARIABLE\" => \"\",\n		\"SECTION_URL\" => \"/catalog/#SECTION_CODE#/\",\n		\"SEF_MODE\" => \"N\",\n		\"SEF_RULE\" => \"\",\n		\"SHOW_PAGINATION\" => \"Y\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_SLIDER\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"VIEW_MODE\" => \"SECTION\"\n	)\n);?> </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"feedback clearfix\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section>\n<? endif; ?>\n\n<?//$NoPageArray = array(\"/\");\n//$YesPageArray = array(\"/catalog/shoes/\");\n//if(!in_array($APPLICATION->GetCurPage(), $pageArray)):?>\n\n    <? if ($APPLICATION->GetCurPage(false) !== \'/\' && $APPLICATION->GetCurPage(false) === \'/catalog/shoes/\'): ?>\n\n    <section class=\"filter\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.smart.filter\",\n	\"myfilter\",\n	Array(\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"DISPLAY_ELEMENT_COUNT\" => \"N\",\n		\"FILTER_NAME\" => \"arrFilter\",\n		\"FILTER_VIEW_MODE\" => \"horizontal\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"PAGER_PARAMS_NAME\" => \"arrPager\",\n		\"POPUP_POSITION\" => \"left\",\n		\"SAVE_IN_SESSION\" => \"N\",\n		\"SECTION_CODE\" => \"\",\n		\"SECTION_DESCRIPTION\" => \"-\",\n		\"SECTION_ID\" => $_REQUEST[\"SECTION_ID\"],\n		\"SECTION_TITLE\" => \"-\",\n		\"SEF_MODE\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"XML_EXPORT\" => \"N\"\n	)\n);?> </section>\n<? endif; ?> <section class=\"catalog\" id=\"catalog-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog\", \n	\"mycatalog\", \n	array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_ELEMENT_CHAIN\" => \"Y\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mycatalog\",\n		\"DETAIL_ADD_DETAIL_TO_SLIDER\" => \"N\",\n		\"DETAIL_BACKGROUND_IMAGE\" => \"-\",\n		\"DETAIL_BRAND_USE\" => \"N\",\n		\"DETAIL_BROWSER_TITLE\" => \"NAME\",\n		\"DETAIL_CHECK_SECTION_ID_VARIABLE\" => \"N\",\n		\"DETAIL_DETAIL_PICTURE_MODE\" => array(\n			0 => \"MAGNIFIER\",\n		),\n		\"DETAIL_DISPLAY_NAME\" => \"Y\",\n		\"DETAIL_DISPLAY_PREVIEW_TEXT_MODE\" => \"E\",\n		\"DETAIL_IMAGE_RESOLUTION\" => \"1by1\",\n		\"DETAIL_MAIN_BLOCK_PROPERTY_CODE\" => array(\n			0 => \"CAT_DETAIL_PHOTO\",\n		),\n		\"DETAIL_META_DESCRIPTION\" => \"-\",\n		\"DETAIL_META_KEYWORDS\" => \"-\",\n		\"DETAIL_PRODUCT_INFO_BLOCK_ORDER\" => \"props,sku\",\n		\"DETAIL_PRODUCT_PAY_BLOCK_ORDER\" => \"price,rating,priceRanges,quantity,buttons,quantityLimit\",\n		\"DETAIL_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"CAT_DETAIL_PHOTO\",\n			6 => \"\",\n		),\n		\"DETAIL_SET_CANONICAL_URL\" => \"Y\",\n		\"DETAIL_SHOW_POPULAR\" => \"Y\",\n		\"DETAIL_SHOW_SLIDER\" => \"N\",\n		\"DETAIL_SHOW_VIEWED\" => \"Y\",\n		\"DETAIL_SLIDER_INTERVAL\" => \"5000\",\n		\"DETAIL_SLIDER_PROGRESS\" => \"N\",\n		\"DETAIL_STRICT_SECTION_CHECK\" => \"N\",\n		\"DETAIL_USE_COMMENTS\" => \"N\",\n		\"DETAIL_USE_VOTE_RATING\" => \"N\",\n		\"DISABLE_INIT_JS_IN_COMPONENT\" => \"N\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"N\",\n		\"DISPLAY_TOP_PAGER\" => \"Y\",\n		\"ELEMENT_SORT_FIELD\" => \"sort\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"FILE_404\" => \"\",\n		\"FILTER_FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_HIDE_ON_MOBILE\" => \"N\",\n		\"FILTER_NAME\" => \"\",\n		\"FILTER_PRICE_CODE\" => array(\n			0 => \"CAT_PRICE\",\n		),\n		\"FILTER_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"FILTER_VIEW_MODE\" => \"HORIZONTAL\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"INSTANT_RELOAD\" => \"Y\",\n		\"LABEL_PROP\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n		),\n		\"LABEL_PROP_MOBILE\" => array(\n		),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LAZY_LOAD\" => \"N\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"LINK_ELEMENTS_URL\" => \"link.php?PARENT_ELEMENT_ID=#ELEMENT_ID#\",\n		\"LINK_IBLOCK_ID\" => \"\",\n		\"LINK_IBLOCK_TYPE\" => \"\",\n		\"LINK_PROPERTY_SID\" => \"\",\n		\"LIST_BROWSER_TITLE\" => \"-\",\n		\"LIST_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"LIST_META_DESCRIPTION\" => \"-\",\n		\"LIST_META_KEYWORDS\" => \"-\",\n		\"LIST_PRODUCT_BLOCKS_ORDER\" => \"props,price,sku,quantityLimit,quantity,buttons,compare\",\n		\"LIST_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"LIST_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"LIST_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n		),\n		\"LIST_SHOW_SLIDER\" => \"N\",\n		\"LIST_SLIDER_INTERVAL\" => \"3000\",\n		\"LIST_SLIDER_PROGRESS\" => \"N\",\n		\"LOAD_ON_SCROLL\" => \"N\",\n		\"MESSAGE_404\" => \"\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнение\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_BTN_SUBSCRIBE\" => \"Подписаться\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"Y\",\n		\"PAGER_SHOW_ALWAYS\" => \"Y\",\n		\"PAGER_TEMPLATE\" => \"orange\",\n		\"PAGER_TITLE\" => \"Товары\",\n		\"PAGE_ELEMENT_COUNT\" => \"30\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(\n		),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRICE_VAT_SHOW_VALUE\" => \"N\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(\n		),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"SEARCH_CHECK_DATES\" => \"Y\",\n		\"SEARCH_NO_WORD_LOGIC\" => \"Y\",\n		\"SEARCH_PAGE_RESULT_COUNT\" => \"50\",\n		\"SEARCH_RESTART\" => \"N\",\n		\"SEARCH_USE_LANGUAGE_GUESS\" => \"Y\",\n		\"SECTIONS_HIDE_SECTION_NAME\" => \"N\",\n		\"SECTIONS_SHOW_PARENT_NAME\" => \"Y\",\n		\"SECTIONS_VIEW_MODE\" => \"TILE\",\n		\"SECTION_BACKGROUND_IMAGE\" => \"-\",\n		\"SECTION_COUNT_ELEMENTS\" => \"N\",\n		\"SECTION_ID_VARIABLE\" => \"SECTION_CODE\",\n		\"SECTION_TOP_DEPTH\" => \"2\",\n		\"SEF_FOLDER\" => \"/catalog/\",\n		\"SEF_MODE\" => \"Y\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SHOW_DEACTIVATED\" => \"N\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_TOP_ELEMENTS\" => \"N\",\n		\"SIDEBAR_DETAIL_SHOW\" => \"N\",\n		\"SIDEBAR_PATH\" => \"\",\n		\"SIDEBAR_SECTION_SHOW\" => \"Y\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"TOP_ELEMENT_COUNT\" => \"3\",\n		\"TOP_ELEMENT_SORT_FIELD\" => \"sort\",\n		\"TOP_ELEMENT_SORT_FIELD2\" => \"id\",\n		\"TOP_ELEMENT_SORT_ORDER\" => \"asc\",\n		\"TOP_ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"TOP_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"TOP_LINE_ELEMENT_COUNT\" => \"3\",\n		\"TOP_PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"TOP_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'2\',\'BIG_DATA\':false}]\",\n		\"TOP_PROPERTY_CODE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n			4 => \"\",\n		),\n		\"TOP_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n		),\n		\"TOP_ROTATE_TIMER\" => \"30\",\n		\"TOP_SHOW_SLIDER\" => \"N\",\n		\"TOP_SLIDER_INTERVAL\" => \"3000\",\n		\"TOP_SLIDER_PROGRESS\" => \"N\",\n		\"TOP_VIEW_MODE\" => \"SECTION\",\n		\"USE_COMPARE\" => \"N\",\n		\"USE_ELEMENT_COUNTER\" => \"Y\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_FILTER\" => \"Y\",\n		\"USE_MAIN_ELEMENT_SECTION\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"USE_STORE\" => \"N\",\n		\"SEF_URL_TEMPLATES\" => array(\n			\"sections\" => \"\",\n			\"section\" => \"#SECTION_CODE#/\",\n			\"element\" => \"#SECTION_CODE#/#ELEMENT_CODE#/\",\n			\"compare\" => \"compare/\",\n			\"smart_filter\" => \"#SECTION_CODE#/filter/#SMART_FILTER_PATH#/apply/\",\n		)\n	),\n	false\n);?> </section> <section class=\"shipping\" id=\"shipping-anchor\">\n<?$APPLICATION->IncludeFile(\n                        SITE_DIR.\"include/shipping.php\",\n                        array(),\n                        array(\n                            \"MORE\" => \"html\"\n                        )\n                    );?> </section> <section class=\"communication-block\" id=\"contacts-anchor\">\n<div class=\"address-tel\" id=\"address-tel\">\n	 <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/adress-info.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?> <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/telefon.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?>\n</div>\n<div class=\"contacts-form\" id=\"contacts-form\">\n <a href=\"#feedback-anchor\">Напишите нам</a>\n</div>\n </section> <section class=\"yandex-map\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\", \n	\"mymap\", \n	array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mymap\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"Y\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"4\",\n		\"IBLOCK_TYPE\" => \"dress_shop\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(\n			0 => \"ADDRESS\",\n			1 => \"PHONE\",\n			2 => \"YANDEX_MAP\",\n			3 => \"SHOP_MANAGER\",\n			4 => \"HOURS\",\n			5 => \"\",\n		),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	),\n	false\n);?> </section> <section class=\"feedback clearfix\" id=\"feedback-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section> <section class=\"slider-preview\">\n<h1>Наши клиенты о нас</h1>\n <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider-rewiev\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider-rewiev\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"N\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"5\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?> </section> <a href=\"#\" class=\"go-top\"></a> </main><?require($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/footer.php\");?>\";}', 1, 1510658483);
INSERT INTO `b_undo` (`ID`, `MODULE_ID`, `UNDO_TYPE`, `UNDO_HANDLER`, `CONTENT`, `USER_ID`, `TIMESTAMP_X`) VALUES
('1f3f62e34a7f2745067e45a42ac046a8e', 'fileman', 'edit_component_props', 'CFileman::UndoEditFile', 'a:2:{s:7:\"absPath\";s:29:\"/var/www/dress-shop/index.php\";s:7:\"content\";s:18409:\"<?\nrequire($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/header.php\");\n$APPLICATION->SetTitle(\"Магазин модной одежды\");\n    ?><main>\n<? if ($APPLICATION->GetCurPage() !== \'/\'): ?>\n<section class=\"breadcrumb-section clearfix\">\n    <?$APPLICATION->IncludeComponent(\n    \"bitrix:breadcrumb\",\n    \"breadcrumb\",\n    array(\n        \"PATH\" => \"\",\n        \"SITE_ID\" => \"s1\",\n        \"START_FROM\" => \"0\",\n        \"COMPONENT_TEMPLATE\" => \"breadcrumb\"\n    ),\n    false\n);?>\n</section>\n<? endif; ?>\n<? if ($APPLICATION->GetCurPage(false) === \'/\'): ?>\n <section class=\"features-slider clearfix\">\n<div class=\"my-slider\">\n	 <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"N\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"1\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"N\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?>\n</div>\n<div class=\"features\">\n	 <?$APPLICATION->IncludeFile(\n        SITE_DIR.\"include/features.php\",\n        array(),\n        array(\n            \"MORE\" => \"html\"\n        )\n    );?>\n</div>\n </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"mycatalog-top\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.top\",\n	\"mytop\",\n	Array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPARE_NAME\" => \"CATALOG_COMPARE_LIST\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mytop\",\n		\"DETAIL_URL\" => \"/catalog/#SECTION_CODE#/#ELEMENT_CODE#/\",\n		\"DISPLAY_COMPARE\" => \"N\",\n		\"ELEMENT_COUNT\" => \"6\",\n		\"ELEMENT_SORT_FIELD\" => \"shows\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"ENLARGE_PRODUCT\" => \"PROP\",\n		\"ENLARGE_PROP\" => \"-\",\n		\"FILTER_NAME\" => \"\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"LABEL_PROP\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_AVAILABILITY\",),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнить\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"OFFERS_LIMIT\" => \"5\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"PRODUCT_SUBSCRIPTION\" => \"N\",\n		\"PROPERTY_CODE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",5=>\"\",),\n		\"PROPERTY_CODE_MOBILE\" => array(0=>\"CAT_COLOR\",1=>\"CAT_SIZE\",2=>\"CAT_SIZE_SHOES\",3=>\"CAT_PRICE\",4=>\"CAT_AVAILABILITY\",),\n		\"ROTATE_TIMER\" => \"2\",\n		\"SECTION_ID_VARIABLE\" => \"\",\n		\"SECTION_URL\" => \"/catalog/#SECTION_CODE#/\",\n		\"SEF_MODE\" => \"N\",\n		\"SEF_RULE\" => \"\",\n		\"SHOW_PAGINATION\" => \"Y\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_SLIDER\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"VIEW_MODE\" => \"SECTION\"\n	)\n);?> </section>\n<? endif; ?> <? if ($APPLICATION->GetCurPage(false) === \'/\'): ?> <section class=\"feedback clearfix\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section>\n<? endif; ?>\n\n<?//$NoPageArray = array(\"/\");\n//$YesPageArray = array(\"/catalog/shoes/\");\n//if(!in_array($APPLICATION->GetCurPage(), $pageArray)):?>\n\n    <? if ($APPLICATION->GetCurPage(false) !== \'/\' && $APPLICATION->GetCurPage(false) === \'/catalog/shoes/\' ): ?>\n\n    <section class=\"filter\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog.smart.filter\",\n	\"myfilter\",\n	Array(\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"DISPLAY_ELEMENT_COUNT\" => \"N\",\n		\"FILTER_NAME\" => \"arrFilter\",\n		\"FILTER_VIEW_MODE\" => \"horizontal\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"PAGER_PARAMS_NAME\" => \"arrPager\",\n		\"POPUP_POSITION\" => \"left\",\n		\"SAVE_IN_SESSION\" => \"N\",\n		\"SECTION_CODE\" => \"\",\n		\"SECTION_DESCRIPTION\" => \"-\",\n		\"SECTION_ID\" => $_REQUEST[\"SECTION_ID\"],\n		\"SECTION_TITLE\" => \"-\",\n		\"SEF_MODE\" => \"N\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"XML_EXPORT\" => \"N\"\n	)\n);?> </section>\n<? endif; ?> <section class=\"catalog\" id=\"catalog-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:catalog\", \n	\"mycatalog\", \n	array(\n		\"ACTION_VARIABLE\" => \"action\",\n		\"ADD_ELEMENT_CHAIN\" => \"Y\",\n		\"ADD_PICT_PROP\" => \"-\",\n		\"ADD_PROPERTIES_TO_BASKET\" => \"Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"Y\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"BASKET_URL\" => \"/personal/basket.php\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"COMPATIBLE_MODE\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mycatalog\",\n		\"DETAIL_ADD_DETAIL_TO_SLIDER\" => \"N\",\n		\"DETAIL_BACKGROUND_IMAGE\" => \"-\",\n		\"DETAIL_BRAND_USE\" => \"N\",\n		\"DETAIL_BROWSER_TITLE\" => \"NAME\",\n		\"DETAIL_CHECK_SECTION_ID_VARIABLE\" => \"N\",\n		\"DETAIL_DETAIL_PICTURE_MODE\" => array(\n			0 => \"MAGNIFIER\",\n		),\n		\"DETAIL_DISPLAY_NAME\" => \"Y\",\n		\"DETAIL_DISPLAY_PREVIEW_TEXT_MODE\" => \"E\",\n		\"DETAIL_IMAGE_RESOLUTION\" => \"1by1\",\n		\"DETAIL_MAIN_BLOCK_PROPERTY_CODE\" => array(\n			0 => \"CAT_DETAIL_PHOTO\",\n		),\n		\"DETAIL_META_DESCRIPTION\" => \"-\",\n		\"DETAIL_META_KEYWORDS\" => \"-\",\n		\"DETAIL_PRODUCT_INFO_BLOCK_ORDER\" => \"props,sku\",\n		\"DETAIL_PRODUCT_PAY_BLOCK_ORDER\" => \"price,rating,priceRanges,quantity,buttons,quantityLimit\",\n		\"DETAIL_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"CAT_DETAIL_PHOTO\",\n			6 => \"\",\n		),\n		\"DETAIL_SET_CANONICAL_URL\" => \"Y\",\n		\"DETAIL_SHOW_POPULAR\" => \"Y\",\n		\"DETAIL_SHOW_SLIDER\" => \"N\",\n		\"DETAIL_SHOW_VIEWED\" => \"Y\",\n		\"DETAIL_SLIDER_INTERVAL\" => \"5000\",\n		\"DETAIL_SLIDER_PROGRESS\" => \"N\",\n		\"DETAIL_STRICT_SECTION_CHECK\" => \"N\",\n		\"DETAIL_USE_COMMENTS\" => \"N\",\n		\"DETAIL_USE_VOTE_RATING\" => \"N\",\n		\"DISABLE_INIT_JS_IN_COMPONENT\" => \"N\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"N\",\n		\"DISPLAY_TOP_PAGER\" => \"Y\",\n		\"ELEMENT_SORT_FIELD\" => \"sort\",\n		\"ELEMENT_SORT_FIELD2\" => \"id\",\n		\"ELEMENT_SORT_ORDER\" => \"asc\",\n		\"ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"FILE_404\" => \"\",\n		\"FILTER_FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_HIDE_ON_MOBILE\" => \"N\",\n		\"FILTER_NAME\" => \"\",\n		\"FILTER_PRICE_CODE\" => array(\n			0 => \"CAT_PRICE\",\n		),\n		\"FILTER_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"FILTER_VIEW_MODE\" => \"HORIZONTAL\",\n		\"IBLOCK_ID\" => \"3\",\n		\"IBLOCK_TYPE\" => \"assortment\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"INSTANT_RELOAD\" => \"Y\",\n		\"LABEL_PROP\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n		),\n		\"LABEL_PROP_MOBILE\" => array(\n		),\n		\"LABEL_PROP_POSITION\" => \"top-left\",\n		\"LAZY_LOAD\" => \"N\",\n		\"LINE_ELEMENT_COUNT\" => \"3\",\n		\"LINK_ELEMENTS_URL\" => \"link.php?PARENT_ELEMENT_ID=#ELEMENT_ID#\",\n		\"LINK_IBLOCK_ID\" => \"\",\n		\"LINK_IBLOCK_TYPE\" => \"\",\n		\"LINK_PROPERTY_SID\" => \"\",\n		\"LIST_BROWSER_TITLE\" => \"-\",\n		\"LIST_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"LIST_META_DESCRIPTION\" => \"-\",\n		\"LIST_META_KEYWORDS\" => \"-\",\n		\"LIST_PRODUCT_BLOCKS_ORDER\" => \"props,price,sku,quantityLimit,quantity,buttons,compare\",\n		\"LIST_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false},{\'VARIANT\':\'6\',\'BIG_DATA\':false}]\",\n		\"LIST_PROPERTY_CODE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n			5 => \"\",\n		),\n		\"LIST_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"CAT_COLOR\",\n			1 => \"CAT_SIZE\",\n			2 => \"CAT_SIZE_SHOES\",\n			3 => \"CAT_AVAILABILITY\",\n			4 => \"CAT_PRICE\",\n		),\n		\"LIST_SHOW_SLIDER\" => \"N\",\n		\"LIST_SLIDER_INTERVAL\" => \"3000\",\n		\"LIST_SLIDER_PROGRESS\" => \"N\",\n		\"LOAD_ON_SCROLL\" => \"N\",\n		\"MESSAGE_404\" => \"\",\n		\"MESS_BTN_ADD_TO_BASKET\" => \"В корзину\",\n		\"MESS_BTN_BUY\" => \"Купить\",\n		\"MESS_BTN_COMPARE\" => \"Сравнение\",\n		\"MESS_BTN_DETAIL\" => \"Подробнее\",\n		\"MESS_BTN_SUBSCRIBE\" => \"Подписаться\",\n		\"MESS_NOT_AVAILABLE\" => \"Нет в наличии\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"Y\",\n		\"PAGER_SHOW_ALWAYS\" => \"Y\",\n		\"PAGER_TEMPLATE\" => \"orange\",\n		\"PAGER_TITLE\" => \"Товары\",\n		\"PAGE_ELEMENT_COUNT\" => \"30\",\n		\"PARTIAL_PRODUCT_PROPERTIES\" => \"N\",\n		\"PRICE_CODE\" => array(\n		),\n		\"PRICE_VAT_INCLUDE\" => \"Y\",\n		\"PRICE_VAT_SHOW_VALUE\" => \"N\",\n		\"PRODUCT_ID_VARIABLE\" => \"id\",\n		\"PRODUCT_PROPERTIES\" => array(\n		),\n		\"PRODUCT_PROPS_VARIABLE\" => \"prop\",\n		\"PRODUCT_QUANTITY_VARIABLE\" => \"quantity\",\n		\"SEARCH_CHECK_DATES\" => \"Y\",\n		\"SEARCH_NO_WORD_LOGIC\" => \"Y\",\n		\"SEARCH_PAGE_RESULT_COUNT\" => \"50\",\n		\"SEARCH_RESTART\" => \"N\",\n		\"SEARCH_USE_LANGUAGE_GUESS\" => \"Y\",\n		\"SECTIONS_HIDE_SECTION_NAME\" => \"N\",\n		\"SECTIONS_SHOW_PARENT_NAME\" => \"Y\",\n		\"SECTIONS_VIEW_MODE\" => \"TILE\",\n		\"SECTION_BACKGROUND_IMAGE\" => \"-\",\n		\"SECTION_COUNT_ELEMENTS\" => \"N\",\n		\"SECTION_ID_VARIABLE\" => \"SECTION_CODE\",\n		\"SECTION_TOP_DEPTH\" => \"2\",\n		\"SEF_FOLDER\" => \"/catalog/\",\n		\"SEF_MODE\" => \"Y\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SHOW_DEACTIVATED\" => \"N\",\n		\"SHOW_PRICE_COUNT\" => \"1\",\n		\"SHOW_TOP_ELEMENTS\" => \"N\",\n		\"SIDEBAR_DETAIL_SHOW\" => \"N\",\n		\"SIDEBAR_PATH\" => \"\",\n		\"SIDEBAR_SECTION_SHOW\" => \"Y\",\n		\"TEMPLATE_THEME\" => \"blue\",\n		\"TOP_ELEMENT_COUNT\" => \"3\",\n		\"TOP_ELEMENT_SORT_FIELD\" => \"sort\",\n		\"TOP_ELEMENT_SORT_FIELD2\" => \"id\",\n		\"TOP_ELEMENT_SORT_ORDER\" => \"asc\",\n		\"TOP_ELEMENT_SORT_ORDER2\" => \"desc\",\n		\"TOP_ENLARGE_PRODUCT\" => \"STRICT\",\n		\"TOP_LINE_ELEMENT_COUNT\" => \"3\",\n		\"TOP_PRODUCT_BLOCKS_ORDER\" => \"price,props,sku,quantityLimit,quantity,buttons,compare\",\n		\"TOP_PRODUCT_ROW_VARIANTS\" => \"[{\'VARIANT\':\'2\',\'BIG_DATA\':false}]\",\n		\"TOP_PROPERTY_CODE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n			4 => \"\",\n		),\n		\"TOP_PROPERTY_CODE_MOBILE\" => array(\n			0 => \"cat_availability\",\n			1 => \"cat_size_shoes\",\n			2 => \"cat_size\",\n			3 => \"cat_price\",\n		),\n		\"TOP_ROTATE_TIMER\" => \"30\",\n		\"TOP_SHOW_SLIDER\" => \"N\",\n		\"TOP_SLIDER_INTERVAL\" => \"3000\",\n		\"TOP_SLIDER_PROGRESS\" => \"N\",\n		\"TOP_VIEW_MODE\" => \"SECTION\",\n		\"USE_COMPARE\" => \"N\",\n		\"USE_ELEMENT_COUNTER\" => \"Y\",\n		\"USE_ENHANCED_ECOMMERCE\" => \"N\",\n		\"USE_FILTER\" => \"Y\",\n		\"USE_MAIN_ELEMENT_SECTION\" => \"N\",\n		\"USE_PRICE_COUNT\" => \"N\",\n		\"USE_PRODUCT_QUANTITY\" => \"N\",\n		\"USE_STORE\" => \"N\",\n		\"SEF_URL_TEMPLATES\" => array(\n			\"sections\" => \"\",\n			\"section\" => \"#SECTION_CODE#/\",\n			\"element\" => \"#SECTION_CODE#/detail/#ELEMENT_CODE#/\",\n			\"compare\" => \"compare/\",\n			\"smart_filter\" => \"#SECTION_CODE#/filter/#SMART_FILTER_PATH#/apply/\",\n		)\n	),\n	false\n);?> </section> <section class=\"shipping\" id=\"shipping-anchor\">\n<?$APPLICATION->IncludeFile(\n                        SITE_DIR.\"include/shipping.php\",\n                        array(),\n                        array(\n                            \"MORE\" => \"html\"\n                        )\n                    );?> </section> <section class=\"communication-block\" id=\"contacts-anchor\">\n<div class=\"address-tel\" id=\"address-tel\">\n	 <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/adress-info.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?> <?$APPLICATION->IncludeFile(\n                                SITE_DIR.\"include/telefon.php\",\n                                array(),\n                                array(\n                                    \"MORE\" => \"html\"\n                                )\n                            );?>\n</div>\n<div class=\"contacts-form\" id=\"contacts-form\">\n <a href=\"#feedback-anchor\">Напишите нам</a>\n</div>\n </section> <section class=\"yandex-map\">\n<?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\", \n	\"mymap\", \n	array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"mymap\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"Y\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"Y\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(\n			0 => \"\",\n			1 => \"\",\n		),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"4\",\n		\"IBLOCK_TYPE\" => \"dress_shop\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(\n			0 => \"ADDRESS\",\n			1 => \"PHONE\",\n			2 => \"YANDEX_MAP\",\n			3 => \"SHOP_MANAGER\",\n			4 => \"HOURS\",\n			5 => \"\",\n		),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"Y\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	),\n	false\n);?> </section> <section class=\"feedback clearfix\" id=\"feedback-anchor\">\n<?$APPLICATION->IncludeComponent(\n	\"dress:main.feedback\",\n	\"myfeedback\",\n	Array(\n		\"COMPONENT_TEMPLATE\" => \"myfeedback\",\n		\"EMAIL_TO\" => \"test@mail.ru\",\n		\"EVENT_MESSAGE_ID\" => array(),\n		\"OK_TEXT\" => \"Спасибо, ваше сообщение принято.\",\n		\"REQUIRED_FIELDS\" => array(0=>\"TELL\",1=>\"MESSAGE\",),\n		\"USE_CAPTCHA\" => \"N\"\n	)\n);?> </section> <section class=\"slider-preview\">\n<h1>Наши клиенты о нас</h1>\n <?$APPLICATION->IncludeComponent(\n	\"bitrix:news.list\",\n	\"slider-rewiev\",\n	Array(\n		\"ACTIVE_DATE_FORMAT\" => \"d.m.Y\",\n		\"ADD_SECTIONS_CHAIN\" => \"N\",\n		\"AJAX_MODE\" => \"N\",\n		\"AJAX_OPTION_ADDITIONAL\" => \"\",\n		\"AJAX_OPTION_HISTORY\" => \"N\",\n		\"AJAX_OPTION_JUMP\" => \"N\",\n		\"AJAX_OPTION_STYLE\" => \"Y\",\n		\"CACHE_FILTER\" => \"N\",\n		\"CACHE_GROUPS\" => \"Y\",\n		\"CACHE_TIME\" => \"36000000\",\n		\"CACHE_TYPE\" => \"A\",\n		\"CHECK_DATES\" => \"Y\",\n		\"COMPONENT_TEMPLATE\" => \"slider-rewiev\",\n		\"DETAIL_URL\" => \"\",\n		\"DISPLAY_BOTTOM_PAGER\" => \"Y\",\n		\"DISPLAY_DATE\" => \"N\",\n		\"DISPLAY_NAME\" => \"Y\",\n		\"DISPLAY_PICTURE\" => \"N\",\n		\"DISPLAY_PREVIEW_TEXT\" => \"Y\",\n		\"DISPLAY_TOP_PAGER\" => \"N\",\n		\"FIELD_CODE\" => array(0=>\"\",1=>\"\",),\n		\"FILTER_NAME\" => \"\",\n		\"HIDE_LINK_WHEN_NO_DETAIL\" => \"N\",\n		\"IBLOCK_ID\" => \"5\",\n		\"IBLOCK_TYPE\" => \"slider_header\",\n		\"INCLUDE_IBLOCK_INTO_CHAIN\" => \"N\",\n		\"INCLUDE_SUBSECTIONS\" => \"Y\",\n		\"MESSAGE_404\" => \"\",\n		\"NEWS_COUNT\" => \"20\",\n		\"PAGER_BASE_LINK_ENABLE\" => \"N\",\n		\"PAGER_DESC_NUMBERING\" => \"N\",\n		\"PAGER_DESC_NUMBERING_CACHE_TIME\" => \"36000\",\n		\"PAGER_SHOW_ALL\" => \"N\",\n		\"PAGER_SHOW_ALWAYS\" => \"N\",\n		\"PAGER_TEMPLATE\" => \".default\",\n		\"PAGER_TITLE\" => \"Новости\",\n		\"PARENT_SECTION\" => \"\",\n		\"PARENT_SECTION_CODE\" => \"\",\n		\"PREVIEW_TRUNCATE_LEN\" => \"\",\n		\"PROPERTY_CODE\" => array(0=>\"\",1=>\"\",),\n		\"SET_BROWSER_TITLE\" => \"N\",\n		\"SET_LAST_MODIFIED\" => \"N\",\n		\"SET_META_DESCRIPTION\" => \"Y\",\n		\"SET_META_KEYWORDS\" => \"N\",\n		\"SET_STATUS_404\" => \"N\",\n		\"SET_TITLE\" => \"N\",\n		\"SHOW_404\" => \"N\",\n		\"SORT_BY1\" => \"ACTIVE_FROM\",\n		\"SORT_BY2\" => \"SORT\",\n		\"SORT_ORDER1\" => \"DESC\",\n		\"SORT_ORDER2\" => \"ASC\",\n		\"STRICT_SECTION_CHECK\" => \"N\"\n	)\n);?> </section> <a href=\"#\" class=\"go-top\"></a> </main><?require($_SERVER[\"DOCUMENT_ROOT\"].\"/bitrix/footer.php\");?>\";}', 1, 1510658169);

-- --------------------------------------------------------

--
-- Структура таблицы `b_urlpreview_metadata`
--

CREATE TABLE `b_urlpreview_metadata` (
  `ID` int(11) NOT NULL,
  `URL` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `DATE_INSERT` datetime NOT NULL,
  `DATE_EXPIRE` datetime DEFAULT NULL,
  `TITLE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `IMAGE_ID` int(11) DEFAULT NULL,
  `IMAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMBED` mediumtext COLLATE utf8_unicode_ci,
  `EXTRA` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_urlpreview_route`
--

CREATE TABLE `b_urlpreview_route` (
  `ID` int(11) NOT NULL,
  `ROUTE` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CLASS` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMETERS` mediumtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user`
--

CREATE TABLE `b_user` (
  `ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LOGIN` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CHECKWORD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_LOGIN` datetime DEFAULT NULL,
  `DATE_REGISTER` datetime NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PROFESSION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_WWW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ICQ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_GENDER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_BIRTHDATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PHOTO` int(18) DEFAULT NULL,
  `PERSONAL_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_FAX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_MOBILE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PAGER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STREET` text COLLATE utf8_unicode_ci,
  `PERSONAL_MAILBOX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ZIP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_NOTES` text COLLATE utf8_unicode_ci,
  `WORK_COMPANY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_DEPARTMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_POSITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_WWW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_FAX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PAGER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_STREET` text COLLATE utf8_unicode_ci,
  `WORK_MAILBOX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_STATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_ZIP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PROFILE` text COLLATE utf8_unicode_ci,
  `WORK_LOGO` int(18) DEFAULT NULL,
  `WORK_NOTES` text COLLATE utf8_unicode_ci,
  `ADMIN_NOTES` text COLLATE utf8_unicode_ci,
  `STORED_HASH` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_BIRTHDAY` date DEFAULT NULL,
  `EXTERNAL_AUTH_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CHECKWORD_TIME` datetime DEFAULT NULL,
  `SECOND_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONFIRM_CODE` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGIN_ATTEMPTS` int(18) DEFAULT NULL,
  `LAST_ACTIVITY_DATE` datetime DEFAULT NULL,
  `AUTO_TIME_ZONE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_ZONE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_ZONE_OFFSET` int(18) DEFAULT NULL,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BX_USER_ID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_user`
--

INSERT INTO `b_user` (`ID`, `TIMESTAMP_X`, `LOGIN`, `PASSWORD`, `CHECKWORD`, `ACTIVE`, `NAME`, `LAST_NAME`, `EMAIL`, `LAST_LOGIN`, `DATE_REGISTER`, `LID`, `PERSONAL_PROFESSION`, `PERSONAL_WWW`, `PERSONAL_ICQ`, `PERSONAL_GENDER`, `PERSONAL_BIRTHDATE`, `PERSONAL_PHOTO`, `PERSONAL_PHONE`, `PERSONAL_FAX`, `PERSONAL_MOBILE`, `PERSONAL_PAGER`, `PERSONAL_STREET`, `PERSONAL_MAILBOX`, `PERSONAL_CITY`, `PERSONAL_STATE`, `PERSONAL_ZIP`, `PERSONAL_COUNTRY`, `PERSONAL_NOTES`, `WORK_COMPANY`, `WORK_DEPARTMENT`, `WORK_POSITION`, `WORK_WWW`, `WORK_PHONE`, `WORK_FAX`, `WORK_PAGER`, `WORK_STREET`, `WORK_MAILBOX`, `WORK_CITY`, `WORK_STATE`, `WORK_ZIP`, `WORK_COUNTRY`, `WORK_PROFILE`, `WORK_LOGO`, `WORK_NOTES`, `ADMIN_NOTES`, `STORED_HASH`, `XML_ID`, `PERSONAL_BIRTHDAY`, `EXTERNAL_AUTH_ID`, `CHECKWORD_TIME`, `SECOND_NAME`, `CONFIRM_CODE`, `LOGIN_ATTEMPTS`, `LAST_ACTIVITY_DATE`, `AUTO_TIME_ZONE`, `TIME_ZONE`, `TIME_ZONE_OFFSET`, `TITLE`, `BX_USER_ID`, `LANGUAGE_ID`) VALUES
(1, '2017-10-16 02:41:14', 'admin', '5ngvi2ecfe48771b9147d0702d6f96c08a93f485', 'ljX5r7Xz5e466c68ee759c0db4689e52817b5fb6', 'Y', '', '', 'lena1687@mail.ru', '2017-11-15 11:36:41', '2017-10-16 08:41:14', NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-10-16 08:41:14', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_access`
--

CREATE TABLE `b_user_access` (
  `USER_ID` int(11) DEFAULT NULL,
  `PROVIDER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACCESS_CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_user_access`
--

INSERT INTO `b_user_access` (`USER_ID`, `PROVIDER_ID`, `ACCESS_CODE`) VALUES
(0, 'group', 'G2'),
(1, 'group', 'G1'),
(1, 'group', 'G3'),
(1, 'group', 'G4'),
(1, 'group', 'G2'),
(1, 'user', 'U1');

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_access_check`
--

CREATE TABLE `b_user_access_check` (
  `USER_ID` int(11) DEFAULT NULL,
  `PROVIDER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_user_access_check`
--

INSERT INTO `b_user_access_check` (`USER_ID`, `PROVIDER_ID`) VALUES
(1, 'group'),
(1, 'user');

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_counter`
--

CREATE TABLE `b_user_counter` (
  `USER_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '**',
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CNT` int(18) NOT NULL DEFAULT '0',
  `LAST_DATE` datetime DEFAULT NULL,
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '3000-01-01 00:00:00',
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `SENT` char(1) COLLATE utf8_unicode_ci DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_digest`
--

CREATE TABLE `b_user_digest` (
  `USER_ID` int(11) NOT NULL,
  `DIGEST_HA1` varchar(32) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_field`
--

CREATE TABLE `b_user_field` (
  `ID` int(11) NOT NULL,
  `ENTITY_ID` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_NAME` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL,
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `MANDATORY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SHOW_FILTER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SHOW_IN_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EDIT_IN_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `IS_SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SETTINGS` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_field_confirm`
--

CREATE TABLE `b_user_field_confirm` (
  `ID` int(18) NOT NULL,
  `USER_ID` int(18) NOT NULL,
  `DATE_CHANGE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FIELD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FIELD_VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONFIRM_CODE` varchar(32) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_field_enum`
--

CREATE TABLE `b_user_field_enum` (
  `ID` int(11) NOT NULL,
  `USER_FIELD_ID` int(11) DEFAULT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_field_lang`
--

CREATE TABLE `b_user_field_lang` (
  `USER_FIELD_ID` int(11) NOT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `EDIT_FORM_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_COLUMN_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_FILTER_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ERROR_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HELP_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_group`
--

CREATE TABLE `b_user_group` (
  `USER_ID` int(18) NOT NULL,
  `GROUP_ID` int(18) NOT NULL,
  `DATE_ACTIVE_FROM` datetime DEFAULT NULL,
  `DATE_ACTIVE_TO` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_user_group`
--

INSERT INTO `b_user_group` (`USER_ID`, `GROUP_ID`, `DATE_ACTIVE_FROM`, `DATE_ACTIVE_TO`) VALUES
(1, 1, NULL, NULL),
(1, 3, NULL, NULL),
(1, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_hit_auth`
--

CREATE TABLE `b_user_hit_auth` (
  `ID` int(18) NOT NULL,
  `USER_ID` int(18) NOT NULL,
  `HASH` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_option`
--

CREATE TABLE `b_user_option` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `CATEGORY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` mediumtext COLLATE utf8_unicode_ci,
  `COMMON` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_user_option`
--

INSERT INTO `b_user_option` (`ID`, `USER_ID`, `CATEGORY`, `NAME`, `VALUE`, `COMMON`) VALUES
(1, 0, 'intranet', '~gadgets_admin_index', 'a:1:{i:0;a:1:{s:7:\"GADGETS\";a:8:{s:20:\"ADMIN_INFO@333333333\";a:3:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:0;s:4:\"HIDE\";s:1:\"N\";}s:19:\"HTML_AREA@444444444\";a:5:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:1;s:4:\"HIDE\";s:1:\"N\";s:8:\"USERDATA\";a:1:{s:7:\"content\";s:797:\"<table class=\"bx-gadgets-info-site-table\" cellspacing=\"0\"><tr>	<td class=\"bx-gadget-gray\">Создатель сайта:</td>	<td>Группа компаний &laquo;1С-Битрикс&raquo;.</td>	<td class=\"bx-gadgets-info-site-logo\" rowspan=\"5\"><img src=\"/bitrix/components/bitrix/desktop/templates/admin/images/site_logo.png\"></td></tr><tr>	<td class=\"bx-gadget-gray\">Адрес сайта:</td>	<td><a href=\"http://www.1c-bitrix.ru\">www.1c-bitrix.ru</a></td></tr><tr>	<td class=\"bx-gadget-gray\">Сайт сдан:</td>	<td>12 декабря 2010 г.</td></tr><tr>	<td class=\"bx-gadget-gray\">Ответственное лицо:</td>	<td>Иван Иванов</td></tr><tr>	<td class=\"bx-gadget-gray\">E-mail:</td>	<td><a href=\"mailto:info@1c-bitrix.ru\">info@1c-bitrix.ru</a></td></tr></table>\";}s:8:\"SETTINGS\";a:1:{s:9:\"TITLE_STD\";s:34:\"Информация о сайте\";}}s:25:\"ADMIN_CHECKLIST@777888999\";a:3:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:2;s:4:\"HIDE\";s:1:\"N\";}s:19:\"RSSREADER@777777777\";a:4:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:3;s:4:\"HIDE\";s:1:\"N\";s:8:\"SETTINGS\";a:3:{s:9:\"TITLE_STD\";s:33:\"Новости 1С-Битрикс\";s:3:\"CNT\";i:10;s:7:\"RSS_URL\";s:45:\"https://www.1c-bitrix.ru/about/life/news/rss/\";}}s:24:\"ADMIN_SECURITY@555555555\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:0;s:4:\"HIDE\";s:1:\"N\";}s:25:\"ADMIN_SITESPEED@666666777\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:1;s:4:\"HIDE\";s:1:\"N\";}s:23:\"ADMIN_PERFMON@666666666\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:2;s:4:\"HIDE\";s:1:\"N\";}s:23:\"ADMIN_MARKETPALCE@22549\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:3;s:4:\"HIDE\";s:1:\"N\";}}}}', 'Y'),
(2, 1, 'admin_panel', 'settings', 'a:2:{s:4:\"edit\";s:3:\"off\";s:9:\"collapsed\";s:3:\"off\";}', 'N'),
(3, 1, 'hot_keys', 'user_defined', 'b:1;', 'N'),
(4, 1, 'main', 'helper_hero_admin', 'a:1:{s:4:\"time\";s:10:\"1510712381\";}', 'N'),
(5, 1, 'favorite', 'favorite_menu', 'a:1:{s:5:\"stick\";s:1:\"N\";}', 'N'),
(13, 1, 'admin_menu', 'pos', 'a:3:{s:8:\"sections\";s:306:\"menu_fileman,menu_iblock,iblock_admin,menu_iblock_/slider_header,menu_templates,menu_util,backup,menu_module_settings,menu_iblock_%2Fassortment%2F3,menu_perfmon,menu_system,menu_site,iblock_redirect,menu_lang,urlrewrite,menu_iblock_%2Fdress_shop%2F4,menu_iblock_%2Fslider_header%2F5,menu_iblock_/assortment\";s:3:\"ver\";s:2:\"on\";s:5:\"width\";s:3:\"300\";}', 'N'),
(17, 1, 'html_editor', 'user_settings_', 'a:1:{s:13:\"taskbar_shown\";s:1:\"1\";}', 'N'),
(29, 1, 'fileman', 'last_pathes', 's:127:\"a:4:{i:0;s:27:\"/bitrix/templates/dress/img\";i:1;s:23:\"/bitrix/templates/dress\";i:2;s:17:\"/bitrix/templates\";i:3;s:7:\"/bitrix\";}\";', 'N'),
(68, 1, 'bx.windowmanager.9.5', 'size_/bitrix/admin/component_props.php', 'a:2:{s:5:\"width\";s:4:\"1657\";s:6:\"height\";s:3:\"744\";}', 'N'),
(93, 1, 'form', 'form_element_3', 'a:1:{s:4:\"tabs\";s:794:\"edit1--#--Товар--,--ID--#--ID--,--DATE_CREATE--#--Создан--,--TIMESTAMP_X--#--Изменен--,--ACTIVE--#--Активность--,--ACTIVE_FROM--#--Начало активности--,--ACTIVE_TO--#--Окончание активности--,--NAME--#--*Название--,--CODE--#--*Символьный код--,--SORT--#--Сортировка--,--IBLOCK_ELEMENT_PROPERTY--#--Значения свойств--,--IBLOCK_ELEMENT_PROP_VALUE--#----Значения свойств--,--PROPERTY_4--#--Размер обуви--,--PROPERTY_1--#--Размеры одежды--,--PROPERTY_2--#--Цена--,--PROPERTY_3--#--В наличии--,--PREVIEW_PICTURE--#--Картинка для анонса--,--PROPERTY_5--#--Фото--,--DETAIL_TEXT--#--Детальное описание--;--\";}', 'N'),
(110, 1, 'list', 'tbl_iblock_element_231a6cbe00dc6e24a3ba81294e4a72f0', 'a:4:{s:7:\"columns\";s:36:\"NAME,ACTIVE,SORT,TIMESTAMP_X,ID,CODE\";s:2:\"by\";s:11:\"timestamp_x\";s:5:\"order\";s:4:\"desc\";s:9:\"page_size\";s:2:\"20\";}', 'N'),
(117, 1, 'fileman', 'code_editor', 'a:1:{s:5:\"theme\";s:5:\"light\";}', 'N'),
(132, 1, 'list', 'tbl_iblock_section_231a6cbe00dc6e24a3ba81294e4a72f0', 'a:4:{s:7:\"columns\";s:36:\"NAME,CODE,ACTIVE,SORT,TIMESTAMP_X,ID\";s:2:\"by\";s:11:\"timestamp_x\";s:5:\"order\";s:4:\"desc\";s:9:\"page_size\";s:2:\"20\";}', 'N'),
(143, 1, 'bx.windowmanager.9.5', 'options_36f63e3977e67e140cf00b37e1e8c5af', 'a:4:{s:3:\"pin\";s:5:\"false\";s:9:\"transform\";s:5:\"false\";s:3:\"top\";s:5:\"false\";s:4:\"left\";s:5:\"false\";}', 'N'),
(219, 1, 'form', 'form_element_4', 'a:1:{s:4:\"tabs\";s:414:\"edit1--#--Магазин--,--ID--#--ID--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--IBLOCK_ELEMENT_PROP_VALUE--#----Значения свойств--,--PROPERTY_7--#--Адрес магазина--,--PROPERTY_9--#--Контактный телефон--,--PROPERTY_11--#--Координаты--,--PROPERTY_10--#--ФИО руководителя--,--PROPERTY_8--#--Часы работы--;--\";}', 'N'),
(236, 1, 'form', 'form_element_5', 'a:1:{s:4:\"tabs\";s:260:\"edit1--#--Слайд--,--ID--#--ID--,--DATE_CREATE--#--Создан--,--TIMESTAMP_X--#--Изменен--,--ACTIVE--#--Активность--,--NAME--#--*Автор отзыва--,--SORT--#--Сортировка--,--PREVIEW_TEXT--#--Текст отзыва--;--\";}', 'N'),
(253, 1, 'bx.windowmanager.9.5', 'size_bx_component_properties_res', 'a:2:{s:5:\"width\";s:4:\"1248\";s:6:\"height\";s:3:\"756\";}', 'N'),
(258, 1, 'bx.windowmanager.9.5', 'options_acdcdcafae258176295fefdcb19ba760', 'a:4:{s:3:\"pin\";s:5:\"false\";s:3:\"top\";s:5:\"false\";s:4:\"left\";s:5:\"false\";s:9:\"transform\";s:5:\"false\";}', 'N');

-- --------------------------------------------------------

--
-- Структура таблицы `b_user_stored_auth`
--

CREATE TABLE `b_user_stored_auth` (
  `ID` int(18) NOT NULL,
  `USER_ID` int(18) NOT NULL,
  `DATE_REG` datetime NOT NULL,
  `LAST_AUTH` datetime NOT NULL,
  `STORED_HASH` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TEMP_HASH` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IP_ADDR` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `b_user_stored_auth`
--

INSERT INTO `b_user_stored_auth` (`ID`, `USER_ID`, `DATE_REG`, `LAST_AUTH`, `STORED_HASH`, `TEMP_HASH`, `IP_ADDR`) VALUES
(1, 1, '2017-11-01 10:12:03', '2017-11-15 11:36:41', 'adab114d42523b73413380f4c445c15c', 'N', 2130706433);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `b_admin_notify`
--
ALTER TABLE `b_admin_notify`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_AD_TAG` (`TAG`);

--
-- Индексы таблицы `b_admin_notify_lang`
--
ALTER TABLE `b_admin_notify_lang`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `IX_ADM_NTFY_LANG` (`NOTIFY_ID`,`LID`),
  ADD KEY `IX_ADM_NTFY_LID` (`LID`);

--
-- Индексы таблицы `b_agent`
--
ALTER TABLE `b_agent`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_act_next_exec` (`ACTIVE`,`NEXT_EXEC`),
  ADD KEY `ix_agent_user_id` (`USER_ID`);

--
-- Индексы таблицы `b_app_password`
--
ALTER TABLE `b_app_password`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_app_password_user` (`USER_ID`);

--
-- Индексы таблицы `b_b24connector_buttons`
--
ALTER TABLE `b_b24connector_buttons`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_bitrixcloud_option`
--
ALTER TABLE `b_bitrixcloud_option`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_bitrixcloud_option_1` (`NAME`);

--
-- Индексы таблицы `b_cache_tag`
--
ALTER TABLE `b_cache_tag`
  ADD KEY `ix_b_cache_tag_0` (`SITE_ID`,`CACHE_SALT`,`RELATIVE_PATH`(50)),
  ADD KEY `ix_b_cache_tag_1` (`TAG`);

--
-- Индексы таблицы `b_captcha`
--
ALTER TABLE `b_captcha`
  ADD UNIQUE KEY `UX_B_CAPTCHA` (`ID`);

--
-- Индексы таблицы `b_checklist`
--
ALTER TABLE `b_checklist`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_clouds_file_bucket`
--
ALTER TABLE `b_clouds_file_bucket`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_clouds_file_resize`
--
ALTER TABLE `b_clouds_file_resize`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_file_resize_ts` (`TIMESTAMP_X`),
  ADD KEY `ix_b_file_resize_path` (`TO_PATH`(100)),
  ADD KEY `ix_b_file_resize_file` (`FILE_ID`);

--
-- Индексы таблицы `b_clouds_file_upload`
--
ALTER TABLE `b_clouds_file_upload`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_component_params`
--
ALTER TABLE `b_component_params`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_comp_params_name` (`COMPONENT_NAME`),
  ADD KEY `ix_comp_params_path` (`SITE_ID`,`REAL_PATH`),
  ADD KEY `ix_comp_params_sname` (`SITE_ID`,`COMPONENT_NAME`);

--
-- Индексы таблицы `b_consent_agreement`
--
ALTER TABLE `b_consent_agreement`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_CONSENT_AGREEMENT_CODE` (`CODE`);

--
-- Индексы таблицы `b_consent_field`
--
ALTER TABLE `b_consent_field`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_CONSENT_FIELD_AG_ID` (`AGREEMENT_ID`);

--
-- Индексы таблицы `b_consent_user_consent`
--
ALTER TABLE `b_consent_user_consent`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_CONSENT_USER_CONSENT` (`AGREEMENT_ID`);

--
-- Индексы таблицы `b_counter_data`
--
ALTER TABLE `b_counter_data`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_culture`
--
ALTER TABLE `b_culture`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_event`
--
ALTER TABLE `b_event`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_success` (`SUCCESS_EXEC`),
  ADD KEY `ix_b_event_date_exec` (`DATE_EXEC`);

--
-- Индексы таблицы `b_event_attachment`
--
ALTER TABLE `b_event_attachment`
  ADD PRIMARY KEY (`EVENT_ID`,`FILE_ID`);

--
-- Индексы таблицы `b_event_log`
--
ALTER TABLE `b_event_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_event_log_time` (`TIMESTAMP_X`);

--
-- Индексы таблицы `b_event_message`
--
ALTER TABLE `b_event_message`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_event_message_name` (`EVENT_NAME`(50));

--
-- Индексы таблицы `b_event_message_attachment`
--
ALTER TABLE `b_event_message_attachment`
  ADD PRIMARY KEY (`EVENT_MESSAGE_ID`,`FILE_ID`);

--
-- Индексы таблицы `b_event_message_site`
--
ALTER TABLE `b_event_message_site`
  ADD PRIMARY KEY (`EVENT_MESSAGE_ID`,`SITE_ID`);

--
-- Индексы таблицы `b_event_type`
--
ALTER TABLE `b_event_type`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_1` (`EVENT_NAME`,`LID`);

--
-- Индексы таблицы `b_favorite`
--
ALTER TABLE `b_favorite`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_file`
--
ALTER TABLE `b_file`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_FILE_EXTERNAL_ID` (`EXTERNAL_ID`);

--
-- Индексы таблицы `b_file_search`
--
ALTER TABLE `b_file_search`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_filters`
--
ALTER TABLE `b_filters`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_finder_dest`
--
ALTER TABLE `b_finder_dest`
  ADD PRIMARY KEY (`USER_ID`,`CODE`,`CONTEXT`),
  ADD KEY `IX_FINDER_DEST` (`CODE_TYPE`);

--
-- Индексы таблицы `b_geoip_handlers`
--
ALTER TABLE `b_geoip_handlers`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_group`
--
ALTER TABLE `b_group`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_group_collection_task`
--
ALTER TABLE `b_group_collection_task`
  ADD PRIMARY KEY (`GROUP_ID`,`TASK_ID`,`COLLECTION_ID`);

--
-- Индексы таблицы `b_group_subordinate`
--
ALTER TABLE `b_group_subordinate`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_group_task`
--
ALTER TABLE `b_group_task`
  ADD PRIMARY KEY (`GROUP_ID`,`TASK_ID`);

--
-- Индексы таблицы `b_hlblock_entity`
--
ALTER TABLE `b_hlblock_entity`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_hlblock_entity_rights`
--
ALTER TABLE `b_hlblock_entity_rights`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_hot_keys`
--
ALTER TABLE `b_hot_keys`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ix_b_hot_keys_co_u` (`CODE_ID`,`USER_ID`),
  ADD KEY `ix_hot_keys_code` (`CODE_ID`),
  ADD KEY `ix_hot_keys_user` (`USER_ID`);

--
-- Индексы таблицы `b_hot_keys_code`
--
ALTER TABLE `b_hot_keys_code`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_hot_keys_code_cn` (`CLASS_NAME`),
  ADD KEY `ix_hot_keys_code_url` (`URL`);

--
-- Индексы таблицы `b_iblock`
--
ALTER TABLE `b_iblock`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_iblock` (`IBLOCK_TYPE_ID`,`LID`,`ACTIVE`);

--
-- Индексы таблицы `b_iblock_cache`
--
ALTER TABLE `b_iblock_cache`
  ADD PRIMARY KEY (`CACHE_KEY`);

--
-- Индексы таблицы `b_iblock_element`
--
ALTER TABLE `b_iblock_element`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_iblock_element_1` (`IBLOCK_ID`,`IBLOCK_SECTION_ID`),
  ADD KEY `ix_iblock_element_4` (`IBLOCK_ID`,`XML_ID`,`WF_PARENT_ELEMENT_ID`),
  ADD KEY `ix_iblock_element_3` (`WF_PARENT_ELEMENT_ID`),
  ADD KEY `ix_iblock_element_code` (`IBLOCK_ID`,`CODE`);

--
-- Индексы таблицы `b_iblock_element_iprop`
--
ALTER TABLE `b_iblock_element_iprop`
  ADD PRIMARY KEY (`ELEMENT_ID`,`IPROP_ID`),
  ADD KEY `ix_b_iblock_element_iprop_0` (`IPROP_ID`),
  ADD KEY `ix_b_iblock_element_iprop_1` (`IBLOCK_ID`);

--
-- Индексы таблицы `b_iblock_element_lock`
--
ALTER TABLE `b_iblock_element_lock`
  ADD PRIMARY KEY (`IBLOCK_ELEMENT_ID`);

--
-- Индексы таблицы `b_iblock_element_property`
--
ALTER TABLE `b_iblock_element_property`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_iblock_element_property_1` (`IBLOCK_ELEMENT_ID`,`IBLOCK_PROPERTY_ID`),
  ADD KEY `ix_iblock_element_property_2` (`IBLOCK_PROPERTY_ID`),
  ADD KEY `ix_iblock_element_prop_enum` (`VALUE_ENUM`,`IBLOCK_PROPERTY_ID`),
  ADD KEY `ix_iblock_element_prop_num` (`VALUE_NUM`,`IBLOCK_PROPERTY_ID`);

--
-- Индексы таблицы `b_iblock_element_right`
--
ALTER TABLE `b_iblock_element_right`
  ADD PRIMARY KEY (`RIGHT_ID`,`ELEMENT_ID`,`SECTION_ID`),
  ADD KEY `ix_b_iblock_element_right_1` (`ELEMENT_ID`,`IBLOCK_ID`),
  ADD KEY `ix_b_iblock_element_right_2` (`IBLOCK_ID`,`RIGHT_ID`);

--
-- Индексы таблицы `b_iblock_fields`
--
ALTER TABLE `b_iblock_fields`
  ADD PRIMARY KEY (`IBLOCK_ID`,`FIELD_ID`);

--
-- Индексы таблицы `b_iblock_group`
--
ALTER TABLE `b_iblock_group`
  ADD UNIQUE KEY `ux_iblock_group_1` (`IBLOCK_ID`,`GROUP_ID`);

--
-- Индексы таблицы `b_iblock_iblock_iprop`
--
ALTER TABLE `b_iblock_iblock_iprop`
  ADD PRIMARY KEY (`IBLOCK_ID`,`IPROP_ID`),
  ADD KEY `ix_b_iblock_iblock_iprop_0` (`IPROP_ID`);

--
-- Индексы таблицы `b_iblock_iproperty`
--
ALTER TABLE `b_iblock_iproperty`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_iblock_iprop_0` (`IBLOCK_ID`,`ENTITY_TYPE`,`ENTITY_ID`);

--
-- Индексы таблицы `b_iblock_messages`
--
ALTER TABLE `b_iblock_messages`
  ADD PRIMARY KEY (`IBLOCK_ID`,`MESSAGE_ID`);

--
-- Индексы таблицы `b_iblock_offers_tmp`
--
ALTER TABLE `b_iblock_offers_tmp`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_iblock_property`
--
ALTER TABLE `b_iblock_property`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_iblock_property_1` (`IBLOCK_ID`),
  ADD KEY `ix_iblock_property_3` (`LINK_IBLOCK_ID`),
  ADD KEY `ix_iblock_property_2` (`CODE`);

--
-- Индексы таблицы `b_iblock_property_enum`
--
ALTER TABLE `b_iblock_property_enum`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_iblock_property_enum` (`PROPERTY_ID`,`XML_ID`);

--
-- Индексы таблицы `b_iblock_right`
--
ALTER TABLE `b_iblock_right`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_iblock_right_iblock_id` (`IBLOCK_ID`,`ENTITY_TYPE`,`ENTITY_ID`),
  ADD KEY `ix_b_iblock_right_group_code` (`GROUP_CODE`,`IBLOCK_ID`),
  ADD KEY `ix_b_iblock_right_entity` (`ENTITY_ID`,`ENTITY_TYPE`),
  ADD KEY `ix_b_iblock_right_op_eread` (`ID`,`OP_EREAD`,`GROUP_CODE`),
  ADD KEY `ix_b_iblock_right_op_sread` (`ID`,`OP_SREAD`,`GROUP_CODE`),
  ADD KEY `ix_b_iblock_right_task_id` (`TASK_ID`);

--
-- Индексы таблицы `b_iblock_rss`
--
ALTER TABLE `b_iblock_rss`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_iblock_section`
--
ALTER TABLE `b_iblock_section`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_iblock_section_1` (`IBLOCK_ID`,`IBLOCK_SECTION_ID`),
  ADD KEY `ix_iblock_section_depth_level` (`IBLOCK_ID`,`DEPTH_LEVEL`),
  ADD KEY `ix_iblock_section_left_margin` (`IBLOCK_ID`,`LEFT_MARGIN`,`RIGHT_MARGIN`),
  ADD KEY `ix_iblock_section_right_margin` (`IBLOCK_ID`,`RIGHT_MARGIN`,`LEFT_MARGIN`),
  ADD KEY `ix_iblock_section_code` (`IBLOCK_ID`,`CODE`);

--
-- Индексы таблицы `b_iblock_section_element`
--
ALTER TABLE `b_iblock_section_element`
  ADD UNIQUE KEY `ux_iblock_section_element` (`IBLOCK_SECTION_ID`,`IBLOCK_ELEMENT_ID`,`ADDITIONAL_PROPERTY_ID`),
  ADD KEY `UX_IBLOCK_SECTION_ELEMENT2` (`IBLOCK_ELEMENT_ID`);

--
-- Индексы таблицы `b_iblock_section_iprop`
--
ALTER TABLE `b_iblock_section_iprop`
  ADD PRIMARY KEY (`SECTION_ID`,`IPROP_ID`),
  ADD KEY `ix_b_iblock_section_iprop_0` (`IPROP_ID`),
  ADD KEY `ix_b_iblock_section_iprop_1` (`IBLOCK_ID`);

--
-- Индексы таблицы `b_iblock_section_property`
--
ALTER TABLE `b_iblock_section_property`
  ADD PRIMARY KEY (`IBLOCK_ID`,`SECTION_ID`,`PROPERTY_ID`),
  ADD KEY `ix_b_iblock_section_property_1` (`PROPERTY_ID`),
  ADD KEY `ix_b_iblock_section_property_2` (`SECTION_ID`);

--
-- Индексы таблицы `b_iblock_section_right`
--
ALTER TABLE `b_iblock_section_right`
  ADD PRIMARY KEY (`RIGHT_ID`,`SECTION_ID`),
  ADD KEY `ix_b_iblock_section_right_1` (`SECTION_ID`,`IBLOCK_ID`),
  ADD KEY `ix_b_iblock_section_right_2` (`IBLOCK_ID`,`RIGHT_ID`);

--
-- Индексы таблицы `b_iblock_sequence`
--
ALTER TABLE `b_iblock_sequence`
  ADD PRIMARY KEY (`IBLOCK_ID`,`CODE`);

--
-- Индексы таблицы `b_iblock_site`
--
ALTER TABLE `b_iblock_site`
  ADD PRIMARY KEY (`IBLOCK_ID`,`SITE_ID`);

--
-- Индексы таблицы `b_iblock_type`
--
ALTER TABLE `b_iblock_type`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_lang`
--
ALTER TABLE `b_lang`
  ADD PRIMARY KEY (`LID`);

--
-- Индексы таблицы `b_language`
--
ALTER TABLE `b_language`
  ADD PRIMARY KEY (`LID`);

--
-- Индексы таблицы `b_lang_domain`
--
ALTER TABLE `b_lang_domain`
  ADD PRIMARY KEY (`LID`,`DOMAIN`);

--
-- Индексы таблицы `b_medialib_collection`
--
ALTER TABLE `b_medialib_collection`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_medialib_collection_item`
--
ALTER TABLE `b_medialib_collection_item`
  ADD PRIMARY KEY (`ITEM_ID`,`COLLECTION_ID`);

--
-- Индексы таблицы `b_medialib_item`
--
ALTER TABLE `b_medialib_item`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_medialib_type`
--
ALTER TABLE `b_medialib_type`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_module`
--
ALTER TABLE `b_module`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_module_group`
--
ALTER TABLE `b_module_group`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `UK_GROUP_MODULE` (`MODULE_ID`,`GROUP_ID`,`SITE_ID`);

--
-- Индексы таблицы `b_module_to_module`
--
ALTER TABLE `b_module_to_module`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_module_to_module` (`FROM_MODULE_ID`(20),`MESSAGE_ID`(20),`TO_MODULE_ID`(20),`TO_CLASS`(20),`TO_METHOD`(20));

--
-- Индексы таблицы `b_operation`
--
ALTER TABLE `b_operation`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_option`
--
ALTER TABLE `b_option`
  ADD UNIQUE KEY `ix_option` (`MODULE_ID`,`NAME`,`SITE_ID`),
  ADD KEY `ix_option_name` (`NAME`);

--
-- Индексы таблицы `b_perf_cache`
--
ALTER TABLE `b_perf_cache`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `IX_B_PERF_CACHE_0` (`HIT_ID`,`NN`),
  ADD KEY `IX_B_PERF_CACHE_1` (`COMPONENT_ID`);

--
-- Индексы таблицы `b_perf_cluster`
--
ALTER TABLE `b_perf_cluster`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_perf_component`
--
ALTER TABLE `b_perf_component`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `IX_B_PERF_COMPONENT_0` (`HIT_ID`,`NN`);

--
-- Индексы таблицы `b_perf_error`
--
ALTER TABLE `b_perf_error`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_PERF_ERROR_0` (`HIT_ID`);

--
-- Индексы таблицы `b_perf_history`
--
ALTER TABLE `b_perf_history`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_perf_hit`
--
ALTER TABLE `b_perf_hit`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_PERF_HIT_0` (`DATE_HIT`);

--
-- Индексы таблицы `b_perf_index_ban`
--
ALTER TABLE `b_perf_index_ban`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_perf_index_complete`
--
ALTER TABLE `b_perf_index_complete`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_perf_index_complete_0` (`TABLE_NAME`);

--
-- Индексы таблицы `b_perf_index_suggest`
--
ALTER TABLE `b_perf_index_suggest`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_perf_index_suggest_0` (`SQL_MD5`);

--
-- Индексы таблицы `b_perf_index_suggest_sql`
--
ALTER TABLE `b_perf_index_suggest_sql`
  ADD PRIMARY KEY (`SUGGEST_ID`,`SQL_ID`),
  ADD KEY `ix_b_perf_index_suggest_sql_0` (`SQL_ID`,`SUGGEST_ID`);

--
-- Индексы таблицы `b_perf_sql`
--
ALTER TABLE `b_perf_sql`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `IX_B_PERF_SQL_0` (`HIT_ID`,`NN`),
  ADD KEY `IX_B_PERF_SQL_1` (`COMPONENT_ID`);

--
-- Индексы таблицы `b_perf_sql_backtrace`
--
ALTER TABLE `b_perf_sql_backtrace`
  ADD PRIMARY KEY (`SQL_ID`,`NN`);

--
-- Индексы таблицы `b_perf_tab_column_stat`
--
ALTER TABLE `b_perf_tab_column_stat`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_perf_tab_column_stat` (`TABLE_NAME`,`COLUMN_NAME`);

--
-- Индексы таблицы `b_perf_tab_stat`
--
ALTER TABLE `b_perf_tab_stat`
  ADD PRIMARY KEY (`TABLE_NAME`);

--
-- Индексы таблицы `b_perf_test`
--
ALTER TABLE `b_perf_test`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_PERF_TEST_0` (`REFERENCE_ID`);

--
-- Индексы таблицы `b_rating`
--
ALTER TABLE `b_rating`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_rating_component`
--
ALTER TABLE `b_rating_component`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_RATING_ID_1` (`RATING_ID`,`ACTIVE`,`NEXT_CALCULATION`);

--
-- Индексы таблицы `b_rating_component_results`
--
ALTER TABLE `b_rating_component_results`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_ENTITY_TYPE_ID` (`ENTITY_TYPE_ID`),
  ADD KEY `IX_COMPLEX_NAME` (`COMPLEX_NAME`),
  ADD KEY `IX_RATING_ID_2` (`RATING_ID`,`COMPLEX_NAME`);

--
-- Индексы таблицы `b_rating_results`
--
ALTER TABLE `b_rating_results`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_RATING_3` (`RATING_ID`,`ENTITY_TYPE_ID`,`ENTITY_ID`),
  ADD KEY `IX_RATING_4` (`RATING_ID`,`ENTITY_ID`);

--
-- Индексы таблицы `b_rating_rule`
--
ALTER TABLE `b_rating_rule`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_rating_rule_vetting`
--
ALTER TABLE `b_rating_rule_vetting`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `RULE_ID` (`RULE_ID`,`ENTITY_TYPE_ID`,`ENTITY_ID`);

--
-- Индексы таблицы `b_rating_user`
--
ALTER TABLE `b_rating_user`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `RATING_ID` (`RATING_ID`,`ENTITY_ID`),
  ADD KEY `IX_B_RAT_USER_2` (`ENTITY_ID`);

--
-- Индексы таблицы `b_rating_vote`
--
ALTER TABLE `b_rating_vote`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_RAT_VOTE_ID` (`RATING_VOTING_ID`,`USER_ID`),
  ADD KEY `IX_RAT_VOTE_ID_2` (`ENTITY_TYPE_ID`,`ENTITY_ID`,`USER_ID`),
  ADD KEY `IX_RAT_VOTE_ID_3` (`OWNER_ID`,`CREATED`),
  ADD KEY `IX_RAT_VOTE_ID_4` (`USER_ID`),
  ADD KEY `IX_RAT_VOTE_ID_5` (`CREATED`,`VALUE`),
  ADD KEY `IX_RAT_VOTE_ID_6` (`ACTIVE`),
  ADD KEY `IX_RAT_VOTE_ID_7` (`RATING_VOTING_ID`,`CREATED`),
  ADD KEY `IX_RAT_VOTE_ID_8` (`ENTITY_TYPE_ID`,`CREATED`),
  ADD KEY `IX_RAT_VOTE_ID_9` (`CREATED`,`USER_ID`);

--
-- Индексы таблицы `b_rating_vote_group`
--
ALTER TABLE `b_rating_vote_group`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `RATING_ID` (`GROUP_ID`,`TYPE`);

--
-- Индексы таблицы `b_rating_voting`
--
ALTER TABLE `b_rating_voting`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_ENTITY_TYPE_ID_2` (`ENTITY_TYPE_ID`,`ENTITY_ID`,`ACTIVE`),
  ADD KEY `IX_ENTITY_TYPE_ID_4` (`TOTAL_VALUE`);

--
-- Индексы таблицы `b_rating_voting_prepare`
--
ALTER TABLE `b_rating_voting_prepare`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_RATING_VOTING_ID` (`RATING_VOTING_ID`);

--
-- Индексы таблицы `b_rating_weight`
--
ALTER TABLE `b_rating_weight`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_search_content`
--
ALTER TABLE `b_search_content`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `UX_B_SEARCH_CONTENT` (`MODULE_ID`,`ITEM_ID`),
  ADD KEY `IX_B_SEARCH_CONTENT_1` (`MODULE_ID`,`PARAM1`(50),`PARAM2`(50)),
  ADD KEY `IX_B_SEARCH_CONTENT_2` (`ENTITY_ID`(50),`ENTITY_TYPE_ID`);

--
-- Индексы таблицы `b_search_content_freq`
--
ALTER TABLE `b_search_content_freq`
  ADD UNIQUE KEY `UX_B_SEARCH_CONTENT_FREQ` (`STEM`,`LANGUAGE_ID`,`SITE_ID`);

--
-- Индексы таблицы `b_search_content_param`
--
ALTER TABLE `b_search_content_param`
  ADD KEY `IX_B_SEARCH_CONTENT_PARAM` (`SEARCH_CONTENT_ID`,`PARAM_NAME`),
  ADD KEY `IX_B_SEARCH_CONTENT_PARAM_1` (`PARAM_NAME`,`PARAM_VALUE`(50),`SEARCH_CONTENT_ID`);

--
-- Индексы таблицы `b_search_content_right`
--
ALTER TABLE `b_search_content_right`
  ADD UNIQUE KEY `UX_B_SEARCH_CONTENT_RIGHT` (`SEARCH_CONTENT_ID`,`GROUP_CODE`);

--
-- Индексы таблицы `b_search_content_site`
--
ALTER TABLE `b_search_content_site`
  ADD PRIMARY KEY (`SEARCH_CONTENT_ID`,`SITE_ID`);

--
-- Индексы таблицы `b_search_content_stem`
--
ALTER TABLE `b_search_content_stem`
  ADD UNIQUE KEY `UX_B_SEARCH_CONTENT_STEM` (`STEM`,`LANGUAGE_ID`,`TF`,`PS`,`SEARCH_CONTENT_ID`),
  ADD KEY `IND_B_SEARCH_CONTENT_STEM` (`SEARCH_CONTENT_ID`);

--
-- Индексы таблицы `b_search_content_text`
--
ALTER TABLE `b_search_content_text`
  ADD PRIMARY KEY (`SEARCH_CONTENT_ID`);

--
-- Индексы таблицы `b_search_content_title`
--
ALTER TABLE `b_search_content_title`
  ADD UNIQUE KEY `UX_B_SEARCH_CONTENT_TITLE` (`SITE_ID`,`WORD`,`SEARCH_CONTENT_ID`,`POS`),
  ADD KEY `IND_B_SEARCH_CONTENT_TITLE` (`SEARCH_CONTENT_ID`);

--
-- Индексы таблицы `b_search_custom_rank`
--
ALTER TABLE `b_search_custom_rank`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IND_B_SEARCH_CUSTOM_RANK` (`SITE_ID`,`MODULE_ID`);

--
-- Индексы таблицы `b_search_phrase`
--
ALTER TABLE `b_search_phrase`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IND_PK_B_SEARCH_PHRASE_SESS_PH` (`SESSION_ID`,`PHRASE`(50)),
  ADD KEY `IND_PK_B_SEARCH_PHRASE_SESS_TG` (`SESSION_ID`,`TAGS`(50)),
  ADD KEY `IND_PK_B_SEARCH_PHRASE_TIME` (`TIMESTAMP_X`);

--
-- Индексы таблицы `b_search_stem`
--
ALTER TABLE `b_search_stem`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `UX_B_SEARCH_STEM` (`STEM`);

--
-- Индексы таблицы `b_search_suggest`
--
ALTER TABLE `b_search_suggest`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IND_B_SEARCH_SUGGEST` (`FILTER_MD5`,`PHRASE`(50),`RATE`),
  ADD KEY `IND_B_SEARCH_SUGGEST_PHRASE` (`PHRASE`(50),`RATE`),
  ADD KEY `IND_B_SEARCH_SUGGEST_TIME` (`TIMESTAMP_X`);

--
-- Индексы таблицы `b_search_tags`
--
ALTER TABLE `b_search_tags`
  ADD PRIMARY KEY (`SEARCH_CONTENT_ID`,`SITE_ID`,`NAME`),
  ADD KEY `IX_B_SEARCH_TAGS_0` (`NAME`);

--
-- Индексы таблицы `b_search_user_right`
--
ALTER TABLE `b_search_user_right`
  ADD UNIQUE KEY `UX_B_SEARCH_USER_RIGHT` (`USER_ID`,`GROUP_CODE`);

--
-- Индексы таблицы `b_seo_adv_autolog`
--
ALTER TABLE `b_seo_adv_autolog`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_seo_adv_autolog1` (`ENGINE_ID`),
  ADD KEY `ix_b_seo_adv_autolog2` (`TIMESTAMP_X`);

--
-- Индексы таблицы `b_seo_adv_banner`
--
ALTER TABLE `b_seo_adv_banner`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_b_seo_adv_banner` (`ENGINE_ID`,`XML_ID`),
  ADD KEY `ix_b_seo_adv_banner1` (`CAMPAIGN_ID`),
  ADD KEY `ix_b_seo_adv_banner2` (`AUTO_QUANTITY_OFF`,`AUTO_QUANTITY_ON`);

--
-- Индексы таблицы `b_seo_adv_campaign`
--
ALTER TABLE `b_seo_adv_campaign`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_b_seo_adv_campaign` (`ENGINE_ID`,`XML_ID`);

--
-- Индексы таблицы `b_seo_adv_group`
--
ALTER TABLE `b_seo_adv_group`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_b_seo_adv_group` (`ENGINE_ID`,`XML_ID`),
  ADD KEY `ix_b_seo_adv_group1` (`CAMPAIGN_ID`);

--
-- Индексы таблицы `b_seo_adv_link`
--
ALTER TABLE `b_seo_adv_link`
  ADD PRIMARY KEY (`LINK_TYPE`,`LINK_ID`,`BANNER_ID`);

--
-- Индексы таблицы `b_seo_adv_log`
--
ALTER TABLE `b_seo_adv_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_seo_adv_log1` (`ENGINE_ID`),
  ADD KEY `ix_b_seo_adv_log2` (`TIMESTAMP_X`);

--
-- Индексы таблицы `b_seo_adv_order`
--
ALTER TABLE `b_seo_adv_order`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_b_seo_adv_order` (`ENGINE_ID`,`CAMPAIGN_ID`,`BANNER_ID`,`ORDER_ID`),
  ADD KEY `ix_b_seo_adv_order1` (`ORDER_ID`,`PROCESSED`);

--
-- Индексы таблицы `b_seo_adv_region`
--
ALTER TABLE `b_seo_adv_region`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_b_seo_adv_region` (`ENGINE_ID`,`XML_ID`),
  ADD KEY `ix_b_seo_adv_region1` (`PARENT_ID`);

--
-- Индексы таблицы `b_seo_keywords`
--
ALTER TABLE `b_seo_keywords`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_seo_keywords_url` (`URL`,`SITE_ID`);

--
-- Индексы таблицы `b_seo_search_engine`
--
ALTER TABLE `b_seo_search_engine`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_b_seo_search_engine_code` (`CODE`);

--
-- Индексы таблицы `b_seo_service_log`
--
ALTER TABLE `b_seo_service_log`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_seo_service_rtg_queue`
--
ALTER TABLE `b_seo_service_rtg_queue`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_B_SEO_SRV_RTG_QUEUE_1` (`ACTION`,`DATE_AUTO_REMOVE`),
  ADD KEY `IX_B_SEO_SRV_RTG_QUEUE_2` (`TYPE`,`ACTION`);

--
-- Индексы таблицы `b_seo_sitemap`
--
ALTER TABLE `b_seo_sitemap`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_seo_sitemap_entity`
--
ALTER TABLE `b_seo_sitemap_entity`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_seo_sitemap_entity_1` (`ENTITY_TYPE`,`ENTITY_ID`),
  ADD KEY `ix_b_seo_sitemap_entity_2` (`SITEMAP_ID`);

--
-- Индексы таблицы `b_seo_sitemap_iblock`
--
ALTER TABLE `b_seo_sitemap_iblock`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_seo_sitemap_iblock_1` (`IBLOCK_ID`),
  ADD KEY `ix_b_seo_sitemap_iblock_2` (`SITEMAP_ID`);

--
-- Индексы таблицы `b_seo_sitemap_runtime`
--
ALTER TABLE `b_seo_sitemap_runtime`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_seo_sitemap_runtime1` (`PID`,`PROCESSED`,`ITEM_TYPE`,`ITEM_ID`);

--
-- Индексы таблицы `b_seo_yandex_direct_stat`
--
ALTER TABLE `b_seo_yandex_direct_stat`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_seo_yandex_direct_stat` (`BANNER_ID`,`DATE_DAY`),
  ADD KEY `ix_seo_yandex_direct_stat1` (`CAMPAIGN_ID`);

--
-- Индексы таблицы `b_short_uri`
--
ALTER TABLE `b_short_uri`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ux_b_short_uri_1` (`SHORT_URI_CRC`),
  ADD KEY `ux_b_short_uri_2` (`URI_CRC`);

--
-- Индексы таблицы `b_site_template`
--
ALTER TABLE `b_site_template`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_site_template_site` (`SITE_ID`);

--
-- Индексы таблицы `b_smile`
--
ALTER TABLE `b_smile`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_smile_lang`
--
ALTER TABLE `b_smile_lang`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `UX_SMILE_SL` (`TYPE`,`SID`,`LID`);

--
-- Индексы таблицы `b_smile_set`
--
ALTER TABLE `b_smile_set`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_socialservices_ap`
--
ALTER TABLE `b_socialservices_ap`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_socialservices_ap1` (`USER_ID`,`DOMAIN`);

--
-- Индексы таблицы `b_socialservices_contact`
--
ALTER TABLE `b_socialservices_contact`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_socialservices_contact1` (`USER_ID`),
  ADD KEY `ix_b_socialservices_contact2` (`CONTACT_USER_ID`),
  ADD KEY `ix_b_socialservices_contact3` (`TIMESTAMP_X`),
  ADD KEY `ix_b_socialservices_contact4` (`LAST_AUTHORIZE`);

--
-- Индексы таблицы `b_socialservices_contact_connect`
--
ALTER TABLE `b_socialservices_contact_connect`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_socialservices_contact_connect1` (`CONTACT_ID`),
  ADD KEY `ix_b_socialservices_contact_connect2` (`LINK_ID`),
  ADD KEY `ix_b_socialservices_contact_connect3` (`LAST_AUTHORIZE`);

--
-- Индексы таблицы `b_socialservices_message`
--
ALTER TABLE `b_socialservices_message`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_socialservices_user`
--
ALTER TABLE `b_socialservices_user`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `IX_B_SOCIALSERVICES_USER` (`XML_ID`,`EXTERNAL_AUTH_ID`),
  ADD KEY `IX_B_SOCIALSERVICES_US_1` (`USER_ID`),
  ADD KEY `IX_B_SOCIALSERVICES_US_3` (`LOGIN`);

--
-- Индексы таблицы `b_socialservices_user_link`
--
ALTER TABLE `b_socialservices_user_link`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_socialservices_user_link_5` (`SOCSERV_USER_ID`),
  ADD KEY `ix_b_socialservices_user_link_6` (`LINK_USER_ID`,`TIMESTAMP_X`),
  ADD KEY `ix_b_socialservices_user_link_7` (`LINK_UID`);

--
-- Индексы таблицы `b_sticker`
--
ALTER TABLE `b_sticker`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_sticker_group_task`
--
ALTER TABLE `b_sticker_group_task`
  ADD PRIMARY KEY (`GROUP_ID`,`TASK_ID`);

--
-- Индексы таблицы `b_task`
--
ALTER TABLE `b_task`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_task` (`MODULE_ID`,`BINDING`,`LETTER`,`SYS`);

--
-- Индексы таблицы `b_task_operation`
--
ALTER TABLE `b_task_operation`
  ADD PRIMARY KEY (`TASK_ID`,`OPERATION_ID`);

--
-- Индексы таблицы `b_undo`
--
ALTER TABLE `b_undo`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `b_urlpreview_metadata`
--
ALTER TABLE `b_urlpreview_metadata`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_URLPREVIEW_METADATA_URL` (`URL`);

--
-- Индексы таблицы `b_urlpreview_route`
--
ALTER TABLE `b_urlpreview_route`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `UX_URLPREVIEW_ROUTE_ROUTE` (`ROUTE`);

--
-- Индексы таблицы `b_user`
--
ALTER TABLE `b_user`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ix_login` (`LOGIN`,`EXTERNAL_AUTH_ID`),
  ADD KEY `ix_b_user_email` (`EMAIL`),
  ADD KEY `ix_b_user_activity_date` (`LAST_ACTIVITY_DATE`),
  ADD KEY `IX_B_USER_XML_ID` (`XML_ID`);

--
-- Индексы таблицы `b_user_access`
--
ALTER TABLE `b_user_access`
  ADD KEY `ix_ua_user_provider` (`USER_ID`,`PROVIDER_ID`),
  ADD KEY `ix_ua_user_access` (`USER_ID`,`ACCESS_CODE`),
  ADD KEY `ix_ua_access` (`ACCESS_CODE`);

--
-- Индексы таблицы `b_user_access_check`
--
ALTER TABLE `b_user_access_check`
  ADD KEY `ix_uac_user_provider` (`USER_ID`,`PROVIDER_ID`);

--
-- Индексы таблицы `b_user_counter`
--
ALTER TABLE `b_user_counter`
  ADD PRIMARY KEY (`USER_ID`,`SITE_ID`,`CODE`),
  ADD KEY `ix_buc_tag` (`TAG`),
  ADD KEY `ix_buc_code` (`CODE`),
  ADD KEY `ix_buc_ts` (`TIMESTAMP_X`),
  ADD KEY `ix_buc_sent_userid` (`SENT`,`USER_ID`);

--
-- Индексы таблицы `b_user_digest`
--
ALTER TABLE `b_user_digest`
  ADD PRIMARY KEY (`USER_ID`);

--
-- Индексы таблицы `b_user_field`
--
ALTER TABLE `b_user_field`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_user_type_entity` (`ENTITY_ID`,`FIELD_NAME`);

--
-- Индексы таблицы `b_user_field_confirm`
--
ALTER TABLE `b_user_field_confirm`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ix_b_user_field_confirm1` (`USER_ID`,`CONFIRM_CODE`);

--
-- Индексы таблицы `b_user_field_enum`
--
ALTER TABLE `b_user_field_enum`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_user_field_enum` (`USER_FIELD_ID`,`XML_ID`);

--
-- Индексы таблицы `b_user_field_lang`
--
ALTER TABLE `b_user_field_lang`
  ADD PRIMARY KEY (`USER_FIELD_ID`,`LANGUAGE_ID`);

--
-- Индексы таблицы `b_user_group`
--
ALTER TABLE `b_user_group`
  ADD UNIQUE KEY `ix_user_group` (`USER_ID`,`GROUP_ID`),
  ADD KEY `ix_user_group_group` (`GROUP_ID`);

--
-- Индексы таблицы `b_user_hit_auth`
--
ALTER TABLE `b_user_hit_auth`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IX_USER_HIT_AUTH_1` (`HASH`),
  ADD KEY `IX_USER_HIT_AUTH_2` (`USER_ID`),
  ADD KEY `IX_USER_HIT_AUTH_3` (`TIMESTAMP_X`);

--
-- Индексы таблицы `b_user_option`
--
ALTER TABLE `b_user_option`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ux_user_category_name` (`USER_ID`,`CATEGORY`,`NAME`);

--
-- Индексы таблицы `b_user_stored_auth`
--
ALTER TABLE `b_user_stored_auth`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ux_user_hash` (`USER_ID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `b_admin_notify`
--
ALTER TABLE `b_admin_notify`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `b_admin_notify_lang`
--
ALTER TABLE `b_admin_notify_lang`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_agent`
--
ALTER TABLE `b_agent`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `b_app_password`
--
ALTER TABLE `b_app_password`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_bitrixcloud_option`
--
ALTER TABLE `b_bitrixcloud_option`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `b_checklist`
--
ALTER TABLE `b_checklist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_clouds_file_bucket`
--
ALTER TABLE `b_clouds_file_bucket`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_clouds_file_resize`
--
ALTER TABLE `b_clouds_file_resize`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_component_params`
--
ALTER TABLE `b_component_params`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1824;
--
-- AUTO_INCREMENT для таблицы `b_consent_agreement`
--
ALTER TABLE `b_consent_agreement`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_consent_field`
--
ALTER TABLE `b_consent_field`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_consent_user_consent`
--
ALTER TABLE `b_consent_user_consent`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_culture`
--
ALTER TABLE `b_culture`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `b_event`
--
ALTER TABLE `b_event`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_event_log`
--
ALTER TABLE `b_event_log`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT для таблицы `b_event_message`
--
ALTER TABLE `b_event_message`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `b_event_type`
--
ALTER TABLE `b_event_type`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT для таблицы `b_favorite`
--
ALTER TABLE `b_favorite`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_file`
--
ALTER TABLE `b_file`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT для таблицы `b_file_search`
--
ALTER TABLE `b_file_search`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_filters`
--
ALTER TABLE `b_filters`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_geoip_handlers`
--
ALTER TABLE `b_geoip_handlers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `b_group`
--
ALTER TABLE `b_group`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `b_hlblock_entity`
--
ALTER TABLE `b_hlblock_entity`
  MODIFY `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_hlblock_entity_rights`
--
ALTER TABLE `b_hlblock_entity_rights`
  MODIFY `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_hot_keys`
--
ALTER TABLE `b_hot_keys`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT для таблицы `b_hot_keys_code`
--
ALTER TABLE `b_hot_keys_code`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;
--
-- AUTO_INCREMENT для таблицы `b_iblock`
--
ALTER TABLE `b_iblock`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `b_iblock_element`
--
ALTER TABLE `b_iblock_element`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT для таблицы `b_iblock_element_property`
--
ALTER TABLE `b_iblock_element_property`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;
--
-- AUTO_INCREMENT для таблицы `b_iblock_iproperty`
--
ALTER TABLE `b_iblock_iproperty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_iblock_offers_tmp`
--
ALTER TABLE `b_iblock_offers_tmp`
  MODIFY `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_iblock_property`
--
ALTER TABLE `b_iblock_property`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `b_iblock_property_enum`
--
ALTER TABLE `b_iblock_property_enum`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT для таблицы `b_iblock_right`
--
ALTER TABLE `b_iblock_right`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_iblock_rss`
--
ALTER TABLE `b_iblock_rss`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_iblock_section`
--
ALTER TABLE `b_iblock_section`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `b_medialib_collection`
--
ALTER TABLE `b_medialib_collection`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_medialib_item`
--
ALTER TABLE `b_medialib_item`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_medialib_type`
--
ALTER TABLE `b_medialib_type`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `b_module_group`
--
ALTER TABLE `b_module_group`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_module_to_module`
--
ALTER TABLE `b_module_to_module`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;
--
-- AUTO_INCREMENT для таблицы `b_operation`
--
ALTER TABLE `b_operation`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT для таблицы `b_perf_cache`
--
ALTER TABLE `b_perf_cache`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_cluster`
--
ALTER TABLE `b_perf_cluster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_component`
--
ALTER TABLE `b_perf_component`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_error`
--
ALTER TABLE `b_perf_error`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_history`
--
ALTER TABLE `b_perf_history`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_hit`
--
ALTER TABLE `b_perf_hit`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_index_ban`
--
ALTER TABLE `b_perf_index_ban`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_index_complete`
--
ALTER TABLE `b_perf_index_complete`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_index_suggest`
--
ALTER TABLE `b_perf_index_suggest`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_sql`
--
ALTER TABLE `b_perf_sql`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_tab_column_stat`
--
ALTER TABLE `b_perf_tab_column_stat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_perf_test`
--
ALTER TABLE `b_perf_test`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating`
--
ALTER TABLE `b_rating`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `b_rating_component`
--
ALTER TABLE `b_rating_component`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating_component_results`
--
ALTER TABLE `b_rating_component_results`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating_results`
--
ALTER TABLE `b_rating_results`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating_rule`
--
ALTER TABLE `b_rating_rule`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `b_rating_rule_vetting`
--
ALTER TABLE `b_rating_rule_vetting`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating_user`
--
ALTER TABLE `b_rating_user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `b_rating_vote`
--
ALTER TABLE `b_rating_vote`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating_vote_group`
--
ALTER TABLE `b_rating_vote_group`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `b_rating_voting`
--
ALTER TABLE `b_rating_voting`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating_voting_prepare`
--
ALTER TABLE `b_rating_voting_prepare`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_rating_weight`
--
ALTER TABLE `b_rating_weight`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `b_search_content`
--
ALTER TABLE `b_search_content`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT для таблицы `b_search_custom_rank`
--
ALTER TABLE `b_search_custom_rank`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_search_phrase`
--
ALTER TABLE `b_search_phrase`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_search_stem`
--
ALTER TABLE `b_search_stem`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;
--
-- AUTO_INCREMENT для таблицы `b_search_suggest`
--
ALTER TABLE `b_search_suggest`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_adv_autolog`
--
ALTER TABLE `b_seo_adv_autolog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_adv_banner`
--
ALTER TABLE `b_seo_adv_banner`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_adv_campaign`
--
ALTER TABLE `b_seo_adv_campaign`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_adv_group`
--
ALTER TABLE `b_seo_adv_group`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_adv_log`
--
ALTER TABLE `b_seo_adv_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_adv_order`
--
ALTER TABLE `b_seo_adv_order`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_adv_region`
--
ALTER TABLE `b_seo_adv_region`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_keywords`
--
ALTER TABLE `b_seo_keywords`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_search_engine`
--
ALTER TABLE `b_seo_search_engine`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `b_seo_service_log`
--
ALTER TABLE `b_seo_service_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_service_rtg_queue`
--
ALTER TABLE `b_seo_service_rtg_queue`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_sitemap`
--
ALTER TABLE `b_seo_sitemap`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_sitemap_entity`
--
ALTER TABLE `b_seo_sitemap_entity`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_sitemap_iblock`
--
ALTER TABLE `b_seo_sitemap_iblock`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_sitemap_runtime`
--
ALTER TABLE `b_seo_sitemap_runtime`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_seo_yandex_direct_stat`
--
ALTER TABLE `b_seo_yandex_direct_stat`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_short_uri`
--
ALTER TABLE `b_short_uri`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_site_template`
--
ALTER TABLE `b_site_template`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `b_smile`
--
ALTER TABLE `b_smile`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT для таблицы `b_smile_lang`
--
ALTER TABLE `b_smile_lang`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT для таблицы `b_smile_set`
--
ALTER TABLE `b_smile_set`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `b_socialservices_ap`
--
ALTER TABLE `b_socialservices_ap`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_socialservices_contact`
--
ALTER TABLE `b_socialservices_contact`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_socialservices_contact_connect`
--
ALTER TABLE `b_socialservices_contact_connect`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_socialservices_message`
--
ALTER TABLE `b_socialservices_message`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_socialservices_user`
--
ALTER TABLE `b_socialservices_user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_socialservices_user_link`
--
ALTER TABLE `b_socialservices_user_link`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_sticker`
--
ALTER TABLE `b_sticker`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_task`
--
ALTER TABLE `b_task`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT для таблицы `b_urlpreview_metadata`
--
ALTER TABLE `b_urlpreview_metadata`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_urlpreview_route`
--
ALTER TABLE `b_urlpreview_route`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_user`
--
ALTER TABLE `b_user`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `b_user_field`
--
ALTER TABLE `b_user_field`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_user_field_confirm`
--
ALTER TABLE `b_user_field_confirm`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_user_field_enum`
--
ALTER TABLE `b_user_field_enum`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_user_hit_auth`
--
ALTER TABLE `b_user_hit_auth`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `b_user_option`
--
ALTER TABLE `b_user_option`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=260;
--
-- AUTO_INCREMENT для таблицы `b_user_stored_auth`
--
ALTER TABLE `b_user_stored_auth`
  MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
